Complete bounded HTC comparison campaign. r0 is excluded warm-up; r1-r5 measured.
The manifest is frozen and hashed. Paths inside configs preserve the original execution paths.
Relocating inputs requires a new explicit path mapping and executable identity; do not silently overwrite raw configs.

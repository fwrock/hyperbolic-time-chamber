#!/usr/bin/env python3
"""
repair_parquet.py — Recover data from truncated HTC Parquet files.

When the HTC simulator JVM is killed before a clean shutdown (SIGKILL, OOM,
container eviction), the Parquet writer never calls close(), which means the
file footer is never written.  The row-group data is already fully on disk —
only the footer metadata is missing.  This script:

  1. Scans the binary content of each file to find page boundaries and
     row-group structure using the Thrift compact-encoded page headers.
  2. Reconstructs the missing footer (FileMetaData) in Thrift compact format.
  3. Appends the footer to a copy of the file, producing a valid Parquet file
     that pyarrow / DuckDB / Spark can read normally.

Usage
-----
    python repair_parquet.py <file_or_dir> [--out DIR] [--workers N] [--overwrite]

Options
-------
    <file_or_dir>   Path to a single .parquet file or a directory to scan.
    --out DIR       Output directory (default: <input_dir>/repaired/).
    --workers N     Parallel workers (default: 1; increase carefully — RAM).
    --overwrite     Overwrite existing repaired files.
    --dry-run       Parse and report without writing output files.

Requirements
------------
    pip install pyarrow>=14.0 (already in ../requirements.txt)
"""

from __future__ import annotations

import argparse
import struct
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pyarrow as pa
import pyarrow.parquet as pq

# ── Logging ────────────────────────────────────────────────────────────────────
_T0 = time.monotonic()
def _log(msg: str, level: str = "INFO") -> None:
    import datetime
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] [{level}] (+{time.monotonic()-_T0:6.1f}s) {msg}", flush=True)

# ── Parquet / Thrift constants ─────────────────────────────────────────────────
MAGIC = b"PAR1"

# Page types
PT_DATA_PAGE      = 0
PT_INDEX_PAGE     = 1
PT_DICT_PAGE      = 2
PT_DATA_PAGE_V2   = 3

# Encodings
ENC_PLAIN         = 0
ENC_PLAIN_DICT    = 2
ENC_RLE           = 3
ENC_DELTA_BINARY  = 5
ENC_RLE_DICT      = 8

# Thrift compact field types
TC_STOP    = 0
TC_BOOL_T  = 1
TC_BOOL_F  = 2
TC_BYTE    = 3
TC_I16     = 4
TC_I32     = 5
TC_I64     = 6
TC_DOUBLE  = 7
TC_BINARY  = 8
TC_LIST    = 9
TC_SET     = 10
TC_MAP     = 11
TC_STRUCT  = 12

# ── HTC-specific schema knowledge ─────────────────────────────────────────────
# Column order matches ParquetReportData.scala SCHEMA_JSON.
# (col_name, uses_dict, nullable)
HTC_COLUMNS = [
    ("entity_id",     True,  False),  # 0 — required string, dict-encoded
    ("tick",          False, False),  # 1 — required i64,    delta-encoded
    ("real_time_ms",  False, False),  # 2 — required i64,    delta-encoded
    ("lamport_tick",  False, False),  # 3 — required i64,    delta-encoded
    ("event_type",    True,  True),   # 4 — optional string, dict-encoded
    ("simulation_id", True,  False),  # 5 — required string, dict-encoded (1 unique value)
    ("data",          False, True),   # 6 — optional string, PLAIN (no dict)
]
NUM_COLS = len(HTC_COLUMNS)
# Column indices that always start with a DICTIONARY_PAGE
DICT_COL_IDXS = frozenset(i for i, (_, uses_dict, _) in enumerate(HTC_COLUMNS) if uses_dict)


# ── Thrift compact reader ──────────────────────────────────────────────────────

class _ByteReader:
    """Lightweight wrapper for reading Thrift compact values from a bytes buffer."""

    __slots__ = ("_data", "_pos", "_end")

    def __init__(self, data: bytes | bytearray | memoryview, start: int, end: int) -> None:
        self._data = data
        self._pos  = start
        self._end  = end

    @property
    def pos(self) -> int:
        return self._pos

    def read_byte(self) -> int:
        if self._pos >= self._end:
            raise EOFError("Truncated Thrift struct")
        b = self._data[self._pos]
        self._pos += 1
        return b

    def read_varint(self) -> int:
        result, shift = 0, 0
        while True:
            b = self.read_byte()
            result |= (b & 0x7F) << shift
            if not (b & 0x80):
                return result
            shift += 7

    def read_zigzag_i32(self) -> int:
        n = self.read_varint()
        return (n >> 1) ^ -(n & 1)

    def read_zigzag_i64(self) -> int:
        n = self.read_varint()
        return (n >> 1) ^ -(n & 1)

    def skip_binary(self) -> None:
        length = self.read_varint()
        self._pos += length

    def skip_value(self, ftype: int) -> None:
        """Skip a Thrift compact field value of the given type."""
        if ftype in (TC_BOOL_T, TC_BOOL_F):
            pass  # value is in the type byte; nothing extra
        elif ftype in (TC_BYTE,):
            self._pos += 1
        elif ftype in (TC_I16, TC_I32, TC_I64):
            self.read_varint()
        elif ftype == TC_DOUBLE:
            self._pos += 8
        elif ftype == TC_BINARY:
            self.skip_binary()
        elif ftype in (TC_LIST, TC_SET):
            header = self.read_byte()
            size   = header >> 4
            etype  = header & 0x0F
            if size == 15:
                size = self.read_varint()
            for _ in range(size):
                self.skip_value(etype)
        elif ftype == TC_MAP:
            size = self.read_varint()
            if size > 0:
                types = self.read_byte()
                ktype = types >> 4
                vtype = types & 0x0F
                for _ in range(size):
                    self.skip_value(ktype)
                    self.skip_value(vtype)
        elif ftype == TC_STRUCT:
            self.skip_struct()
        else:
            # Unknown type (e.g. 13=UUID in newer Thrift versions).
            # Raise EOFError so the caller can treat this position as invalid.
            raise EOFError(f"Unknown Thrift compact type {ftype}")

    def skip_struct(self) -> None:
        """Skip an entire nested struct."""
        last_fid = 0
        while True:
            fb = self.read_byte()
            if fb == TC_STOP:
                return
            ftype  = fb & 0x0F
            fdelta = fb >> 4
            if fdelta == 0:
                self.read_varint()  # absolute field id
            # booleans carry their value in the type byte
            if ftype not in (TC_BOOL_T, TC_BOOL_F):
                self.skip_value(ftype)


# ── Page header structs ────────────────────────────────────────────────────────

@dataclass
class DictPageInfo:
    num_values: int
    encoding:   int

@dataclass
class DataPageV2Info:
    num_rows:                    int
    num_nulls:                   int
    num_values:                  int
    encoding:                    int
    definition_levels_byte_len:  int
    repetition_levels_byte_len:  int
    is_compressed:               bool = True

@dataclass
class PageInfo:
    offset:           int          # byte offset of the Thrift header in the file
    header_size:      int          # bytes consumed by the Thrift page header
    page_type:        int
    uncompressed_size: int
    compressed_size:  int
    # Only one of these is set
    dict_hdr:   Optional[DictPageInfo]   = None
    data_v2_hdr: Optional[DataPageV2Info] = None

    @property
    def data_offset(self) -> int:
        return self.offset + self.header_size

    @property
    def total_size(self) -> int:
        return self.header_size + self.compressed_size


def _parse_dict_header(rdr: _ByteReader) -> DictPageInfo:
    num_values = 0
    encoding   = 0
    last_fid   = 0
    while True:
        fb = rdr.read_byte()
        if fb == TC_STOP:
            break
        ftype  = fb & 0x0F
        fdelta = fb >> 4
        if fdelta == 0:
            fid = rdr.read_zigzag_i32()
        else:
            fid = last_fid + fdelta
        last_fid = fid

        if fid == 1 and ftype == TC_I32:
            num_values = rdr.read_zigzag_i32()
        elif fid == 2 and ftype == TC_I32:
            encoding = rdr.read_zigzag_i32()
        else:
            if ftype not in (TC_BOOL_T, TC_BOOL_F):
                rdr.skip_value(ftype)
    return DictPageInfo(num_values=num_values, encoding=encoding)


def _parse_data_v2_header(rdr: _ByteReader) -> DataPageV2Info:
    d = DataPageV2Info(0, 0, 0, 0, 0, 0)
    last_fid = 0
    while True:
        fb = rdr.read_byte()
        if fb == TC_STOP:
            break
        ftype  = fb & 0x0F
        fdelta = fb >> 4
        if fdelta == 0:
            fid = rdr.read_zigzag_i32()
        else:
            fid = last_fid + fdelta
        last_fid = fid

        if ftype not in (TC_BOOL_T, TC_BOOL_F) and fid in (1, 2, 3, 4, 5, 6):
            val = rdr.read_zigzag_i32()
            if fid == 1:
                d.num_rows = val
            elif fid == 2:
                d.num_nulls = val
            elif fid == 3:
                d.num_values = val
            elif fid == 4:
                d.encoding = val
            elif fid == 5:
                d.definition_levels_byte_len = val
            elif fid == 6:
                d.repetition_levels_byte_len = val
        elif fid == 7 and ftype in (TC_BOOL_T, TC_BOOL_F):
            d.is_compressed = ftype == TC_BOOL_T
        else:
            if ftype not in (TC_BOOL_T, TC_BOOL_F):
                rdr.skip_value(ftype)
    return d


def _parse_page_header(data: bytes | bytearray | memoryview,
                        offset: int) -> Optional[PageInfo]:
    """Attempt to parse one Thrift compact PageHeader at *offset*.
    Returns None if parsing fails or produces implausible values."""
    max_header = min(offset + 4096, len(data))  # headers are small
    rdr = _ByteReader(data, offset, max_header)

    page_type = uncomp = comp = -1
    dict_hdr: Optional[DictPageInfo]    = None
    data_v2:  Optional[DataPageV2Info]  = None

    try:
        last_fid = 0
        while True:
            fb = rdr.read_byte()
            if fb == TC_STOP:
                break
            ftype  = fb & 0x0F
            fdelta = fb >> 4
            if fdelta == 0:
                fid = rdr.read_zigzag_i32()
            else:
                fid = last_fid + fdelta
            last_fid = fid

            if fid == 1 and ftype == TC_I32:
                page_type = rdr.read_zigzag_i32()
            elif fid == 2 and ftype == TC_I32:
                uncomp = rdr.read_zigzag_i32()
            elif fid == 3 and ftype == TC_I32:
                comp = rdr.read_zigzag_i32()
            elif fid == 4 and ftype == TC_I32:
                rdr.read_zigzag_i32()  # crc — skip
            elif fid == 5 and ftype == TC_STRUCT:
                rdr.skip_struct()      # DataPageHeader v1 — skip
            elif fid == 7 and ftype == TC_STRUCT:
                inner_start = rdr.pos
                dict_hdr = _parse_dict_header(rdr)
            elif fid == 8 and ftype == TC_STRUCT:
                data_v2 = _parse_data_v2_header(rdr)
            else:
                if ftype not in (TC_BOOL_T, TC_BOOL_F):
                    rdr.skip_value(ftype)
    except Exception:
        # Any parse error at this position means this is not a valid page header.
        # scan_pages will slide forward one byte and try the next position.
        return None

    header_size = rdr.pos - offset

    # Basic sanity checks
    if page_type not in (PT_DATA_PAGE, PT_DICT_PAGE, PT_DATA_PAGE_V2):
        return None
    if uncomp < 0 or comp < 0 or comp > 512 * 1024 * 1024:
        return None
    if header_size < 3 or header_size > 1024:
        return None
    if rdr.pos + comp > len(data) + 1:   # allow 1-byte slack
        return None

    return PageInfo(
        offset=offset,
        header_size=header_size,
        page_type=page_type,
        uncompressed_size=uncomp,
        compressed_size=comp,
        dict_hdr=dict_hdr,
        data_v2_hdr=data_v2,
    )


# ── File scanner ───────────────────────────────────────────────────────────────

def scan_pages(data: bytes | bytearray | memoryview) -> list[PageInfo]:
    """Scan the binary for Parquet pages, starting at offset 4 (after PAR1 magic).

    Uses the page headers' compressed_page_size to jump to the next header once
    a valid page is found.  When the jump lands on garbage (e.g. due to the JVM
    writing partial data), falls back to a pattern-search: Thrift compact page
    headers always start with byte 0x15 (field 1, type I32 = page_type enum)
    encoded as delta=1, type=TC_I32 → (1 << 4) | 5 = 0x15.  We use
    bytes.find() to skip ahead quickly instead of byte-by-byte sliding.
    """
    pages: list[PageInfo] = []
    pos = 4  # skip opening PAR1 magic
    n   = len(data)

    # Thrift compact field header for "field 1, type I32 (TC_I32=5)" = 0x15.
    # This is always the FIRST byte of a valid Parquet PageHeader because
    # the Thrift delta=1 from last_fid=0 encodes page_type (field id 1, I32).
    _HEADER_ANCHOR = bytes([0x15])

    consecutive_failures = 0

    while pos < n - 8:
        pi = _parse_page_header(data, pos)
        if pi is not None:
            pages.append(pi)
            next_pos = pi.data_offset + pi.compressed_size
            # Sanity-check the jump; if it overshoots or is negative, fall through
            if 0 < next_pos - pos < 512 * 1024 * 1024:
                pos = next_pos
                consecutive_failures = 0
                continue
            # Suspicious jump — treat as failure and search ahead
        
        # Fast-forward to the next candidate using bytes.find()
        search_start = pos + 1
        next_anchor  = data.find(_HEADER_ANCHOR, search_start, min(search_start + 4 * 1024 * 1024, n))
        if next_anchor == -1:
            # No anchor found in next 4 MB — skip that block entirely
            pos = search_start + 4 * 1024 * 1024
            consecutive_failures += 1
        else:
            pos = next_anchor
            consecutive_failures += 1

        # Give up if we've been failing for too long without finding any page
        if consecutive_failures > 512 and not pages:
            # Extend search window if we haven't found anything yet
            consecutive_failures = 0
        elif consecutive_failures > 2048:
            break

    return pages


# ── Row-group assembler ────────────────────────────────────────────────────────

@dataclass
class ColumnChunkMeta:
    col_idx:           int
    file_offset:       int       # offset of first page header
    total_header_size: int
    total_comp_size:   int
    total_uncomp_size: int
    num_values:        int
    num_rows:          int
    has_dict_page:     bool
    pages:             list[PageInfo] = field(default_factory=list)

    @property
    def data_page_offset(self) -> int:
        """Offset of the first data page (after optional dict page)."""
        for p in self.pages:
            if p.page_type in (PT_DATA_PAGE, PT_DATA_PAGE_V2):
                return p.offset
        return self.file_offset


@dataclass
class RowGroupMeta:
    rg_idx:       int
    columns:      list[ColumnChunkMeta]
    num_rows:     int
    file_offset:  int
    total_bytes:  int


def _assemble_row_groups(pages: list[PageInfo]) -> list[RowGroupMeta]:
    """Group pages into column chunks and row groups.

    Strategy (HTC-specific):
    - A DICT_PAGE marks the START of column 0 (entity_id) → new row group, OR
      the start of columns 4/5 (event_type, simulation_id) within the current group.
    - Non-dict columns (tick, real_time_ms, lamport_tick, data) are split by
      matching row counts against the first dict-encoded column in the same group.
    - Uses DataPageHeaderV2.num_rows for precise row counting.
    """
    row_groups: list[RowGroupMeta] = []
    i = 0

    while i < len(pages):
        # ── Find start of a row group: DICT page ──────────────────────────────
        if pages[i].page_type != PT_DICT_PAGE:
            i += 1
            continue

        rg_start = i
        rg_file_offset = pages[i].offset

        # ── Collect all pages up to the next "row group boundary" ─────────────
        # A new row group begins when we see a DICT page AFTER the 6th column
        # (simulation_id) or after 'data' column (col 6) pages.
        # We use a two-pass approach:
        #   Pass 1: collect a "candidate" block of pages
        #   Pass 2: split into 7 column chunks using row-count matching

        # Collect pages for columns 0..5 (stop when we see the 3rd DICT page,
        # which belongs to the NEXT row group's col 0, not the current one)
        candidate: list[PageInfo] = []
        dict_count = 0
        j = i
        while j < len(pages):
            p = pages[j]
            if p.page_type == PT_DICT_PAGE:
                dict_count += 1
                # The 4th DICT page is the start of the next row group (col 0)
                # because this row group only has 3 dict columns (0, 4, 5)
                if dict_count > 3:
                    break
            candidate.append(p)
            j += 1

        if not candidate:
            i += 1
            continue

        i = j  # advance main pointer past this row group's pages

        # ── Split candidate pages into 7 column chunks ────────────────────────
        chunks = _split_into_columns(candidate)
        if not chunks or len(chunks) < NUM_COLS:
            # Incomplete row group (e.g., at truncation boundary) — skip
            continue

        num_rows = max(c.num_rows for c in chunks)
        total_bytes = sum(c.total_comp_size + c.total_header_size for c in chunks)

        row_groups.append(RowGroupMeta(
            rg_idx=len(row_groups),
            columns=chunks,
            num_rows=num_rows,
            file_offset=rg_file_offset,
            total_bytes=total_bytes,
        ))

    return row_groups


def _split_into_columns(pages: list[PageInfo]) -> list[ColumnChunkMeta]:
    """Split a flat list of pages (one row group) into 7 ColumnChunkMeta objects.

    Layout within a row group:
        col 0 (entity_id):    DICT + DATA_V2*  (RLE_DICT)
        col 1 (tick):                DATA_V2*  (DELTA_BINARY)
        col 2 (real_time_ms):        DATA_V2*  (DELTA_BINARY)
        col 3 (lamport_tick):        DATA_V2*  (DELTA_BINARY)
        col 4 (event_type):   DICT + DATA_V2*  (RLE_DICT)
        col 5 (simulation_id):DICT + DATA_V2*  (RLE_DICT)
        col 6 (data):                DATA_V2*  (PLAIN / RLE_DICT)
    """
    # Find DICT page positions to use as anchors
    dict_positions = [idx for idx, p in enumerate(pages) if p.page_type == PT_DICT_PAGE]

    if len(dict_positions) < 3:
        # Need at least 3 DICT pages (cols 0, 4, 5) to reconstruct 7 columns
        return []

    # dict_positions[0] → col 0 (entity_id)
    # dict_positions[1] → col 4 (event_type)
    # dict_positions[2] → col 5 (simulation_id)
    dict_0, dict_4, dict_5 = dict_positions[0], dict_positions[1], dict_positions[2]

    # Slices of pages per column:
    # col 0: pages[dict_0 .. dict_4)  includes dict + data pages for entity_id + tick + rt + lamport
    # col 4: pages[dict_4 .. dict_5)
    # col 5: pages[dict_5 .. end)
    # BUT cols 1/2/3 are INSIDE the col-0 slice.  Split them by row count.

    col_0_and_ints = pages[dict_0 : dict_4]
    col_4_pages    = pages[dict_4 : dict_5]
    col_5_and_data = pages[dict_5 :]

    # Get row count for the group from col 4 (event_type) — it's a clear anchor
    rg_rows = _sum_rows(col_4_pages)
    if rg_rows == 0:
        # Fall back: use col 5
        rg_rows = _sum_rows(col_5_and_data)

    # Split col_0_and_ints into col 0 (dict-encoded) + cols 1, 2, 3 (delta)
    col_0_pages, int_pages = _split_dict_then_plain(col_0_and_ints, target_rows=rg_rows)

    # Split int_pages into 3 equal-row-count chunks (tick, real_time_ms, lamport_tick)
    int_chunks = _split_equal_row_chunks(int_pages, n=3, target_rows=rg_rows)

    # Split col_5_and_data into col 5 (simulation_id, dict-encoded) + col 6 (data, plain)
    col_5_pages, col_6_pages = _split_dict_then_plain(col_5_and_data, target_rows=rg_rows)

    all_col_pages = (
        [col_0_pages]
        + int_chunks
        + [col_4_pages, col_5_pages, col_6_pages]
    )

    if len(all_col_pages) != NUM_COLS:
        return []

    chunks = []
    for col_idx, col_pages in enumerate(all_col_pages):
        if not col_pages:
            return []
        has_dict = col_pages[0].page_type == PT_DICT_PAGE
        total_comp   = sum(p.compressed_size  for p in col_pages)
        total_uncomp = sum(p.uncompressed_size for p in col_pages)
        total_hdrs   = sum(p.header_size       for p in col_pages)
        num_vals     = _sum_values(col_pages)
        num_rows     = _sum_rows(col_pages)

        chunks.append(ColumnChunkMeta(
            col_idx=col_idx,
            file_offset=col_pages[0].offset,
            total_header_size=total_hdrs,
            total_comp_size=total_comp,
            total_uncomp_size=total_uncomp,
            num_values=num_vals,
            num_rows=max(num_rows, rg_rows),
            has_dict_page=has_dict,
            pages=col_pages,
        ))
    return chunks


def _sum_rows(pages: list[PageInfo]) -> int:
    return sum(
        p.data_v2_hdr.num_rows
        for p in pages
        if p.data_v2_hdr is not None
    )

def _sum_values(pages: list[PageInfo]) -> int:
    return sum(
        p.data_v2_hdr.num_values
        for p in pages
        if p.data_v2_hdr is not None
    )


def _split_dict_then_plain(pages: list[PageInfo],
                            target_rows: int) -> tuple[list[PageInfo], list[PageInfo]]:
    """Split pages into (dict-encoded column, remaining).

    The dict-encoded column starts with a DICT page and collects DATA_V2 pages
    until the cumulative row count reaches *target_rows*.
    """
    if not pages or pages[0].page_type != PT_DICT_PAGE:
        return [], pages

    dict_col, rest = [pages[0]], []
    cum_rows = 0
    for p in pages[1:]:
        if cum_rows >= target_rows and p.page_type == PT_DICT_PAGE:
            rest = pages[pages.index(p):]
            break
        dict_col.append(p)
        if p.data_v2_hdr is not None:
            cum_rows += p.data_v2_hdr.num_rows

    return dict_col, rest


def _split_equal_row_chunks(pages: list[PageInfo],
                              n: int,
                              target_rows: int) -> list[list[PageInfo]]:
    """Split *pages* into *n* equal-row-count groups (for tick/rt_ms/lamport)."""
    if n == 0:
        return []
    rows_per_chunk = max(1, target_rows // n)
    chunks: list[list[PageInfo]] = []
    current: list[PageInfo] = []
    cum = 0
    for p in pages:
        current.append(p)
        if p.data_v2_hdr is not None:
            cum += p.data_v2_hdr.num_rows
        if cum >= rows_per_chunk and len(chunks) < n - 1:
            chunks.append(current)
            current = []
            cum = 0
    if current:
        chunks.append(current)
    # Pad if needed
    while len(chunks) < n:
        chunks.append([])
    return chunks[:n]


# ── Thrift compact footer writer ───────────────────────────────────────────────

def _write_varint(n: int) -> bytes:
    out = []
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            break
    return bytes(out)

def _zigzag_i32(n: int) -> bytes:
    return _write_varint(((n << 1) ^ (n >> 31)) & 0xFFFFFFFF)

def _zigzag_i64(n: int) -> bytes:
    return _write_varint(((n << 1) ^ (n >> 63)) & 0xFFFFFFFFFFFFFFFF)

def _tc_field(fid_delta: int, ftype: int) -> bytes:
    """Emit a Thrift compact field header using delta encoding (delta 1–15)."""
    if 1 <= fid_delta <= 15:
        return bytes([(fid_delta << 4) | ftype])
    raise ValueError(f"Field delta {fid_delta} out of range for compact shorthand")

def _tc_i32(fid_delta: int, value: int) -> bytes:
    return _tc_field(fid_delta, TC_I32) + _zigzag_i32(value)

def _tc_i64(fid_delta: int, value: int) -> bytes:
    return _tc_field(fid_delta, TC_I64) + _zigzag_i64(value)

def _tc_binary(fid_delta: int, value: str | bytes) -> bytes:
    if isinstance(value, str):
        value = value.encode()
    return _tc_field(fid_delta, TC_BINARY) + _write_varint(len(value)) + value

def _tc_list_of_structs(fid_delta: int, items: list[bytes]) -> bytes:
    # List header: (size << 4) | element_type
    size = len(items)
    if size < 15:
        list_hdr = bytes([(size << 4) | TC_STRUCT])
    else:
        list_hdr = bytes([0xF0 | TC_STRUCT]) + _write_varint(size)
    return _tc_field(fid_delta, TC_LIST) + list_hdr + b"".join(items)

def _tc_stop() -> bytes:
    return b"\x00"


def _encode_schema_elements() -> bytes:
    """Encode the HTC Avro schema as a list<SchemaElement> in Thrift compact."""
    # parquet SchemaElement:
    #  1: optional Type type
    #  2: optional i32  type_length
    #  3: optional FieldRepetitionType repetition_type
    #  4: required string name
    #  5: optional i32  num_children
    #  ...
    # Type enum: BOOLEAN=0 INT32=1 INT64=2 ... BYTE_ARRAY=6
    # FieldRepetitionType: REQUIRED=0 OPTIONAL=1 REPEATED=2

    elements = []

    # Message schema (root)
    msg = (
        _tc_i32(5, 7)            # num_children = 7 (fid=5, delta=5 from last=0)
        + _tc_binary(1, "spark_schema")  # name (fid=4 in spec but we use delta encoding)
        + _tc_stop()
    )
    # Build root element: fields 4 (name) and 5 (num_children)
    root = b""
    root += bytes([(5 << 4) | TC_I32]) + _zigzag_i32(7)         # field 5 = num_children
    root += bytes([(15 << 4) | 0])                                # cannot do delta>15; use full
    # Use absolute field id for name (field 4)
    root = (
        bytes([0x00, TC_I32]) + _zigzag_i32(5) + _zigzag_i32(7)  # fid=5, num_children=7
        + bytes([0x00, TC_BINARY])                                  # fid=4, name
        + _write_varint(len(b"schema")) + b"schema"
        + _tc_stop()
    )
    elements.append(root)

    # Column elements
    col_types = [
        ("entity_id",     6, 0),   # BYTE_ARRAY, REQUIRED
        ("tick",          2, 0),   # INT64, REQUIRED
        ("real_time_ms",  2, 0),
        ("lamport_tick",  2, 0),
        ("event_type",    6, 1),   # BYTE_ARRAY, OPTIONAL
        ("simulation_id", 6, 0),
        ("data",          6, 1),   # BYTE_ARRAY, OPTIONAL
    ]
    for name, ptype, rep in col_types:
        name_b = name.encode()
        elem = (
            bytes([0x00, TC_I32]) + _zigzag_i32(1) + _zigzag_i32(ptype)
            + bytes([0x00, TC_I32]) + _zigzag_i32(3) + _zigzag_i32(rep)
            + bytes([0x00, TC_BINARY]) + _write_varint(len(name_b)) + name_b
            + _tc_stop()
        )
        elements.append(elem)

    # Encode as a Thrift list<struct> using direct size+type header
    size = len(elements)
    list_hdr = bytes([(size << 4) | TC_STRUCT]) if size < 15 else (
        bytes([0xF0 | TC_STRUCT]) + _write_varint(size)
    )
    return list_hdr + b"".join(elements)


def _encode_column_chunk(col: ColumnChunkMeta) -> bytes:
    """Encode a ColumnChunk + ColumnMetaData in Thrift compact."""
    # ColumnMetaData fields (thrift field ids):
    #  1: type (Type enum)        2: encodings (list<Encoding>)
    #  3: path_in_schema          4: codec (CompressionCodec)
    #  5: num_values              6: total_uncompressed_size
    #  7: total_compressed_size   8: key_value_metadata
    #  9: data_page_offset       10: index_page_offset
    # 11: dictionary_page_offset  ...
    #
    # CompressionCodec: UNCOMPRESSED=0, SNAPPY=1, GZIP=2, LZO=3, BROTLI=4, LZ4=5, ZSTD=6
    # Type: BOOLEAN=0, INT32=1, INT64=2, INT96=3, FLOAT=4, DOUBLE=5, BYTE_ARRAY=6
    # Encoding: PLAIN=0, PLAIN_DICTIONARY=2, RLE=3, DELTA_BINARY_PACKED=5, RLE_DICTIONARY=8

    name, uses_dict, nullable = HTC_COLUMNS[col.col_idx]
    col_type   = 6 if col.col_idx in (0, 4, 5, 6) else 2   # BYTE_ARRAY or INT64

    # path_in_schema: list<string>
    path_b = name.encode()
    path_list = bytes([0x10 | TC_BINARY]) + _write_varint(len(path_b)) + path_b

    # encodings: list<Encoding>  (1 or 2 values)
    enc_vals = [ENC_RLE_DICT, ENC_PLAIN] if uses_dict else [ENC_DELTA_BINARY, ENC_PLAIN]
    enc_size = len(enc_vals)
    enc_list = (bytes([(enc_size << 4) | TC_I32]) +
                b"".join(_zigzag_i32(e) for e in enc_vals))

    data_page_offset = col.data_page_offset
    dict_page_offset = col.file_offset if col.has_dict_page else 0

    col_meta = (
        bytes([0x00, TC_I32]) + _zigzag_i32(1) + _zigzag_i32(col_type)
        + bytes([0x00, TC_LIST]) + _zigzag_i32(2) + enc_list
        + bytes([0x00, TC_LIST]) + _zigzag_i32(3) + path_list
        + bytes([0x00, TC_I32]) + _zigzag_i32(4) + _zigzag_i32(1)  # SNAPPY
        + bytes([0x00, TC_I64]) + _zigzag_i32(5) + _zigzag_i64(col.num_values)
        + bytes([0x00, TC_I64]) + _zigzag_i32(6) + _zigzag_i64(col.total_uncomp_size)
        + bytes([0x00, TC_I64]) + _zigzag_i32(7) + _zigzag_i64(col.total_comp_size)
        + bytes([0x00, TC_I64]) + _zigzag_i32(9) + _zigzag_i64(data_page_offset)
    )
    if col.has_dict_page:
        col_meta += bytes([0x00, TC_I64]) + _zigzag_i32(11) + _zigzag_i64(dict_page_offset)
    col_meta += _tc_stop()

    # ColumnChunk: field 2 (file_offset), field 3 (meta_data struct)
    chunk = (
        bytes([0x00, TC_I64]) + _zigzag_i32(2) + _zigzag_i64(col.file_offset)
        + bytes([0x00, TC_STRUCT]) + _zigzag_i32(3) + col_meta
        + _tc_stop()
    )
    return chunk


def _encode_row_group(rg: RowGroupMeta) -> bytes:
    """Encode a RowGroup in Thrift compact."""
    # RowGroup fields:
    #  1: columns (list<ColumnChunk>)
    #  2: total_byte_size (i64)
    #  3: num_rows (i64)
    col_structs = [_encode_column_chunk(c) for c in rg.columns]
    size = len(col_structs)
    col_list = (
        (bytes([(size << 4) | TC_STRUCT]) if size < 15
         else bytes([0xF0 | TC_STRUCT]) + _write_varint(size))
        + b"".join(col_structs)
    )

    rg_bytes = (
        bytes([0x00, TC_LIST]) + _zigzag_i32(1) + col_list
        + bytes([0x00, TC_I64]) + _zigzag_i32(2) + _zigzag_i64(rg.total_bytes)
        + bytes([0x00, TC_I64]) + _zigzag_i32(3) + _zigzag_i64(rg.num_rows)
        + _tc_stop()
    )
    return rg_bytes


def build_footer(row_groups: list[RowGroupMeta], total_rows: int) -> bytes:
    """Build a complete Parquet footer (FileMetaData encoded as Thrift compact)."""
    schema_list = _encode_schema_elements()
    rg_structs  = [_encode_row_group(rg) for rg in row_groups]
    n_rg = len(rg_structs)
    rg_list = (
        (bytes([(n_rg << 4) | TC_STRUCT]) if n_rg < 15
         else bytes([0xF0 | TC_STRUCT]) + _write_varint(n_rg))
        + b"".join(rg_structs)
    )

    # FileMetaData:
    #  1: version (i32)
    #  2: schema (list<SchemaElement>)
    #  3: num_rows (i64)
    #  4: row_groups (list<RowGroup>)
    # 13: created_by (string)
    created_by = b"htc-repair-1.0"
    file_meta = (
        bytes([0x00, TC_I32]) + _zigzag_i32(1) + _zigzag_i32(2)   # version=2
        + bytes([0x00, TC_LIST]) + _zigzag_i32(2) + schema_list
        + bytes([0x00, TC_I64]) + _zigzag_i32(3) + _zigzag_i64(total_rows)
        + bytes([0x00, TC_LIST]) + _zigzag_i32(4) + rg_list
        + bytes([0x00, TC_BINARY]) + _zigzag_i32(13)
        + _write_varint(len(created_by)) + created_by
        + _tc_stop()
    )
    footer_len = struct.pack("<I", len(file_meta))
    return file_meta + footer_len + MAGIC


# ── High-level repair ──────────────────────────────────────────────────────────

def is_truncated(path: Path) -> bool:
    """Return True if the file is missing the Parquet footer magic bytes."""
    try:
        with open(path, "rb") as f:
            if f.seek(0, 2) < 8:
                return True
            f.seek(-4, 2)
            return f.read(4) != MAGIC
    except OSError:
        return True


def repair_file(input_path: Path, output_path: Path, *, dry_run: bool = False) -> bool:
    """Repair one truncated Parquet file.

    Returns True on success, False on failure.
    """
    _log(f"Repairing: {input_path.name}  ({input_path.stat().st_size / 1e9:.2f} GB)")

    t0 = time.monotonic()
    with open(input_path, "rb") as f:
        data = f.read()

    if data[:4] != MAGIC:
        _log(f"  [SKIP] Not a Parquet file (missing opening PAR1 magic)", "WARN")
        return False

    if data[-4:] == MAGIC:
        _log(f"  [SKIP] File already has a valid footer — no repair needed", "INFO")
        if not dry_run:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            import shutil; shutil.copy2(input_path, output_path)
        return True

    _log(f"  Scanning pages …")
    pages = scan_pages(data)
    _log(f"  Found {len(pages)} pages  ({time.monotonic()-t0:.1f}s)")

    if not pages:
        _log(f"  [FAIL] No valid Parquet pages found — file may be entirely corrupted", "ERROR")
        return False

    _log(f"  Assembling row groups …")
    row_groups = _assemble_row_groups(pages)
    _log(f"  Found {len(row_groups)} complete row group(s)")

    if not row_groups:
        _log(f"  [FAIL] Could not reconstruct any row groups", "ERROR")
        return False

    total_rows = sum(rg.num_rows for rg in row_groups)
    _log(f"  Total rows (estimated): {total_rows:,}")

    if dry_run:
        _log(f"  [DRY-RUN] Would write repaired file to: {output_path}")
        return True

    footer = build_footer(row_groups, total_rows)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "wb") as out:
        out.write(data)
        out.write(footer)

    elapsed = time.monotonic() - t0
    _log(f"  Written: {output_path.name}  ({elapsed:.1f}s)")

    # Quick validation: try to open with pyarrow
    try:
        pf = pq.ParquetFile(output_path)
        n = pf.metadata.num_row_groups
        _log(f"  Validation OK — pyarrow sees {n} row group(s)")
        return True
    except Exception as exc:
        _log(f"  [WARN] pyarrow validation failed: {exc}  "
             f"(footer may be approximate — try DuckDB or Spark)", "WARN")
        return False


# ── CLI ────────────────────────────────────────────────────────────────────────

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Recover data from truncated HTC Parquet files (missing footer)."
    )
    p.add_argument("input",     help="Path to a .parquet file or directory")
    p.add_argument("--out",     default=None,
                   help="Output directory (default: <input_dir>/repaired/)")
    p.add_argument("--workers", type=int, default=1,
                   help="Parallel worker processes (default: 1)")
    p.add_argument("--overwrite", action="store_true",
                   help="Overwrite existing repaired files")
    p.add_argument("--dry-run", action="store_true",
                   help="Analyse files without writing output")
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    input_path = Path(args.input).expanduser().resolve()

    if input_path.is_file():
        files = [input_path]
        out_dir = Path(args.out) if args.out else input_path.parent / "repaired"
    elif input_path.is_dir():
        files = sorted(input_path.rglob("*.parquet"))
        out_dir = Path(args.out) if args.out else input_path / "repaired"
    else:
        _log(f"Input path not found: {input_path}", "ERROR")
        raise SystemExit(1)

    _log(f"Found {len(files)} Parquet file(s) under {input_path}")

    truncated = [f for f in files if is_truncated(f)]
    ok        = [f for f in files if not is_truncated(f)]
    _log(f"Truncated (missing footer): {len(truncated)}  |  Already valid: {len(ok)}")

    if not truncated:
        _log("Nothing to repair.")
        return

    successes, failures = 0, 0
    for f in truncated:
        out = out_dir / f.name
        if not args.overwrite and out.exists():
            _log(f"  [SKIP] Already exists: {out.name}  (use --overwrite to force)")
            continue
        ok = repair_file(f, out, dry_run=args.dry_run)
        if ok:
            successes += 1
        else:
            failures += 1

    _log(f"Done. Repaired: {successes}  |  Failed: {failures}")
    if successes:
        _log(f"Repaired files are in: {out_dir}")
        _log(f"Run htc_report.py against that directory.")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3

"""Repair route fields in a generated HTC scenario.

This script is intentionally narrow:
  - It fixes BusStation actors whose `goingRoute` / `returningRoute` were
    serialized as null instead of an empty route map.
  - It reports SubwayStation garages with missing `linesRoute` data, but does
    not invent rail routes automatically.

By default it writes a repaired copy of the scenario to a sibling directory
named `<input>_repaired` so the original output remains untouched.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
from collections import defaultdict
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

try:
    import numpy as np
    from scipy.spatial import cKDTree
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components

    SCIPY_AVAILABLE = True
except Exception:
    SCIPY_AVAILABLE = False


@dataclass
class RepairStats:
    files_scanned: int = 0
    files_written: int = 0
    files_corrected: int = 0
    network_nodes_total: int = 0
    network_edges_total: int = 0
    bus_stations_total: int = 0
    bus_stations_repaired: int = 0
    bus_station_null_going_route: int = 0
    bus_station_null_returning_route: int = 0
    bus_stations_missing_network_nodes: int = 0
    bus_stations_disconnected_segments: int = 0
    bus_station_missing_nodes_total: int = 0
    bus_station_disconnected_segments_total: int = 0
    bus_stations_duplicate_node_segments: int = 0
    bus_station_duplicate_node_segments_total: int = 0
    bus_stations_connectivity_repaired: int = 0
    bus_stations_connectivity_unrepairable: int = 0
    bus_station_removed_stops_total: int = 0
    bus_stations_snapped: int = 0
    bus_stops_snapped_total: int = 0
    transit_routes_lines_updated: int = 0
    transit_routes_stops_removed_total: int = 0
    transit_map_entries_updated: int = 0
    subway_garages_total: int = 0
    subway_garages_missing_lines_route: int = 0
    bus_actor_files_dropped: int = 0
    simulation_bus_entries_removed: int = 0
    virtual_connector_links_added: int = 0
    bus_stations_bridge_connected: int = 0


@dataclass
class NetworkData:
    node_ids: np.ndarray
    weak_labels: np.ndarray
    strong_labels: np.ndarray
    latitudes: np.ndarray
    longitudes: np.ndarray


VERBOSE = False


def vlog(message: str) -> None:
    if VERBOSE:
        print(f"[repair] {message}", flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Repair route fields in a generated HTC scenario copy."
    )
    parser.add_argument(
        "--input-root",
        required=True,
        help="Path to the generated scenario root (the directory containing data/).",
    )
    parser.add_argument(
        "--output-root",
        default=None,
        help="Path to the repaired scenario root. Defaults to <input-root>_repaired.",
    )
    parser.add_argument(
        "--in-place",
        action="store_true",
        help="Apply the repair directly in the input root instead of creating a copy.",
    )
    parser.add_argument(
        "--report-only",
        action="store_true",
        help="Only generate the report; do not write any repaired files.",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print detailed progress logs while repairing.",
    )
    parser.add_argument(
        "--progress-every",
        type=int,
        default=50,
        help="How often (files) to print progress when --verbose is enabled.",
    )
    parser.add_argument(
        "--snap-max-distance-meters",
        type=float,
        default=120.0,
        help="Maximum distance (meters) to snap a bus stop to a nearby node in the dominant component.",
    )
    return parser.parse_args()


def iter_json_files(root: Path) -> Iterable[Path]:
    for path in sorted(root.rglob("*.json")):
        if path.is_file():
            yield path


def iter_pattern_files(root: Path, pattern: str) -> Iterable[Path]:
    for path in sorted(root.rglob(pattern)):
        if path.is_file():
            yield path


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def safe_hardlink_or_copy(src: Path, dst: Path) -> None:
    ensure_parent(dst)
    try:
        if dst.exists():
            dst.unlink()
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)


def suffix_to_int(entity_id: str) -> int:
    try:
        return int(entity_id.rsplit(";", 1)[1])
    except Exception as exc:
        raise ValueError(f"Cannot parse numeric suffix from id: {entity_id}") from exc


def load_network_components(input_root: Path) -> tuple[NetworkData, RepairStats] | None:
    if not SCIPY_AVAILABLE:
        return None

    nodes_dir = input_root / "data"
    node_id_chunks: List[np.ndarray] = []
    node_lat_chunks: List[np.ndarray] = []
    node_lon_chunks: List[np.ndarray] = []
    edge_src_chunks: List[np.ndarray] = []
    edge_dst_chunks: List[np.ndarray] = []
    stats = RepairStats()
    vlog("Loading nodes and links to build connectivity index")

    for src in iter_pattern_files(nodes_dir, "nodes_*.json"):
        with src.open() as fh:
            data = json.load(fh)
        if not isinstance(data, list):
            continue
        ids: List[int] = []
        lats: List[float] = []
        lons: List[float] = []
        for actor in data:
            if not isinstance(actor, dict) or not actor.get("id"):
                continue
            content = actor.get("data", {}).get("content", {})
            lat = content.get("latitude")
            lon = content.get("longitude")
            if lat is None or lon is None:
                continue
            ids.append(suffix_to_int(actor["id"]))
            lats.append(float(lat))
            lons.append(float(lon))
        if ids:
            node_id_chunks.append(np.array(ids, dtype=np.int64))
            node_lat_chunks.append(np.array(lats, dtype=np.float64))
            node_lon_chunks.append(np.array(lons, dtype=np.float64))

    for src in iter_pattern_files(nodes_dir, "links_*.json"):
        with src.open() as fh:
            data = json.load(fh)
        if not isinstance(data, list):
            continue
        src_values = []
        dst_values = []
        for actor in data:
            if not isinstance(actor, dict):
                continue
            content = actor.get("data", {}).get("content", {})
            from_id = content.get("from")
            to_id = content.get("to")
            if from_id is None or to_id is None:
                continue
            src_values.append(suffix_to_int(from_id))
            dst_values.append(suffix_to_int(to_id))
        if src_values:
            edge_src_chunks.append(np.array(src_values, dtype=np.int64))
            edge_dst_chunks.append(np.array(dst_values, dtype=np.int64))

    if not node_id_chunks or not edge_src_chunks:
        return None

    node_ids_raw = np.concatenate(node_id_chunks)
    node_lats_raw = np.concatenate(node_lat_chunks)
    node_lons_raw = np.concatenate(node_lon_chunks)

    sort_idx = np.argsort(node_ids_raw)
    node_ids_sorted = node_ids_raw[sort_idx]
    node_lats_sorted = node_lats_raw[sort_idx]
    node_lons_sorted = node_lons_raw[sort_idx]

    unique_ids, unique_first_idx = np.unique(node_ids_sorted, return_index=True)
    node_ids = unique_ids
    node_lats = node_lats_sorted[unique_first_idx]
    node_lons = node_lons_sorted[unique_first_idx]

    edge_src = np.concatenate(edge_src_chunks)
    edge_dst = np.concatenate(edge_dst_chunks)

    node_index = np.searchsorted(node_ids, edge_src)
    dst_index = np.searchsorted(node_ids, edge_dst)

    if np.any(node_index >= node_ids.size) or not np.array_equal(node_ids[node_index], edge_src):
        raise SystemExit("Some link source ids are missing from nodes_*.json")
    if np.any(dst_index >= node_ids.size) or not np.array_equal(node_ids[dst_index], edge_dst):
        raise SystemExit("Some link target ids are missing from nodes_*.json")

    stats.network_nodes_total = int(node_ids.size)
    stats.network_edges_total = int(edge_src.size)

    matrix = coo_matrix(
        (
            np.ones(edge_src.size, dtype=np.uint8),
            (node_index, dst_index),
        ),
        shape=(node_ids.size, node_ids.size),
    )
    _, weak_labels = connected_components(matrix, directed=False, connection="weak", return_labels=True)
    _, strong_labels = connected_components(matrix, directed=True, connection="strong", return_labels=True)

    vlog(f"Network index ready: {node_ids.size} nodes, {edge_src.size} edges")
    return NetworkData(
        node_ids=node_ids,
        weak_labels=weak_labels,
        strong_labels=strong_labels,
        latitudes=node_lats,
        longitudes=node_lons,
    ), stats


def component_for_node(node_id: str, network: NetworkData, mode: str = "weak") -> int | None:
    numeric_id = suffix_to_int(node_id)
    index = np.searchsorted(network.node_ids, numeric_id)
    if index >= network.node_ids.size or int(network.node_ids[index]) != numeric_id:
        return None
    labels = network.weak_labels if mode == "weak" else network.strong_labels
    return int(labels[index])


def ordered_bus_stop_ids(bus_stops: Dict[str, str]) -> List[str]:
    # Mirror the actor ordering logic (numeric suffix, fallback lexicographic)
    # so repair decisions match runtime route segment checks.
    def suffix_number(stop_id: str) -> tuple[int, int, str]:
        digits = ""
        i = len(stop_id) - 1
        while i >= 0 and stop_id[i].isdigit():
            digits = stop_id[i] + digits
            i -= 1
        if digits:
            return (0, int(digits), stop_id)
        return (1, 2**63 - 1, stop_id)

    return sorted(bus_stops.keys(), key=suffix_number)


def node_lat_lon(node_id: str, network: NetworkData) -> tuple[float, float] | None:
    numeric_id = suffix_to_int(node_id)
    index = np.searchsorted(network.node_ids, numeric_id)
    if index >= network.node_ids.size or int(network.node_ids[index]) != numeric_id:
        return None
    return float(network.latitudes[index]), float(network.longitudes[index])


def haversine_meters(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371000.0
    p1 = np.radians(lat1)
    p2 = np.radians(lat2)
    dp = np.radians(lat2 - lat1)
    dl = np.radians(lon2 - lon1)
    a = np.sin(dp / 2.0) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2.0) ** 2
    return float(2.0 * r * np.arctan2(np.sqrt(a), np.sqrt(1.0 - a)))


def nearest_node_in_component(
    lat: float,
    lon: float,
    component_id: int,
    network: NetworkData,
    tree_cache: Dict[int, tuple[cKDTree, np.ndarray]],
    max_distance_m: float,
) -> str | None:
    if component_id not in tree_cache:
        idx = np.flatnonzero(network.weak_labels == component_id)
        if idx.size == 0:
            return None
        coords = np.column_stack((network.latitudes[idx], network.longitudes[idx]))
        tree_cache[component_id] = (cKDTree(coords), idx)

    tree, idx = tree_cache[component_id]
    distance, pos = tree.query(np.array([lat, lon]), k=1)
    nearest_idx = idx[int(pos)]
    nearest_lat = float(network.latitudes[nearest_idx])
    nearest_lon = float(network.longitudes[nearest_idx])
    meters = haversine_meters(lat, lon, nearest_lat, nearest_lon)
    if meters > max_distance_m:
        return None
    return f"htcaid:node;{int(network.node_ids[nearest_idx])}"


def components_for_node(node_id: str, network: NetworkData) -> tuple[int | None, int | None]:
    """Return (weak_component, strong_component) for a node in a single binary search."""
    numeric_id = suffix_to_int(node_id)
    index = np.searchsorted(network.node_ids, numeric_id)
    if index >= network.node_ids.size or int(network.node_ids[index]) != numeric_id:
        return None, None
    return int(network.weak_labels[index]), int(network.strong_labels[index])


def nearest_node_in_strong_component(
    lat: float,
    lon: float,
    component_id: int,
    network: NetworkData,
    strong_tree_cache: Dict[int, tuple[cKDTree, np.ndarray]],
) -> str | None:
    """Return the geographically nearest node in the given STRONG component (no distance limit)."""
    if component_id not in strong_tree_cache:
        idx = np.flatnonzero(network.strong_labels == component_id)
        if idx.size == 0:
            return None
        coords = np.column_stack((network.latitudes[idx], network.longitudes[idx]))
        strong_tree_cache[component_id] = (cKDTree(coords), idx)
    tree, idx = strong_tree_cache[component_id]
    _, pos = tree.query(np.array([lat, lon]), k=1)
    nearest_idx = idx[int(pos)]
    return f"htcaid:node;{int(network.node_ids[nearest_idx])}"


def build_connector_link_actors(
    from_id: str,
    to_id: str,
    network: NetworkData,
) -> list[Dict[str, Any]]:
    """Build a bidirectional pair of virtual connector link actors bridging two nodes."""
    from_coord = node_lat_lon(from_id, network)
    to_coord = node_lat_lon(to_id, network)
    if from_coord is None or to_coord is None:
        return []
    length = max(1.0, haversine_meters(from_coord[0], from_coord[1], to_coord[0], to_coord[1]))
    speed = 13.89  # 50 km/h in m/s
    from_num = suffix_to_int(from_id)
    to_num = suffix_to_int(to_id)

    def _actor(src_id: str, dst_id: str, src_num: int, dst_num: int) -> Dict[str, Any]:
        return {
            "id": f"htcaid:link;vconn_{src_num}_{dst_num}",
            "typeActor": "hybrid.actor.Link",
            "data": {
                "dataType": "model.hybrid.entity.state.LinkState",
                "content": {
                    "startTick": 0,
                    "from": src_id,
                    "to": dst_id,
                    "length": round(length, 2),
                    "lanes": 1,
                    "speedLimit": speed,
                    "freeSpeed": speed,
                    "capacity": 600.0,
                    "simulationMode": "MESO",
                    "microTimeStep": 0.1,
                    "microTicksPerGlobalTick": 10,
                    "laneConfigurations": [{"laneId": 0, "type": "normal", "width": 3.5, "speedLimit": None}],
                    "linkType": "connector",
                    "congestionFactor": 1.0,
                    "currentSpeed": speed,
                    "registered": [],
                    "vehiclesByLane": {},
                    "modes": ["car", "pt", "bike"],
                    "name": f"vconn_{src_num}_{dst_num}",
                },
            },
            "dependencies": {
                "from_node": {"id": src_id, "classType": "hybrid.actor.Node"},
                "to_node":   {"id": dst_id, "classType": "hybrid.actor.Node"},
            },
        }

    return [
        _actor(from_id, to_id, from_num, to_num),
        _actor(to_id, from_id, to_num, from_num),
    ]


def write_connector_links_file(
    output_root: Path,
    connector_links: Dict[tuple[str, str], Dict[str, Any]],
    stats: RepairStats,
    report: Dict[str, List[Any]],
) -> None:
    """Write all virtual connector links to data/links_connector.json and patch simulation.json."""
    if not connector_links:
        return

    actors = list(connector_links.values())
    connector_path = output_root / "data" / "links_connector.json"
    ensure_parent(connector_path)
    with connector_path.open("w") as fh:
        json.dump(actors, fh, separators=(",", ":"))
    stats.virtual_connector_links_added = len(actors)
    report["correctedFiles"].append("data/links_connector.json")
    vlog(f"Wrote {len(actors)} virtual connector links → data/links_connector.json")

    # Patch simulation config files — only look for simulation*.json, not all json files.
    for config_file in sorted(output_root.rglob("simulation*.json")):
        if not config_file.is_file():
            continue
        try:
            with config_file.open() as fh:
                cfg_data = json.load(fh)
        except Exception:
            continue
        if not isinstance(cfg_data, dict) or "actorsDataSources" not in cfg_data:
            continue
        sources = cfg_data["actorsDataSources"]
        # Skip if already registered.
        if any(
            isinstance(s, dict)
            and s.get("dataSource", {}).get("info", {}).get("path", "").endswith("links_connector.json")
            for s in sources
        ):
            continue
        # Derive the Docker base path from an existing links entry.
        base_path: str | None = None
        for s in sources:
            if not isinstance(s, dict):
                continue
            path_val = s.get("dataSource", {}).get("info", {}).get("path", "")
            if "/links_" in path_val and path_val.endswith(".json"):
                base_path = path_val.rsplit("/links_", 1)[0]
                break
        if base_path is None:
            vlog(f"Could not derive base path for connector entry in {config_file.name}")
            continue
        new_entry = {
            "id": "links_connector",
            "classType": "hybrid.actor.Link",
            "creationType": "LoadBalancedDistributed",
            "loadingStrategy": "EAGER",
            "entityLifecycle": "STATIC",
            "dataSource": {
                "sourceType": "json",
                "info": {"path": f"{base_path}/links_connector.json"},
            },
        }
        cfg_data["actorsDataSources"].append(new_entry)
        with config_file.open("w") as fh:
            json.dump(cfg_data, fh, separators=(",", ":"))
        vlog(f"Patched {config_file.name} → added links_connector.json entry")


def station_line_id(actor: Dict[str, Any], content: Dict[str, Any]) -> str | None:
    name = content.get("name")
    if isinstance(name, str) and name.strip():
        # Example: "1012-10 (sptrans)" -> "1012-10"
        return name.split("(", 1)[0].strip()

    actor_id = actor.get("id")
    if isinstance(actor_id, str) and ";" in actor_id:
        suffix = actor_id.rsplit(";", 1)[1]
        if "_" in suffix:
            return suffix.split("_", 1)[1]
        return suffix
    return None


def bus_stop_actor_to_transit_stop_id(bus_stop_actor_id: str) -> str:
    suffix = bus_stop_actor_id.rsplit(";", 1)[1]
    return f"htcaid:stop;bus_{suffix}"


def repair_bus_station_actor(actor: Dict[str, Any], stats: RepairStats, report: Dict[str, List[Any]]) -> bool:
    content = actor.get("data", {}).get("content", {})
    if actor.get("typeActor") != "hybrid.actor.BusStation":
        return False

    stats.bus_stations_total += 1
    changed = False

    if content.get("goingRoute") is None:
        content["goingRoute"] = {}
        stats.bus_station_null_going_route += 1
        changed = True
        report["busStationsMissingGoingRoute"].append(actor.get("id", ""))

    if content.get("returningRoute") is None:
        content["returningRoute"] = {}
        stats.bus_station_null_returning_route += 1
        changed = True
        report["busStationsMissingReturningRoute"].append(actor.get("id", ""))

    if changed:
        stats.bus_stations_repaired += 1

    return changed


def repair_bus_station_connectivity(
    actor: Dict[str, Any],
    network: NetworkData | None,
    stats: RepairStats,
    report: Dict[str, List[Any]],
    snap_max_distance_m: float,
    tree_cache: Dict[int, tuple[cKDTree, np.ndarray]],
    connector_links: Dict[tuple[str, str], Dict[str, Any]],
    strong_tree_cache: Dict[int, tuple[cKDTree, np.ndarray]],
) -> bool:
    if network is None:
        return False

    content = actor.get("data", {}).get("content", {})
    if actor.get("typeActor") != "hybrid.actor.BusStation":
        return False

    bus_stops = content.get("busStops", {})
    if not isinstance(bus_stops, dict) or len(bus_stops) < 2:
        return False

    ordered_ids = ordered_bus_stop_ids(bus_stops)

    # Build stop_entries fetching BOTH weak and strong components in one binary search per stop.
    stop_entries: List[Tuple[str, str, int | None, int | None]] = []
    for stop_id in ordered_ids:
        node_id = bus_stops.get(stop_id)
        if not isinstance(node_id, str):
            continue
        wc, sc = components_for_node(node_id, network)
        stop_entries.append((stop_id, node_id, wc, sc))

    valid_weak = [wc for _, _, wc, _ in stop_entries if wc is not None]
    if not valid_weak:
        stats.bus_stations_connectivity_unrepairable += 1
        report["busStationsConnectivityUnrepairable"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "reason": "all-stops-missing-from-network",
            }
        )
        return False
    dominant_component = max(set(valid_weak), key=valid_weak.count)

    # Try to snap out-of-component stops; update stop_entries in-place (no full rebuild).
    snapped_stops: List[Dict[str, Any]] = []
    for i, (stop_id, node_id, wc, sc) in enumerate(stop_entries):
        if wc == dominant_component:
            continue
        coord = node_lat_lon(node_id, network)
        if coord is None:
            continue
        replacement = nearest_node_in_component(
            lat=coord[0],
            lon=coord[1],
            component_id=int(dominant_component),
            network=network,
            tree_cache=tree_cache,
            max_distance_m=snap_max_distance_m,
        )
        if replacement is not None and replacement != node_id:
            bus_stops[stop_id] = replacement
            new_wc, new_sc = components_for_node(replacement, network)
            stop_entries[i] = (stop_id, replacement, new_wc, new_sc)
            snapped_stops.append({"stopActorId": stop_id, "oldNodeId": node_id, "newNodeId": replacement})

    if snapped_stops:
        stats.bus_stations_snapped += 1
        stats.bus_stops_snapped_total += len(snapped_stops)
        report["snappedBusStops"].extend(snapped_stops)
        report["busStationsConnectivitySnapped"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "snappedStops": len(snapped_stops),
            }
        )

    # Derive dominant strong component from stops already in the dominant weak component.
    strong_valid_base = [sc for _, _, wc, sc in stop_entries if wc == dominant_component and sc is not None]
    if not strong_valid_base:
        stats.bus_stations_connectivity_unrepairable += 1
        report["busStationsConnectivityUnrepairable"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "reason": "no-strongly-connected-stops-in-dominant-weak-component",
            }
        )
        return False
    dominant_strong = max(set(strong_valid_base), key=strong_valid_base.count)

    # Single unified pass: bridge weak-out AND strong-out stops, build strong_filtered.
    any_bridged = False
    strong_filtered: List[Tuple[str, str]] = []
    for stop_id, node_id, wc, sc in stop_entries:
        if wc == dominant_component and sc == dominant_strong:
            strong_filtered.append((stop_id, node_id))
            continue
        # Stop needs bridging (wrong weak or wrong strong component).
        coord = node_lat_lon(node_id, network)
        if coord is None:
            continue
        nearest = nearest_node_in_strong_component(
            coord[0], coord[1], int(dominant_strong), network, strong_tree_cache
        )
        if nearest and nearest != node_id:
            for actor_dict in build_connector_link_actors(node_id, nearest, network):
                k = (actor_dict["data"]["content"]["from"], actor_dict["data"]["content"]["to"])
                connector_links[k] = actor_dict
            strong_filtered.append((stop_id, node_id))
            any_bridged = True

    if len(strong_filtered) < 2:
        stats.bus_stations_connectivity_unrepairable += 1
        report["busStationsConnectivityUnrepairable"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "reason": "fewer-than-2-stops-after-connectivity-filter",
            }
        )
        return False

    duplicate_segments: List[Dict[str, Any]] = []
    deduped: List[Tuple[str, str]] = []
    for stop_id, node_id in strong_filtered:
        if deduped and deduped[-1][1] == node_id:
            duplicate_segments.append(
                {
                    "removedStopId": stop_id,
                    "keptPreviousStopId": deduped[-1][0],
                    "nodeId": node_id,
                }
            )
            continue
        deduped.append((stop_id, node_id))

    if len(deduped) < 2:
        stats.bus_stations_connectivity_unrepairable += 1
        report["busStationsConnectivityUnrepairable"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "reason": "fewer-than-2-stops-after-duplicate-node-dedup",
            }
        )
        return False

    original_len = len(bus_stops)
    if len(deduped) == original_len and not any_bridged:
        return False

    new_bus_stops = {stop_id: node_id for stop_id, node_id in deduped}
    content["busStops"] = new_bus_stops
    content["origin"] = deduped[0][1]
    content["destination"] = deduped[-1][1]
    # Force recomputation at runtime (stop sequence may have changed, or new
    # connector links were added to the network that the runtime router needs).
    content["goingRoute"] = {}
    content["returningRoute"] = {}

    removed = original_len - len(deduped)
    if any_bridged:
        stats.bus_stations_bridge_connected += 1
    stats.bus_stations_connectivity_repaired += 1
    stats.bus_station_removed_stops_total += removed
    if duplicate_segments:
        stats.bus_stations_duplicate_node_segments += 1
        stats.bus_station_duplicate_node_segments_total += len(duplicate_segments)
        report["busStationsDuplicateNodeSegmentsRepaired"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "duplicateSegmentsRemoved": len(duplicate_segments),
                "segments": duplicate_segments,
            }
        )
    report["busStationsConnectivityRepaired"].append(
        {
            "stationId": actor.get("id", ""),
            "stationName": content.get("name", ""),
            "removedStops": removed,
            "keptStops": len(deduped),
            "dominantComponent": int(dominant_component),
            "dominantStrongComponent": int(dominant_strong),
        }
    )

    line_id = station_line_id(actor, content)
    if line_id:
        report["repairedBusLines"].append(
            {
                "lineId": line_id,
                "stationId": actor.get("id", ""),
                "keptTransitStops": [
                    bus_stop_actor_to_transit_stop_id(stop_id) for stop_id, _ in deduped
                ],
            }
        )
    return True


def synchronize_transit_files(
    output_root: Path,
    stats: RepairStats,
    report: Dict[str, List[Any]],
) -> bool:
    repaired_lines = report.get("repairedBusLines", [])
    if not repaired_lines:
        return False

    routes_path = output_root / "data" / "transit_routes.json"
    transit_map_path = output_root / "data" / "transit_map.json"
    if not routes_path.exists() or not transit_map_path.exists():
        return False

    line_allowed_stops: Dict[str, set[str]] = {}
    for item in repaired_lines:
        line_id = item.get("lineId")
        stops = item.get("keptTransitStops", [])
        if not isinstance(line_id, str):
            continue
        current = line_allowed_stops.setdefault(line_id, set())
        current.update(s for s in stops if isinstance(s, str))

    with routes_path.open() as fh:
        routes_data = json.load(fh)
    if not isinstance(routes_data, list):
        return False

    routes_changed = False
    served_stops_by_line: Dict[str, set[str]] = defaultdict(set)
    for entry in routes_data:
        if not isinstance(entry, dict):
            continue
        if entry.get("stopType") != "bus":
            continue
        line_id = entry.get("lineId")
        if line_id not in line_allowed_stops:
            continue
        stops = entry.get("stops", [])
        if not isinstance(stops, list):
            continue

        allowed = line_allowed_stops[line_id]
        new_stops = [s for s in stops if isinstance(s, dict) and s.get("stopId") in allowed]
        if len(new_stops) >= 2 and len(new_stops) != len(stops):
            removed = len(stops) - len(new_stops)
            entry["stops"] = new_stops
            stats.transit_routes_lines_updated += 1
            stats.transit_routes_stops_removed_total += removed
            routes_changed = True
        for s in entry.get("stops", []):
            if isinstance(s, dict) and isinstance(s.get("stopId"), str):
                served_stops_by_line[line_id].add(s["stopId"])

    if routes_changed:
        with routes_path.open("w") as fh:
            json.dump(routes_data, fh, separators=(",", ":"))
        report["correctedFiles"].append("data/transit_routes.json")

    with transit_map_path.open() as fh:
        transit_map_data = json.load(fh)
    if not isinstance(transit_map_data, list):
        return routes_changed

    repaired_line_ids = set(line_allowed_stops.keys())
    snapped_map: Dict[str, str] = {}
    for snap in report.get("snappedBusStops", []):
        stop_actor_id = snap.get("stopActorId")
        new_node_id = snap.get("newNodeId")
        if isinstance(stop_actor_id, str) and isinstance(new_node_id, str):
            snapped_map[bus_stop_actor_to_transit_stop_id(stop_actor_id)] = new_node_id

    map_changed = False
    for entry in transit_map_data:
        if not isinstance(entry, dict):
            continue
        if entry.get("stopType") != "bus":
            continue
        lines = entry.get("lines")
        stop_id = entry.get("id")
        if not isinstance(lines, list) or not isinstance(stop_id, str):
            continue

        new_lines = []
        for line in lines:
            if not isinstance(line, str):
                continue
            if line in repaired_line_ids and stop_id not in served_stops_by_line.get(line, set()):
                continue
            new_lines.append(line)

        if new_lines != lines:
            entry["lines"] = new_lines
            stats.transit_map_entries_updated += 1
            map_changed = True

        replacement_node_id = snapped_map.get(stop_id)
        if replacement_node_id and entry.get("nodeId") != replacement_node_id:
            entry["nodeId"] = replacement_node_id
            stats.transit_map_entries_updated += 1
            map_changed = True

    if map_changed:
        with transit_map_path.open("w") as fh:
            json.dump(transit_map_data, fh, separators=(",", ":"))
        report["correctedFiles"].append("data/transit_map.json")

    return routes_changed or map_changed


def analyze_bus_station_connectivity(
    actor: Dict[str, Any],
    network: NetworkData | None,
    stats: RepairStats,
    report: Dict[str, List[Any]],
) -> None:
    if network is None:
        return

    content = actor.get("data", {}).get("content", {})
    if actor.get("typeActor") != "hybrid.actor.BusStation":
        return

    bus_stops = content.get("busStops", {})
    if not isinstance(bus_stops, dict) or len(bus_stops) < 2:
        return

    ordered_ids = ordered_bus_stop_ids(bus_stops)
    missing_nodes: List[str] = []
    disconnected_segments: List[str] = []
    duplicate_segments: List[str] = []

    # Single pass: build per-stop data and check all three conditions at once.
    node_ids_for_stops: List[Tuple[str, str]] = []  # (stop_id, node_id) with valid string node
    for stop_id in ordered_ids:
        node_id = bus_stops.get(stop_id)
        if not isinstance(node_id, str):
            continue
        node_ids_for_stops.append((stop_id, node_id))
        wc, _ = components_for_node(node_id, network)
        if wc is None:
            missing_nodes.append(node_id)

    for (left_stop, left_node), (right_stop, right_node) in zip(node_ids_for_stops, node_ids_for_stops[1:]):
        if left_node == right_node:
            duplicate_segments.append(f"{left_stop}->{right_stop}")
        else:
            _, lc = components_for_node(left_node, network)
            _, rc = components_for_node(right_node, network)
            if lc is None or rc is None or lc != rc:
                disconnected_segments.append(f"{left_stop}->{right_stop}")

    if missing_nodes:
        stats.bus_stations_missing_network_nodes += 1
        stats.bus_station_missing_nodes_total += len(missing_nodes)
        report["busStationsWithMissingNetworkNodes"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "missingNodes": missing_nodes,
            }
        )

    if disconnected_segments:
        stats.bus_stations_disconnected_segments += 1
        stats.bus_station_disconnected_segments_total += len(disconnected_segments)
        report["busStationsWithDisconnectedSegments"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "disconnectedSegments": disconnected_segments,
            }
        )

    if duplicate_segments:
        stats.bus_stations_duplicate_node_segments += 1
        stats.bus_station_duplicate_node_segments_total += len(duplicate_segments)
        report["busStationsWithDuplicateNodeSegments"].append(
            {
                "stationId": actor.get("id", ""),
                "stationName": content.get("name", ""),
                "duplicateSegments": duplicate_segments,
            }
        )


def inspect_subway_station_actor(actor: Dict[str, Any], stats: RepairStats, report: Dict[str, List[Any]]) -> None:
    content = actor.get("data", {}).get("content", {})
    if actor.get("typeActor") != "hybrid.actor.SubwayStation":
        return

    if not content.get("garage"):
        return

    stats.subway_garages_total += 1
    if not content.get("linesRoute"):
        stats.subway_garages_missing_lines_route += 1
        report["subwayGaragesMissingLinesRoute"].append(actor.get("id", ""))


def repair_json_file(
    src: Path,
    dst: Path,
    stats: RepairStats,
    report: Dict[str, List[Any]],
    network: NetworkData | None,
    rel_path: str,
    snap_max_distance_m: float,
    tree_cache: Dict[int, tuple[cKDTree, np.ndarray]],
    connector_links: Dict[tuple[str, str], Dict[str, Any]],
    strong_tree_cache: Dict[int, tuple[cKDTree, np.ndarray]],
) -> bool:
    changed = False
    with src.open() as fh:
        data = json.load(fh)

    if isinstance(data, list):
        # Drop files that consist entirely of pre-built Bus vehicle actors.
        # Bus actors must be created at runtime by BusStation; pre-loaded
        # Bus actors have null routes and will fail to navigate.
        if any(isinstance(a, dict) and a.get("typeActor") == "hybrid.actor.Bus" for a in data):
            stats.bus_actor_files_dropped += 1
            report["droppedBusActorFiles"].append(rel_path)
            vlog(f"Dropped Bus actor file: {rel_path}")
            return False

        for actor in data:
            if not isinstance(actor, dict):
                continue
            if actor.get("typeActor") == "hybrid.actor.BusStation":
                changed = repair_bus_station_actor(actor, stats, report) or changed
                changed = repair_bus_station_connectivity(
                    actor,
                    network,
                    stats,
                    report,
                    snap_max_distance_m,
                    tree_cache,
                    connector_links,
                    strong_tree_cache,
                ) or changed
                analyze_bus_station_connectivity(actor, network, stats, report)
            elif actor.get("typeActor") == "hybrid.actor.SubwayStation":
                inspect_subway_station_actor(actor, stats, report)

    elif isinstance(data, dict) and "actorsDataSources" in data:
        # Remove hybrid.actor.Bus source entries from simulation config files.
        sources_before = data["actorsDataSources"]
        sources_after = [s for s in sources_before if s.get("classType") != "hybrid.actor.Bus"]
        removed = len(sources_before) - len(sources_after)
        if removed:
            data["actorsDataSources"] = sources_after
            stats.simulation_bus_entries_removed += removed
            report["droppedBusActorFiles"].append(f"{rel_path} ({removed} entries removed)")
            vlog(f"Removed {removed} hybrid.actor.Bus source(s) from {rel_path}")
            changed = True

    if changed:
        ensure_parent(dst)
        with dst.open("w") as fh:
            json.dump(data, fh, separators=(",", ":"))
        stats.files_corrected += 1
        report["correctedFiles"].append(rel_path)
    else:
        safe_hardlink_or_copy(src, dst)

    return changed


def build_report(stats: RepairStats, report: Dict[str, List[Any]], input_root: Path, output_root: Path) -> Dict[str, Any]:
    return {
        "inputRoot": str(input_root),
        "outputRoot": str(output_root),
        "summary": asdict(stats),
        "details": {
            "busStationsMissingGoingRoute": report["busStationsMissingGoingRoute"][:50],
            "busStationsMissingReturningRoute": report["busStationsMissingReturningRoute"][:50],
            "busStationsWithMissingNetworkNodes": report["busStationsWithMissingNetworkNodes"][:50],
            "busStationsWithDisconnectedSegments": report["busStationsWithDisconnectedSegments"][:50],
            "busStationsConnectivityRepaired": report["busStationsConnectivityRepaired"][:50],
            "busStationsConnectivitySnapped": report.get("busStationsConnectivitySnapped", [])[:50],
            "busStationsConnectivityUnrepairable": report["busStationsConnectivityUnrepairable"][:50],
            "busStationsWithDuplicateNodeSegments": report.get("busStationsWithDuplicateNodeSegments", [])[:50],
            "busStationsDuplicateNodeSegmentsRepaired": report.get(
                "busStationsDuplicateNodeSegmentsRepaired", []
            )[:50],
            "repairedBusLines": report.get("repairedBusLines", [])[:50],
            "subwayGaragesMissingLinesRoute": report["subwayGaragesMissingLinesRoute"][:50],
            "droppedBusActorFiles": report.get("droppedBusActorFiles", [])[:50],
            "correctedFiles": report.get("correctedFiles", [])[:50],
        },
    }


def main() -> int:
    args = parse_args()
    global VERBOSE
    VERBOSE = args.verbose
    input_root = Path(args.input_root).expanduser().resolve()
    if not input_root.exists():
        raise SystemExit(f"Input root does not exist: {input_root}")

    if args.in_place:
        output_root = input_root
    else:
        output_root = (
            Path(args.output_root).expanduser().resolve()
            if args.output_root
            else input_root.parent / "repair-fixed" / input_root.name
        )

    stats = RepairStats()
    report_lists: Dict[str, List[Any]] = defaultdict(list)

    network: NetworkData | None = None
    tree_cache: Dict[int, tuple[cKDTree, np.ndarray]] = {}
    strong_tree_cache: Dict[int, tuple[cKDTree, np.ndarray]] = {}
    connector_links: Dict[tuple[str, str], Dict[str, Any]] = {}
    network_result = load_network_components(input_root)
    if network_result is not None:
        network, network_stats = network_result
        stats.network_nodes_total = network_stats.network_nodes_total
        stats.network_edges_total = network_stats.network_edges_total
        vlog("Connectivity index loaded")
    elif not SCIPY_AVAILABLE:
        print("[warn] scipy is not available; skipping network connectivity audit")
    else:
        print("[warn] network connectivity audit skipped because nodes/links were not loadable")

    if args.report_only:
        for src in iter_json_files(input_root):
            stats.files_scanned += 1
            if VERBOSE and stats.files_scanned % max(args.progress_every, 1) == 0:
                vlog(f"Scanned {stats.files_scanned} files (report-only)")
            with src.open() as fh:
                data = json.load(fh)
            if isinstance(data, list):
                if any(isinstance(a, dict) and a.get("typeActor") == "hybrid.actor.Bus" for a in data):
                    stats.bus_actor_files_dropped += 1
                    report_lists["droppedBusActorFiles"].append(str(src.relative_to(input_root)))
                    continue
                for actor in data:
                    if not isinstance(actor, dict):
                        continue
                    if actor.get("typeActor") == "hybrid.actor.BusStation":
                        stats.bus_stations_total += 1
                        content = actor.get("data", {}).get("content", {})
                        if content.get("goingRoute") is None:
                            stats.bus_station_null_going_route += 1
                            report_lists["busStationsMissingGoingRoute"].append(actor.get("id", ""))
                        if content.get("returningRoute") is None:
                            stats.bus_station_null_returning_route += 1
                            report_lists["busStationsMissingReturningRoute"].append(actor.get("id", ""))
                        analyze_bus_station_connectivity(actor, network, stats, report_lists)
                    elif actor.get("typeActor") == "hybrid.actor.SubwayStation":
                        inspect_subway_station_actor(actor, stats, report_lists)
            elif isinstance(data, dict) and "actorsDataSources" in data:
                removed = sum(1 for s in data["actorsDataSources"] if s.get("classType") == "hybrid.actor.Bus")
                if removed:
                    stats.simulation_bus_entries_removed += removed
                    report_lists["droppedBusActorFiles"].append(f"{src.relative_to(input_root)} ({removed} entries found)")

        report = build_report(stats, report_lists, input_root, output_root)
        report_path = (output_root if args.in_place else output_root) / "route_repair_report.json"
        ensure_parent(report_path)
        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
        print(json.dumps(report, indent=2, ensure_ascii=False))
        return 0

    output_root.mkdir(parents=True, exist_ok=True)

    for src in iter_json_files(input_root):
        stats.files_scanned += 1
        if VERBOSE and stats.files_scanned % max(args.progress_every, 1) == 0:
            vlog(f"Processed {stats.files_scanned} files")
        rel = src.relative_to(input_root)
        dst = output_root / rel
        changed = repair_json_file(
            src,
            dst,
            stats,
            report_lists,
            network,
            str(rel),
            args.snap_max_distance_meters,
            tree_cache,
            connector_links,
            strong_tree_cache,
        )
        if changed:
            stats.files_written += 1

    transit_changed = synchronize_transit_files(output_root, stats, report_lists)
    if transit_changed:
        stats.files_written += 1
        stats.files_corrected += 1
        vlog("Transit files synchronized with repaired bus stations")

    write_connector_links_file(output_root, connector_links, stats, report_lists)
    if stats.virtual_connector_links_added:
        stats.files_written += 1
        vlog(f"Added {stats.virtual_connector_links_added} virtual connector links, "
             f"{stats.bus_stations_bridge_connected} stations bridge-connected")

    report = build_report(stats, report_lists, input_root, output_root)
    report_path = output_root / "route_repair_report.json"
    report_txt_path = output_root / "route_repair_report.txt"
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    report_txt_path.write_text(
        "Route repair report\n"
        f"Input root: {input_root}\n"
        f"Output root: {output_root}\n"
        f"Files scanned: {stats.files_scanned}\n"
        f"Files written: {stats.files_written}\n"
        f"Files corrected: {stats.files_corrected}\n"
        f"Bus stations total: {stats.bus_stations_total}\n"
        f"Bus stations repaired: {stats.bus_stations_repaired}\n"
        f"Bus stations missing goingRoute: {stats.bus_station_null_going_route}\n"
        f"Bus stations missing returningRoute: {stats.bus_station_null_returning_route}\n"
        f"Network nodes: {stats.network_nodes_total}\n"
        f"Network edges: {stats.network_edges_total}\n"
        f"Bus stations with missing network nodes: {stats.bus_stations_missing_network_nodes}\n"
        f"Bus stations with disconnected segments: {stats.bus_stations_disconnected_segments}\n"
        f"Missing network nodes total: {stats.bus_station_missing_nodes_total}\n"
        f"Disconnected segments total: {stats.bus_station_disconnected_segments_total}\n"
        f"Bus stations with duplicate-node segments: {stats.bus_stations_duplicate_node_segments}\n"
        f"Duplicate-node segments total: {stats.bus_station_duplicate_node_segments_total}\n"
        f"Connectivity-repaired bus stations: {stats.bus_stations_connectivity_repaired}\n"
        f"Connectivity-snapped bus stations: {stats.bus_stations_snapped}\n"
        f"Snapped stops total: {stats.bus_stops_snapped_total}\n"
        f"Connectivity-unrepairable bus stations: {stats.bus_stations_connectivity_unrepairable}\n"
        f"Removed stops total: {stats.bus_station_removed_stops_total}\n"
        f"Transit routes lines updated: {stats.transit_routes_lines_updated}\n"
        f"Transit routes stops removed total: {stats.transit_routes_stops_removed_total}\n"
        f"Transit map entries updated: {stats.transit_map_entries_updated}\n"
        f"Subway garages total: {stats.subway_garages_total}\n"
        f"Subway garages missing linesRoute: {stats.subway_garages_missing_lines_route}\n"
        f"Bus actor data files dropped: {stats.bus_actor_files_dropped}\n"
        f"Simulation config Bus entries removed: {stats.simulation_bus_entries_removed}\n"
        f"Virtual connector links added: {stats.virtual_connector_links_added}\n"
        f"Bus stations bridge-connected: {stats.bus_stations_bridge_connected}\n"
        f"Corrected files: {', '.join(report.get('correctedFiles', [])[:50]) if report.get('correctedFiles') else 'none'}\n"
    )

    print(json.dumps(report, indent=2, ensure_ascii=False))
    print(f"Repaired scenario written to {output_root}")
    print(f"Report: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
package org.interscity.htc
package core.actor.manager.load

import core.actor.BaseActor

import org.apache.pekko.actor.{ ActorRef, Props }
import org.apache.pekko.cluster.singleton.{ ClusterSingletonProxy, ClusterSingletonProxySettings }
import core.util.{ ActorCreatorUtil, DistributedUtil, IdUtil, StringUtil }
import core.entity.state.DefaultState
import core.util.ActorCreatorUtil.createShardRegion

import org.apache.pekko.cluster.sharding.ShardRegion
import org.interscity.htc.core.entity.actor.ShardActorId
import org.htc.protobuf.core.entity.event.control.load.{ InitializeEntityAckEvent, StartCreationEvent }
import org.interscity.htc.core.actor.manager.loadbalance.allocation.SpatialShardIdRegistry
import org.interscity.htc.core.entity.actor.properties.{ CreatorProperties, Properties }
import org.interscity.htc.core.entity.actor.{ ActorSimulationCreation, Initialization }
import org.interscity.htc.core.entity.control.loadbalance.SpatialEntityData
import org.interscity.htc.core.entity.event.EntityEnvelopeEvent
import org.interscity.htc.core.entity.event.control.load.{ CreateActorsEvent, FinishCreationEvent, InitializeEvent, NeedsPostLoadRegistrationEvent, ProcessNextCreateChunk }
import org.interscity.htc.core.entity.event.control.loadbalance.{ BatchShardAssignmentResponse, RegisterSpatialEntitiesBatchEvent }
import org.interscity.htc.core.entity.event.data.InitializeData
import org.interscity.htc.core.util.ManagerConstantsUtil.LOAD_BALANCE_MANAGER_ACTOR_NAME
import org.interscity.htc.core.util.ManagerConstantsUtil.SIMULATION_MANAGER_ACTOR_NAME
import org.htc.protobuf.core.entity.event.control.execution.StopSimulationEvent

import scala.collection.mutable
import scala.concurrent.duration.*
import scala.concurrent.ExecutionContext.Implicits.global

class CreatorLoadData(
  private val creatorProperties: CreatorProperties
) extends BaseActor[DefaultState](
      properties = Properties(
        entityId = creatorProperties.entityId,
        resourceId = creatorProperties.shardId,
        data = creatorProperties.data
      )
    ) {
  override protected val config = context.system.settings.config

  private val timeManagers: mutable.Map[String, ActorRef] = creatorProperties.timeManagers
  private val creatorManager: ActorRef = creatorProperties.creatorManager
  private val reporters: mutable.Map[org.interscity.htc.core.enumeration.ReportTypeEnum, ActorRef] =
    creatorProperties.reporters

  private[load] val initializeData = mutable.Map[String, mutable.Map[String, Initialization]]()
  private[load] val initializedAcknowledges = mutable.Map[String, mutable.Seq[String]]()

  /** entityId -> FIFO queue of (batchId, classType) awaiting this entity's InitializeEntityAckEvent,
    * one entry per StartEntityAck this actor has already forwarded as an InitializeEvent. A queue
    * (not a single value) because the same entityId can legitimately have more than one in-flight
    * registration across overlapping batches — see `actorsBatches` below for why a bare-entityId
    * key silently drops the earlier registration.
    */
  private[load] val pendingInitAck: mutable.Map[String, mutable.Queue[(String, String)]] = mutable.Map.empty
  private[load] var amountActors = 0

  private[load] val actorsToCreate: mutable.Map[String, List[ActorSimulationCreation]] = mutable.Map.empty

  /** entityId -> FIFO queue of batchIds with an outstanding StartEntity/StartEntityAck round-trip
    * for that entity. Keyed by entityId only (like `pendingInitAck`) but the *value* is a queue,
    * not a bare batchId: if a StartEntity for the same entity is redelivered/retried while its
    * original ack is still outstanding, or the same entity is legitimately part of two
    * back-to-back batches, a bare `Map[String, String]` here would let the second registration
    * clobber the first — the original batch's ack then resolves to the wrong (or since-removed)
    * batch and silently never unblocks. FIFO matches Pekko's per-shard-region ordered delivery of
    * StartEntity, so the oldest outstanding registration for an entity is popped first.
    */
  private[load] val actorsBatches: mutable.Map[String, mutable.Queue[String]] = mutable.Map.empty
  private[load] val batchesLoad: mutable.Map[String, ActorRef] = mutable.Map.empty
  private val batchesToCreate: mutable.Map[String, Seq[ActorSimulationCreation]] = mutable.Map.empty

  private val CREATE_CHUNK_SIZE = 500
  private val DELAY_BETWEEN_CHUNKS = 100.milliseconds

  /** Lazy singleton proxy to LoadBalanceManager (null if load balancing disabled). */
  private var loadBalanceProxy: ActorRef = _

  /** Pending chunks awaiting BatchShardAssignmentResponse from LoadBalanceManager. Key: batchId,
    * Value: the chunk of actors waiting for spatial assignment.
    */
  private[load] val pendingChunks: mutable.Map[String, List[ActorSimulationCreation]] = mutable.Map.empty
  private[load] val pendingChunkIndexes: mutable.Map[String, Int] = mutable.Map.empty
  private val nextChunkIndexes: mutable.Map[String, Int] = mutable.Map.empty

  /** Whether this instance has already attempted proxy initialisation (avoids repeat config reads).
    */
  private var lbProxyChecked: Boolean = false
  private var spatialCreationFailed = false

  override def onStart(): Unit =
    super.onStart()

  override def postStop(): Unit =
    super.postStop()

  override def handleEvent: Receive = {
    case _ if spatialCreationFailed => ()
    case event: CreateActorsEvent =>
      logDebug(s"Received CreateActorsEvent with ${event.actors.size} actors, batchId=${event.id}")
      handleCreateActors(event)
    case event: StartCreationEvent             => handleStartCreation(event)
    case event: ProcessNextCreateChunk         => handleProcessNextCreateChunk(event.batchId)
    case event: BatchShardAssignmentResponse   => handleBatchAssignmentResponse(event)
    case event: ShardRegion.StartEntityAck     => handleInitialize(event)
    case event: InitializeEntityAckEvent       => handleFinishInitialization(event)
    case event: NeedsPostLoadRegistrationEvent => handleNeedsPostLoadRegistration(event)

    case _ =>
  }

  private def handleCreateActors(event: CreateActorsEvent): Unit = {
    batchesToCreate.put(event.id, event.actors)
    batchesLoad.put(event.id, event.actorRef)
    self ! StartCreationEvent(batchId = event.id)
  }

  private def handleStartCreation(event: StartCreationEvent): Unit = {
    actorsToCreate(event.batchId) = batchesToCreate
      .get(event.batchId)
      .map(_.distinctBy(_.actor.id))
      .getOrElse(Seq.empty)
      .toList

    batchesToCreate.remove(event.batchId)

    amountActors += actorsToCreate(event.batchId).size

    if (actorsToCreate.nonEmpty) {
      self ! ProcessNextCreateChunk(batchId = event.batchId)
    } else {
      checkAndSendFinish(event.batchId)
    }
  }

  /** Process the next chunk of entities for a batch.
    *
    * Two-phase creation when load balancing is enabled: Phase 1: Extract spatial positions → send
    * batch to LoadBalanceManager → wait Phase 2: On BatchShardAssignmentResponse → store mappings →
    * create entities
    *
    * When load balancing is disabled, entities are created immediately with hash-based routing.
    */
  private def handleProcessNextCreateChunk(batchId: String): Unit = {

    val currentActors = actorsToCreate.getOrElse(batchId, List.empty)
    val chunk = currentActors.take(CREATE_CHUNK_SIZE)

    if (chunk.nonEmpty) {
      val lbProxy = getLoadBalanceProxy
      if (lbProxy.isDefined) {
        val spatialEntities = chunk.map {
          actorCreation =>
            val position = core.actor.manager.loadbalance.allocation.SpatialPositionUtil.resolve(actorCreation.actor.data.content, config)
            SpatialEntityData(
              spatialEntityId = actorCreation.actor.id.toString,
              lon = position._1,
              lat = position._2,
              entityClassType = actorCreation.actor.typeActor
            )
        }

        val withRealPos = spatialEntities.count {
          e => e.position != (0.0, 0.0)
        }

        pendingChunks.put(batchId, chunk)
        val chunkIndex = nextChunkIndexes.getOrElse(batchId, 0)
        nextChunkIndexes(batchId) = chunkIndex + 1
        pendingChunkIndexes(batchId) = chunkIndex
        lbProxy.get ! RegisterSpatialEntitiesBatchEvent(
          entities = spatialEntities,
          batchId = batchId,
          chunkIndex = chunkIndex
        )
        return
      }

      createEntitiesFromChunk(chunk, batchId)
      advanceToNextChunk(batchId, chunk.size)
    } else {
      checkAndSendFinish(batchId)
    }
  }

  /** Handles the batch shard assignment response from LoadBalanceManager.
    *
    * Phase 2 of two-phase creation: stores the spatial shard assignments in
    * [[SpatialShardIdRegistry]], then creates the entities using the assigned shard IDs.
    */
  private[load] def handleBatchAssignmentResponse(response: BatchShardAssignmentResponse): Unit = try {
    if (!pendingChunkIndexes.get(response.batchId).contains(response.chunkIndex)) {
      logWarn(s"Ignoring spatial assignment for inactive chunk '${response.batchId}/${response.chunkIndex}'")
      return
    }
    val expectedIds = pendingChunks(response.batchId).map(_.actor.id.toString).toSet
    require(response.assignments.keySet == expectedIds && response.positions.keySet == expectedIds,
      "spatial assignment response does not cover its creation chunk")
    require(response.positions.values.forall(a => a != null && a.length == 2 && a.forall(_.isFinite)),
      "invalid spatial creation positions")
    if (config.getBoolean("htc.load-balance-manager.enabled")) {
      pendingChunks(response.batchId).foreach { creation =>
        val id = creation.actor.id.toString
        val published = SpatialShardIdRegistry.requirePublishedShardId(id,
          StringUtil.getModelClassName(creation.actor.typeActor))
        require(response.assignments(id) == published, "creation response differs from published spatial directory")
      }
    }
    SpatialShardIdRegistry.putAllShardIds(response.assignments)

    SpatialShardIdRegistry.putAllPositions(response.positions)

    logDebug(
      s"Received spatial assignments for batch '${response.batchId}': " +
        s"${response.assignments.size} entities assigned"
    )

    pendingChunkIndexes.remove(response.batchId)

    pendingChunks.remove(response.batchId) match {
      case Some(chunk) =>
        createEntitiesFromChunk(chunk, response.batchId)
        advanceToNextChunk(response.batchId, chunk.size)

      case None =>
        logWarn(
          s"Received BatchShardAssignmentResponse for batch '${response.batchId}' " +
            s"but no pending chunk found. Ignoring."
        )
    }
  } catch {
    case scala.util.control.NonFatal(error) =>
      spatialCreationFailed = true
      stopForSpatialFailure(error.getMessage)
  }

  protected def stopForSpatialFailure(reason: String): Unit = {
    logError(s"Spatial creation failed; stopping simulation: $reason")
    val proxy = context.actorOf(ClusterSingletonProxy.props(s"/user/$SIMULATION_MANAGER_ACTOR_NAME",
      ClusterSingletonProxySettings(context.system)))
    proxy ! StopSimulationEvent()
  }

  /** Creates entities from a chunk — the actual creation loop extracted from
    * handleProcessNextCreateChunk. This is shared by both the immediate path (no LB) and the
    * deferred path (after spatial assignment).
    */
  private def createEntitiesFromChunk(
    chunk: List[ActorSimulationCreation],
    batchId: String
  ): Unit =
    chunk.foreach {
      actorCreation =>
        val initialization = Initialization(
          id = actorCreation.actor.id.toString,
          resourceId = actorCreation.resourceId,
          classType = actorCreation.actor.typeActor,
          data = actorCreation.actor.data.content,
          timeManagers = timeManagers,
          runtimeCoordinator = creatorProperties.runtimeCoordinator,
          creatorManager = self,
          reporters = reporters,
          relationships = {
            val base =
              if (actorCreation.actor.relationships != null) actorCreation.actor.relationships
              else Map.empty[String, ShardActorId]
            mutable.Map[String, ShardActorId]() ++= base.map {
              case (label, rel) =>
                val bucket =
                  if (rel.shardBucket.nonEmpty) rel.shardBucket
                  else SpatialShardIdRegistry.getShardId(rel.entityId.toString).getOrElse("")
                label -> rel.copy(shardBucket = bucket)
            }
          }
        )

        addInitializeData(actorCreation.actor.id.toString, batchId, initialization)
        addToInitializedAcknowledges(batchId, actorCreation.actor.id.toString)

        val fullClassName = StringUtil.getModelClassName(actorCreation.actor.typeActor)
        SpatialShardIdRegistry.putEntityClassName(actorCreation.actor.id.toString, fullClassName)

        val shardRegion = createShardRegion(
          system = context.system,
          resourceId = actorCreation.resourceId,
          actorClassName = actorCreation.actor.typeActor,
          entityId = actorCreation.actor.id.toString,
          timeManagers = timeManagers,
          runtimeCoordinator = creatorProperties.runtimeCoordinator,
          creatorManager = self,
          reporters = reporters
        )

        shardRegion ! ShardRegion.StartEntity(actorCreation.actor.id.toString)
    }

  /** Advances to the next chunk or finishes if no more actors remain. */
  private def advanceToNextChunk(batchId: String, chunkSize: Int): Unit = {
    actorsToCreate(batchId) = actorsToCreate(batchId).drop(chunkSize)

    if (actorsToCreate(batchId).nonEmpty) {
      context.system.scheduler.scheduleOnce(
        DELAY_BETWEEN_CHUNKS,
        self,
        ProcessNextCreateChunk(batchId = batchId)
      )
    }
  }

  /** Extracts spatial position from an entity's raw data content.
    *
    * Extraction strategy by entity type:
    *   - Nodes: Direct lat/long from content map (`latitude`, `longitude` keys)
    *   - Links: Look up `from` node position via [[SpatialShardIdRegistry]]
    *   - Cars/Buses/Vehicles: Look up `origin` or `currentNode` position via registry
    *   - Unknown: None (falls back to hash-based routing)
    *
    * @return
    *   Some((longitude, latitude)) if spatial data is available, None otherwise
    */
  private def extractSpatialPosition(
    actorCreation: ActorSimulationCreation
  ): Option[(Double, Double)] =
    core.actor.manager.loadbalance.allocation.SpatialPositionUtil.extract(actorCreation.actor.data.content)

  /** Lazily obtains a singleton proxy to LoadBalanceManager, if load balancing is enabled.
    *
    * Uses a JVM-level cache in the companion object so all [[CreatorLoadData]] instances on the
    * same node share one proxy actor, instead of each creating their own.
    *
    * Gate is config `htc.load-balance-manager.enabled` — valid on all cluster nodes, unlike
    * [[ShardAllocatorRegistry]] which is only populated on the singleton host node.
    */
  private def getLoadBalanceProxy: Option[ActorRef] = {
    if (lbProxyChecked) return Option(loadBalanceProxy)

    lbProxyChecked = true
    val lbEnabled =
      try config.getBoolean("htc.load-balance-manager.enabled")
      catch { case _: Exception => false }
    if (lbEnabled) {
      val cached = CreatorLoadData.globalLbProxy.get()
      if (cached != null) {
        loadBalanceProxy = cached
        return Some(loadBalanceProxy)
      }
      val proxy = context.system.actorOf(ClusterSingletonProxy.props(
        s"/user/$LOAD_BALANCE_MANAGER_ACTOR_NAME", ClusterSingletonProxySettings(context.system)),
        s"load-balance-creator-proxy-${java.util.UUID.randomUUID()}")
      // Race: only one proxy wins; stop the losers to avoid orphaned actors.
      if (!CreatorLoadData.globalLbProxy.compareAndSet(null, proxy)) context.stop(proxy)
      loadBalanceProxy = CreatorLoadData.globalLbProxy.get()
      Some(loadBalanceProxy)
    } else {
      None // Load balancing not enabled
    }
  }

  private[load] def addInitializeData(
    entityId: String,
    batchId: String,
    initialization: Initialization
  ): Unit =
    initializeData.get(batchId) match {
      case Some(data) => data.put(entityId, initialization)
      case None       => initializeData.put(batchId, mutable.Map(entityId -> initialization))
    }

  private[load] def addToInitializedAcknowledges(batchId: String, entityId: String): Unit = {
    initializedAcknowledges.get(batchId) match {
      case Some(acknowledge) => initializedAcknowledges.put(batchId, acknowledge :+ entityId)
      case None              => initializedAcknowledges.put(batchId, mutable.Seq(entityId))
    }
    actorsBatches.getOrElseUpdate(entityId, mutable.Queue.empty) += batchId
  }

  private def removeOfInitializedAcknowledges(batchId: String, entityId: String): Unit =
    initializedAcknowledges.get(batchId) match {
      case Some(acknowledge) =>
        initializedAcknowledges.put(batchId, acknowledge.filter(_ != entityId))
      case None =>
    }

  private[load] def handleInitialize(event: ShardRegion.StartEntityAck): Unit = {
    val classTypeForLog = {
      actorsBatches.get(event.entityId).filter(_.nonEmpty) match {
        case Some(queue) =>
          initializeData
            .get(queue.head)
            .flatMap(_.get(event.entityId))
            .map(_.classType)
            .getOrElse("unknown")
        case None =>
          pendingInitAck.get(event.entityId).flatMap(_.headOption).map(_._2).getOrElse("not-found")
      }
    }
    actorsBatches.get(event.entityId).filter(_.nonEmpty) match {
      case Some(queue) =>
        // FIFO: resolve the oldest outstanding registration for this entity first, matching the
        // order StartEntity was sent — same entity can be mid-flight for more than one batch.
        val batchId = queue.head
        initializeData.get(batchId).flatMap(_.get(event.entityId)) match {
          case Some(data) =>
            queue.dequeue()
            if (queue.isEmpty) actorsBatches.remove(event.entityId)
            try {
              val initializeEvent = InitializeEvent(
                id = data.id,
                actorRef = self,
                data = InitializeData(
                  data = data.data,
                  resourceId = data.resourceId,
                  timeManagers = data.timeManagers,
                  runtimeCoordinator = data.runtimeCoordinator,
                  creatorManager = data.creatorManager,
                  reporters = data.reporters,
                  relationships = data.relationships.map {
                    case (_, rel) => IdUtil.format(rel.entityId) -> rel
                  }
                )
              )

              getShardRef(StringUtil.getModelClassName(data.classType)) ! EntityEnvelopeEvent(
                entityId = event.entityId,
                event = initializeEvent
              )

              pendingInitAck.getOrElseUpdate(event.entityId, mutable.Queue.empty) += (batchId -> data.classType)
            } catch {
              case e: Exception =>
                logError(
                  s"Failed to build InitializeEvent for ${event.entityId} (${data.classType}, batch=$batchId): ${e.getMessage}. Bypassing to unblock batch.",
                  e
                )
                // Bypass the stuck entity so the batch can complete
                removeOfInitializedAcknowledges(batchId, event.entityId)
            }
            initializeData(batchId).remove(event.entityId)
            if (initializeData(batchId).isEmpty) initializeData.remove(batchId)
            checkAndSendFinish(batchId)

          case None =>
            // batchId was tracked in actorsBatches but its initializeData was already consumed/lost
            // (e.g. a duplicate/redelivered StartEntityAck for a registration already resolved).
            // Bypass rather than silently leaving that batch stuck forever.
            logError(
              s"StartEntityAck for ${event.entityId} (classType=$classTypeForLog) matched batch=$batchId in actorsBatches " +
                s"but no initializeData found for it. Bypassing to unblock batch."
            )
            queue.dequeue()
            if (queue.isEmpty) actorsBatches.remove(event.entityId)
            removeOfInitializedAcknowledges(batchId, event.entityId)
            checkAndSendFinish(batchId)
        }
      case None =>
        logError(
          s"StartEntityAck for ${event.entityId} (classType=$classTypeForLog) NOT FOUND in actorsBatches! " +
            s"No batchId is known for this entity, so no batch can be unblocked for it. Known batches: ${actorsBatches.size}"
        )
    }
  }

  private[load] def handleFinishInitialization(event: InitializeEntityAckEvent): Unit =
    // FIFO: this entity's InitializeEntityAckEvent replies arrive in the same order its
    // InitializeEvents were sent out (handleInitialize), so resolve the oldest pending
    // (batchId, classType) pair first — same reasoning as `actorsBatches`.
    pendingInitAck.get(event.entityId).filter(_.nonEmpty) match {
      case Some(queue) =>
        val (batchId, classType) = queue.dequeue()
        if (queue.isEmpty) pendingInitAck.remove(event.entityId)
        if (
          creatorProperties.postLoadCoordinator != null &&
          creatorProperties.postLoadRegistrationClasses.contains(classType)
        ) {
          creatorProperties.postLoadCoordinator ! NeedsPostLoadRegistrationEvent(
            entityId = event.entityId,
            classType = classType
          )
        }
        removeOfInitializedAcknowledges(batchId, event.entityId)
        checkAndSendFinish(batchId)

      case None =>
        // No tracked (batchId, classType) for this entity — orphaned/duplicate ack. Fall back to
        // scanning initializedAcknowledges so a stray reply still unblocks whatever batch is
        // actually still waiting on it, instead of leaving that batch stuck forever.
        logError(
          s"InitializeEntityAckEvent for ${event.entityId} NOT FOUND in pendingInitAck! Falling back to scanning initializedAcknowledges."
        )
        initializedAcknowledges.foreach {
          case (bId, acks) =>
            if (acks.contains(event.entityId)) {
              removeOfInitializedAcknowledges(bId, event.entityId)
              checkAndSendFinish(bId)
            }
        }
    }

  /** Forwards NeedsPostLoadRegistrationEvent directly to PostLoadRegistrationCoordinator so it can
    * accumulate registrations during the loading phase (before being triggered). The coordinator is
    * the correct owner of this list, not LoadDataManager.
    */
  private def handleNeedsPostLoadRegistration(event: NeedsPostLoadRegistrationEvent): Unit =
    if (creatorProperties.postLoadCoordinator != null) {
      logDebug(
        s"Forwarding NeedsPostLoadRegistration for ${event.entityId} (${event.classType}) to coordinator"
      )
      creatorProperties.postLoadCoordinator ! event
    } else {
      logWarn(
        s"No postLoadCoordinator set — dropping NeedsPostLoadRegistration for ${event.entityId}"
      )
    }

  private[load] def checkAndSendFinish(batchId: String): Unit = {
    val hasPendingCreation = actorsToCreate.get(batchId).exists(_.nonEmpty)
    val hasPendingAcks = initializedAcknowledges.get(batchId).exists(_.nonEmpty)
    val hasPendingInitData = initializeData.contains(batchId)

    if (!hasPendingCreation && !hasPendingAcks && !hasPendingInitData) {

      batchesLoad.get(batchId).foreach {
        ref =>
          ref ! FinishCreationEvent(
            actorRef = self,
            batchId = batchId,
            amount = amountActors
          )
      }

      batchesLoad.remove(batchId)
      batchesToCreate.remove(batchId)
      actorsToCreate.remove(batchId)
      initializedAcknowledges.remove(batchId)
      nextChunkIndexes.remove(batchId)

      pruneBatchFromQueues(actorsBatches, batchId)(identity)
      pruneBatchFromQueues(pendingInitAck, batchId)(_._1)
    }
  }

  /** Removes every occurrence of `batchId` from a `entityId -> Queue[A]` correlation map
    * (`actorsBatches`/`pendingInitAck`), dropping the entityId key entirely once its queue is
    * empty. Prevents these maps from accumulating stale entries for completed batches.
    */
  private def pruneBatchFromQueues[A](
    map: mutable.Map[String, mutable.Queue[A]],
    batchId: String
  )(batchIdOf: A => String): Unit =
    map.keys.toList.foreach {
      entityId =>
        val remaining = map(entityId).filterNot(a => batchIdOf(a) == batchId)
        if (remaining.isEmpty) map.remove(entityId) else map(entityId) = remaining
    }
}

object CreatorLoadData {

  /** JVM-level cache: all [[CreatorLoadData]] instances on the same node share one proxy actor. */
  private[load] val globalLbProxy: java.util.concurrent.atomic.AtomicReference[ActorRef] =
    new java.util.concurrent.atomic.AtomicReference[ActorRef](null)

  def props(
    creatorProperties: CreatorProperties
  ): Props =
    Props(
      classOf[CreatorLoadData],
      creatorProperties
    )
}

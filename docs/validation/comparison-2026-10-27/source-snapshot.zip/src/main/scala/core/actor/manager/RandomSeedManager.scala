package org.interscity.htc
package core.actor.manager

import core.entity.configuration.Simulation

import java.util.{ Random => JavaRandom }
import scala.util.{ Random => ScalaRandom }

/** Gerenciador de seeds para garantir reprodutibilidade determinística
  */
object RandomSeedManager {

  private var javaRandom: Option[JavaRandom] = None
  private var scalaRandom: Option[ScalaRandom] = None
  private var currentSeed: Option[Long] = None

  /** Inicializa os geradores de random com seed baseado na configuração da simulação
    * @param simulation
    *   Configuração da simulação
    */
  def initialize(simulation: Simulation): Unit = {
    val seed = simulation.randomSeed.getOrElse(System.currentTimeMillis())

    println(s"Configurando random seed: $seed")

    ScalaRandom.setSeed(seed)
    System.setProperty("java.util.Random.seed", seed.toString)

    javaRandom = Some(new JavaRandom(seed))
    scalaRandom = Some(new ScalaRandom(new JavaRandom(seed)))
    currentSeed = Some(seed)

    println(s"Random seed $seed configurado para reprodutibilidade")
  }

  /** Gera ID determinístico baseado no seed + contador
    */
  private var uuidCounter: Long = 0

  def deterministicUUID(): String = {
    uuidCounter += 1
    val seedPart = currentSeed.getOrElse(0L)
    val uuidValue = seedPart + uuidCounter
    f"htc-$uuidValue%016x-$uuidCounter%08x"
  }

  /** Gera um entity id `Long` determinístico baseado no seed + contador. */
  def deterministicId(): Long = {
    uuidCounter += 1
    currentSeed.getOrElse(0L) + uuidCounter
  }

  /** Gera ID determinístico para simulação
    */
  def deterministicSimulationId(simulationName: String): String = {
    val seedPart = currentSeed.getOrElse(System.currentTimeMillis())
    s"${simulationName}_seed_${seedPart}"
  }

  /** Retorna o seed atual sendo usado
    */
  def getCurrentSeed(): Option[Long] = currentSeed

  /** Reset completo do sistema (útil para testes)
    */
  def reset(): Unit = {
    javaRandom = None
    scalaRandom = None
    currentSeed = None
    uuidCounter = 0
    println("🔄 RandomSeedManager resetado")
  }

  /** Informações de debug sobre o estado atual
    */
  def debugInfo(): String =
    s"""RandomSeedManager Status:
       |  Seed: ${currentSeed.getOrElse("Not initialized")}
       |  UUID Counter: $uuidCounter
       |  Java Random: ${if (javaRandom.isDefined) "Initialized" else "Not initialized"}
       |  Scala Random: ${if (scalaRandom.isDefined) "Initialized" else "Not initialized"}
       |""".stripMargin
}

package org.interscity.htc
package core.actor.manager.report

import core.entity.event.control.report.ReportEvent

import org.apache.pekko.actor.ActorRef
import org.interscity.htc.core.util.JsonUtil

import java.io.{ BufferedWriter, FileWriter }
import java.nio.file.{ Files, Path, Paths }
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import scala.collection.mutable

class JsonReportData(
  override val reportManager: ActorRef,
  override val startRealTime: LocalDateTime
) extends ReportData(
      id = "json-report-manager",
      reportManager = reportManager,
      startRealTime = startRealTime
    ) {

  private val prefix =
    Some(config.getString("htc.report-manager.json.prefix")).getOrElse("simulation_")
  private val baseDirectory = Some(config.getString("htc.report-manager.json.directory"))
    .getOrElse("/tmp/reports/json")

  private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")
  private val effectiveStartTime = Option(startRealTime).getOrElse(LocalDateTime.now())
  private val timeBasedId = effectiveStartTime.format(dateFormatter)

  private lazy val simulationId: String = {
    val simulationConfigId =
      try {
        val simulationConfig = core.util.SimulationUtil.loadSimulationConfig()
        simulationConfig.id
      } catch {
        case _: Exception => None
      }

    val envSimId = sys.env.get("HTC_SIMULATION_ID")

    val configSimId =
      try
        Some(config.getString("htc.simulation.id"))
      catch {
        case _: Exception => None
      }

    simulationConfigId
      .orElse(envSimId)
      .orElse(configSimId)
      .getOrElse {
        val simulationName =
          try
            core.util.SimulationUtil.loadSimulationConfig().name.replaceAll("[^a-zA-Z0-9_-]", "_")
          catch {
            case _: Exception => "sim"
          }

        try
          core.actor.manager.RandomSeedManager.deterministicSimulationId(simulationName)
        catch {
          case _: Exception =>
            s"${simulationName}_$timeBasedId"
        }
      }
  }

  private val directory = s"$baseDirectory/$simulationId"

  private val batchSize = Some(config.getInt("htc.report-manager.json.batch-size")).getOrElse(100)

  // Pre-sized ArrayBuffer (instead of unbounded ListBuffer) to avoid the resize cycle and the
  // per-element cons allocations of a linked list.
  private val buffer = new mutable.ArrayBuffer[ReportEvent](batchSize)
  private var fileWriter: Option[BufferedWriter] = None

  private val actorUniqueId = java.util.UUID.randomUUID().toString.take(8)
  private val fileName = s"$prefix${timeBasedId}_${actorUniqueId}_events.jsonl"
  private val filePath = s"$directory/$fileName"
  private var persistentWriter: BufferedWriter = _
  private var flushCount: Long = 0

  override def onReport(event: ReportEvent): Unit = {
    buffer += event
    if (buffer.size >= batchSize) {
      flushBuffer()
    }
  }

  /** Returns a persistent writer, reusing the same file handle across flushes. Opening/closing
    * FileWriter per flush is expensive on network filesystems (GCS Fuse). The writer is only closed
    * in postStop().
    */
  private def getOrCreateWriter(): BufferedWriter = {
    if (persistentWriter == null) {
      mkdir(directory)
      persistentWriter = new BufferedWriter(new FileWriter(filePath, true), 65536)
    }
    persistentWriter
  }

  private def flushBuffer(): Unit = {
    if (buffer.isEmpty) return

    try {
      val writer = getOrCreateWriter()
      buffer.foreach {
        report =>
          val jsonData = Map(
            "tick" -> report.tick,
            "real_time" -> System.currentTimeMillis(),
            "simulation_id" -> simulationId,
            "event_type" -> report.label,
            "data" -> report.data
          )
          writer.write(JsonUtil.toJson(jsonData))
          writer.newLine()
      }
      writer.flush()
      flushCount += 1
      if (flushCount % 50 == 0) {
        logInfo(s"Flushed ${buffer.size} events to $filePath (total flushes: $flushCount)")
      }
      buffer.clear()
    } catch {
      case e: Exception =>
        logError(s"Failed to write report to file: ${e.getMessage}", e)
        closeWriter()
        throw e
    }
  }

  private def closeWriter(): Unit =
    if (persistentWriter != null) {
      try persistentWriter.close()
      catch { case _: Exception => }
      persistentWriter = null
    }

  private def mkdir(directory: String): Unit = {
    val dirPath: Path = Paths.get(directory)
    if (!Files.exists(dirPath)) {
      Files.createDirectories(dirPath)
    }
  }

  override protected def flushCommittedReports(): scala.concurrent.Future[Unit] = {
    flushBuffer()
    if (persistentWriter != null) persistentWriter.flush()
    val path = Paths.get(filePath)
    if (Files.exists(path)) {
      val channel = java.nio.channels.FileChannel.open(path, java.nio.file.StandardOpenOption.WRITE)
      try channel.force(true) finally channel.close()
    }
    scala.concurrent.Future.successful(())
  }

  override def postStop(): Unit = {
    if (buffer.nonEmpty) {
      flushBuffer()
    }
    closeWriter()
  }
}

package org.interscity.htc
package core.util

import core.util.JsonUtil.{ fromJson, readJsonFile }
import core.exception.SimulationEnvConfigFoundException
import core.api.{ApiConfigRegistry, SimulatorSettingsRegistry}

import com.typesafe.config.ConfigFactory
import org.interscity.htc.core.entity.configuration.{ Simulation, SimulationWrapper }
import org.apache.pekko.actor.ActorSystem
import org.apache.pekko.cluster.sharding.ShardRegion
import org.interscity.htc.core.enumeration.CreationTypeEnum
import org.interscity.htc.core.util.ActorCreatorUtil.createShardRegion

import java.util.UUID
import java.io.{ BufferedInputStream, FileInputStream }
import scala.language.postfixOps

object SimulationUtil {

  private[util] def validateAccountedRoutingSources(configuration: Simulation, workerIds: Vector[Long]): Unit = {
    val className = StringUtil.getModelClassName(model.hybrid.util.AccountedRoutingConfig.ActorClassType)
    val sources = configuration.actorsDataSources.filter(s => StringUtil.getModelClassName(s.classType) == className)
    require(sources.nonEmpty, "accounted routing requires an EAGER RoutingService actor source")
    require(sources.forall(_.loadingStrategy == core.enumeration.LoadingStrategyEnum.EAGER),
      "RoutingService sources must use EAGER loading")
    require(sources.forall(_.entityLifecycle == core.enumeration.EntityLifecycleEnum.STATIC),
      "RoutingService sources must use STATIC lifecycle")
    require(sources.forall(s => s.creationType == null || s.creationType == CreationTypeEnum.LoadBalancedDistributed),
      "RoutingService sources must use LoadBalancedDistributed creation")

    val loadedIds = sources.iterator.flatMap { source =>
      val path = source.dataSource.info("path").asInstanceOf[String]
      source.dataSource.sourceType match {
        case core.enumeration.DataSourceTypeEnum.json =>
          val input = new BufferedInputStream(new FileInputStream(path))
          val (parser, actors) = JsonStreamingUtil.createParser(input)
          try actors.map(_.id).toVector.iterator
          finally { parser.close(); input.close() }
        case core.enumeration.DataSourceTypeEnum.sqlite =>
          val (connection, actors) = SqliteActorSimulationUtil.openIterator(path)
          try actors.map(_.id).toVector.iterator
          finally connection.close()
      }
    }.toVector
    require(loadedIds.distinct.size == loadedIds.size, "RoutingService source ids must be unique")
    val expected = workerIds.toSet
    require(loadedIds.toSet == expected,
      s"RoutingService source ids $loadedIds must exactly match htc.routing.accounted.worker-ids $expected")
  }

  private[util] def localScenarioSettings(configuration: Simulation): Map[String, String] =
    Map("htc.simulation.duration" -> configuration.duration.toString,
      SimulationClock.Setting -> SimulationClock.validateScenario(configuration).secondsPerTick.toString) ++
      configuration.cityMapFile.map("htc.mobility.city-map-file" -> _) ++
      configuration.transitMapFile.map("htc.mobility.transit-map-file" -> _) ++
      configuration.transitRoutesFile.map("htc.mobility.transit-routes-file" -> _)

  def installLocalScenarioSettings(configuration: Simulation): Unit =
    SimulatorSettingsRegistry.setAll(localScenarioSettings(configuration))

  def loadSimulationConfig(configuration: String = null): Simulation = {
    val path = if (configuration == null || configuration.isEmpty) null else configuration
    if (path != null) {
      val content = readJsonFile(path)
      try
        fromJson[SimulationWrapper](content).simulation
      catch {
        case _: Exception => fromJson[Simulation](content)
      }
    } else {
      ApiConfigRegistry.get match {
        case Some(config) => config
        case None         => loadSimulationConfigFromFileOrEnv()
      }
    }
  }

  /** Loads simulation config from application.conf / env var only, bypassing the API registry. Used
    * by [[core.api.ConfigRoutes]] to report what would be loaded without the API override.
    */
  def loadSimulationConfigFromFileOrEnv(): Simulation = {
    val applicationConfig = ConfigFactory.load().getString("htc.simulation.config-file")
    if (applicationConfig != null && applicationConfig.nonEmpty) {
      val content = readJsonFile(applicationConfig)
      fromJson[Simulation](content)
    } else {
      loadFromEnvironmentVariable("HTC_SIMULATION_CONFIG_FILE")
    }
  }

  private def loadFromEnvironmentVariable(envVar: String): Simulation =
    sys.env.get(envVar) match {
      case Some(file) => fromJson[Simulation](readJsonFile(file))
      case None       => throw new SimulationEnvConfigFoundException(envVar)
    }

  def loadFronApplicationConfig(configFile: String): Simulation =
    fromJson[Simulation](readJsonFile(configFile))

  def startShards(system: ActorSystem, configuration: String = null): Unit = {
    val simulationConfig = loadSimulationConfig(configuration)
    val customBalancing = system.settings.config.getBoolean("htc.load-balance-manager.enabled")
    require(!customBalancing || simulationConfig.timeManagerType != core.enumeration.TimeManagerTypeEnum.TIME_WARP,
      "custom load-balancing migration requires the production conservative runtime")
    if (customBalancing) core.actor.manager.loadbalance.strategy.LoadBalanceSettings.read(system.settings.config)
    if (model.hybrid.util.AccountedRoutingConfig.enabled)
      validateAccountedRoutingSources(simulationConfig, model.hybrid.util.AccountedRoutingConfig.workerIds)
    // Remote shard actors can initialize lazy process-wide resources before the
    // SimulationManager's singleton runs; its registry writes reach only its own JVM.
    installLocalScenarioSettings(simulationConfig)
    core.actor.manager.loadbalance.allocation.AllocationRuntime(system).start()

    // Register shard regions for all actor types declared in actorsDataSources.
    simulationConfig.actorsDataSources
      .distinctBy(_.id)
      .filter(
        s => s.creationType == null || s.creationType == CreationTypeEnum.LoadBalancedDistributed
      )
      .distinctBy(
        s => s.classType
      )
      .foreach {
        source =>
          val initiatorId =
            try
              s"${core.actor.manager.RandomSeedManager.deterministicUUID()}-shard-initiator"
            catch {
              case _: Exception => s"${UUID.randomUUID().toString}-shard-initiator"
            }
          val shardRegion = createShardRegion(
            system,
            source.classType,
            initiatorId,
            IdUtil.format(source.id),
            null,
            null
          )
          if (!customBalancing) shardRegion ! ShardRegion.StartEntity(initiatorId)
      }

    // Also register shard regions for actor types that are created dynamically at runtime
    // (e.g. Bus spawned by BusStation, Subway by SubwayStation). These types have no initial
    // entries in actorsDataSources but their shard region must exist on EVERY cluster node
    // before any routing can happen.
    simulationConfig.dynamicActorTypes
      .distinct
      .foreach { actorType =>
        val dummyId = s"${UUID.randomUUID().toString}-dynamic-shard-init"
        createShardRegion(
          system,
          actorType,
          dummyId,
          dummyId,
          null,
          null
        )
        system.log.info(s"startShards: registered dynamic shard region for $actorType")
      }
  }
}

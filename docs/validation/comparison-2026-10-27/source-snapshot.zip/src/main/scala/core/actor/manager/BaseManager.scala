package org.interscity.htc
package core.actor.manager

import core.actor.BaseActor
import core.entity.state.BaseState

import org.apache.pekko.actor.{ ActorRef, Props }
import org.interscity.htc.core.entity.actor.properties.Properties
import org.interscity.htc.core.util.{ ActorCreatorUtil, DistributedUtil }

import scala.collection.mutable

abstract class BaseManager[T <: BaseState](
  actorId: String = null,
  timeManager: ActorRef = null
)(implicit m: Manifest[T])
    extends BaseActor[T](
      properties = Properties(
        entityId = actorId,
        resourceId = "",
        timeManagers =
          if (timeManager != null) mutable.Map("discrete-event" -> timeManager)
          else mutable.Map.empty,
        creatorManager = null,
        reporters = mutable.Map.empty
      )
    ) {

  protected var reporters
    : mutable.Map[org.interscity.htc.core.enumeration.ReportTypeEnum, ActorRef] = null
  protected var timeManagerRef: ActorRef = timeManager

  protected def createSingletonManager(
    manager: Props,
    name: String,
    terminateMessage: Any
  ): ActorRef = ActorCreatorUtil.createSingletonManager(
    system = context.system,
    manager = manager,
    name = name,
    terminateMessage = terminateMessage
  )

  protected def createSingletonProxy(name: String): ActorRef =
    DistributedUtil.createSingletonProxy(context.system, name)
}

package org.interscity.htc
package core.actor.manager

import core.entity.state.DefaultState
import core.types.Tick

import org.apache.pekko.actor.{ ActorRef, Props }
import org.apache.pekko.cluster.Cluster
import core.util.SimulationUtil.loadSimulationConfig

import scala.concurrent.duration.*
import scala.concurrent.Future
import scala.util.{Failure, Success, Try}
import org.htc.protobuf.core.entity.event.control.execution.{DestructEvent, PrepareSimulationEvent, StartSimulationTimeEvent, StopSimulationEvent}
import org.htc.protobuf.core.entity.event.control.execution.data.StartSimulationTimeData
import org.interscity.htc.core.actor.manager.load.{LoadDataManager, ProgressiveLoadDataManager}
import org.interscity.htc.core.actor.manager.load.PostLoadRegistrationManager
import org.interscity.htc.core.actor.manager.report.ReportManager
import org.interscity.htc.core.actor.manager.time.{ ConservativeGlobalTimeManager, OptimisticGlobalTimeManager }
import org.interscity.htc.core.api.SimulatorSettingsRegistry
import org.interscity.htc.core.enumeration.TimeManagerTypeEnum
import org.interscity.htc.core.entity.configuration.Simulation
import org.interscity.htc.core.entity.configuration.ActorDataSource
import org.interscity.htc.core.entity.event.control.execution.TimeManagerRegisterEvent
import org.interscity.htc.core.entity.event.control.load.{EagerLoadDataReadyEvent, LoadDataEvent, PostLoadRegistrationDoneEvent, ProgressiveLoadManagerRegisteredEvent, ProgressiveLoadingCompleteEvent, RegisterProgressiveLoadManagerEvent, ScenarioPreflightValidationFailedEvent, SimulationConfigLoadFailedEvent, SimulationConfigLoadedEvent, StartPostLoadRegistrationPhaseEvent, StartProgressiveLoadingEvent, TickWindowReady}
import org.interscity.htc.core.entity.event.control.report.RegisterReportersEvent
import org.interscity.htc.core.entity.event.control.loadbalance.LoadBalanceReadyEvent
import org.interscity.htc.core.actor.manager.loadbalance.LoadBalanceManager
import org.interscity.htc.core.entity.control.loadbalance.SpatialBounds
import org.interscity.htc.core.enumeration.LoadBalanceStrategyEnum
import org.interscity.htc.core.metrics.core.PhaseMetrics
import org.interscity.htc.core.util.ManagerConstantsUtil
import org.interscity.htc.core.util.ManagerConstantsUtil.{GLOBAL_TIME_MANAGER_ACTOR_NAME, LOAD_BALANCE_MANAGER_ACTOR_NAME, LOAD_MANAGER_ACTOR_NAME, POST_LOAD_REGISTRATION_MANAGER_ACTOR_NAME, PROGRESSIVE_LOAD_MANAGER_ACTOR_NAME, REPORT_MANAGER_ACTOR_NAME, SIMULATION_MANAGER_ACTOR_NAME, SNAPSHOT_MANAGER_ACTOR_NAME, WARM_UP_MANAGER_ACTOR_NAME}
import org.interscity.htc.core.actor.manager.warmup.WarmUpManager
import org.interscity.htc.core.entity.event.control.warmup.{StartWarmUpWorkersEvent, WarmUpAllDoneEvent}

import scala.collection.mutable
import scala.compiletime.uninitialized

class SimulationManager(
  val simulationPath: String = null
) extends BaseManager[DefaultState](
      actorId = SIMULATION_MANAGER_ACTOR_NAME,
      timeManager = null
    ) {
  override protected val config = context.system.settings.config

  private var timeSingletonManager: ActorRef = uninitialized
  private var poolTimeManager: ActorRef = uninitialized
  private var loadManager: ActorRef = uninitialized
  private var postLoadRegistrationManager: ActorRef = uninitialized
  private var reportManager: ActorRef = uninitialized
  private var warmUpManager: ActorRef = _
  private var loadBalanceManager: ActorRef = _
  private var snapshotManager: ActorRef = _
  private var progressiveLoadManager: ActorRef = _
  private var configuration: Simulation = uninitialized
  private var selfProxy: ActorRef = null
  private var simulationPrepared: Boolean = false
  private var clusterRetryScheduled: Boolean = false
  private var configLoadInProgress: Boolean = false
  private var postLoadPhaseTriggered: Boolean = false
  private var waitingForProgressiveRegistrationAck: Boolean = false
  private var pendingSimulationStartTick: Option[Tick] = None
  private var simulationStartSent: Boolean = false
  private var loadBalanceReady = false
  private var loadDataStarted = false
  private var pendingProgressiveSources: List[ActorDataSource] = List.empty

  private case object RetryPrepareSimulation

  override def handleEvent: Receive = {
    case event: PrepareSimulationEvent          => prepareSimulation(event)
    case event: EagerLoadDataReadyEvent         => handleEagerLoadReady(event)
    case _: WarmUpAllDoneEvent                  => handleWarmUpDone()
    case _: PostLoadRegistrationDoneEvent       => startSimulation()
    case event: ProgressiveLoadManagerRegisteredEvent =>
      handleProgressiveManagerRegistered(event)
    case event: TimeManagerRegisterEvent        => registerPoolTimeManager(event)
    case event: RegisterReportersEvent          => registerReporters(event)
    case event: ProgressiveLoadingCompleteEvent => handleProgressiveLoadingComplete(event)
    case event: LoadBalanceReadyEvent           => handleLoadBalanceReady(event)
    case _: StopSimulationEvent                 => handleStopSimulation()
    case core.runtime.accounting.RuntimeFailure(reason) =>
      logError(s"[SIMULATION-FAILED] $reason")
      core.api.SimulationController.markFailed()
    case RetryPrepareSimulation =>
      clusterRetryScheduled = false
      prepareSimulation()
    case event: SimulationConfigLoadedEvent     => onSimulationConfigLoaded(event)
    case event: SimulationConfigLoadFailedEvent => onSimulationConfigLoadFailed(event)
    case event: ScenarioPreflightValidationFailedEvent =>
      onScenarioPreflightValidationFailed(event)
  }

  override def onStart(): Unit = {
    val apiEnabled = sys.env
      .getOrElse(
        "HTC_API_ENABLED",
        try context.system.settings.config.getString("htc.api.enabled")
        catch { case _: Exception => "false" }
      )
      .equalsIgnoreCase("true")

    if (apiEnabled) {
      logInfo(
        "Simulator API enabled — simulation is IDLE. Waiting for POST /api/v1/simulation/start"
      )
    } else {
      getSelfProxy ! PrepareSimulationEvent(configuration = simulationPath)
    }
  }

  private def handleEagerLoadReady(event: EagerLoadDataReadyEvent): Unit = {
    pendingProgressiveSources = event.progressiveSources
    PhaseMetrics.recordPhaseEnd("loading")
    logInfo(
      s"[StartupPhase] eager_load_ready: eagerSources=${event.eagerSourcesLoaded}, " +
        s"progressiveSources=${event.progressiveSources.size}"
    )

    val targets = warmUpTargets()
    if (targets.nonEmpty) {
      PhaseMetrics.recordPhaseStart("warmup")
      val minMembers = context.system.settings.config.getInt("pekko.cluster.min-nr-of-members")
      logInfo(s"[StartupPhase] warmup_started: nodes=$minMembers, targets=$targets")
      warmUpManager = createSingletonManager(
        manager = WarmUpManager.props(getSelfProxy, minMembers),
        name = WARM_UP_MANAGER_ACTOR_NAME,
        terminateMessage = StopSimulationEvent()
      )
      createSingletonProxy(WARM_UP_MANAGER_ACTOR_NAME) ! StartWarmUpWorkersEvent(targets)
    } else {
      logInfo("[StartupPhase] warmup_skipped: no targets configured")
      triggerPostLoadRegistrationPhase()
    }
  }

  private def handleWarmUpDone(): Unit = {
    PhaseMetrics.recordPhaseEnd("warmup")
    logInfo("[StartupPhase] warmup_done")
    triggerPostLoadRegistrationPhase()
  }

  private def triggerPostLoadRegistrationPhase(): Unit = {
    if (postLoadPhaseTriggered) return
    postLoadPhaseTriggered = true
    PhaseMetrics.recordPhaseStart("post_load_registration")
    logInfo("[StartupPhase] post_load_registration_started")
    createSingletonProxy(POST_LOAD_REGISTRATION_MANAGER_ACTOR_NAME) ! StartPostLoadRegistrationPhaseEvent
  }

  private def startSimulation(): Unit = {
    PhaseMetrics.recordPhaseEnd("post_load_registration")
    logInfo("[StartupPhase] post_load_registration_done")
    createSingletonProxy(LOAD_MANAGER_ACTOR_NAME) ! StopSimulationEvent()
    doStartSimulation(pendingProgressiveSources)
  }

  /** Returns the list of warm-up targets from application.conf / HTC_WARMUP_TARGETS env var,
    * merged with targets declared in simulation.json (configuration.warmupTargets).
    * Format: comma-separated "pkg.Object#method" strings.
    */
  private def warmUpTargets(): List[String] = {
    val fromConf = scala.util.Try(config.getString("htc.warmup.targets")).getOrElse("")
    val confTargets = fromConf.split(",").map(_.trim).filter(_.nonEmpty).toList
    val simTargets = configuration.warmupTargets
    (confTargets ++ simTargets).distinct
  }

  private def doStartSimulation(progressiveSources: List[ActorDataSource]): Unit = {
    val globalTimeManagerProxy = createSingletonProxy(GLOBAL_TIME_MANAGER_ACTOR_NAME)
    pendingSimulationStartTick = Some(configuration.startTick)
    simulationStartSent = false

    if (progressiveSources.nonEmpty) {
      PhaseMetrics.recordPhaseStart("progressive_loading")
      logInfo(
        s"[StartupPhase] progressive_bootstrap_started: sources=${progressiveSources.size}"
      )

      val lookAheadTicks = configuration.duration match {
        case d if d > 10000 => 10_000L
        case d if d > 1000  => 5_000L
        case _              => 1_000L
      }

      progressiveLoadManager = createSingletonProgressiveLoadManager()
      val progressiveProxy = createSingletonProxy(PROGRESSIVE_LOAD_MANAGER_ACTOR_NAME)

      globalTimeManagerProxy ! RegisterProgressiveLoadManagerEvent(
        progressiveLoadManager = progressiveProxy,
        lookAheadTicks = lookAheadTicks,
        ackTo = Some(getSelfProxy)
      )

      waitingForProgressiveRegistrationAck = true
      logInfo("[StartupPhase] waiting_gtm_progressive_registration_ack")

      progressiveProxy ! StartProgressiveLoadingEvent(
        progressiveSources = progressiveSources,
        timeManagerRef = globalTimeManagerProxy,
        lookAheadTicks = lookAheadTicks
      )
      logInfo("[StartupPhase] progressive_loader_start_sent")
      return
    } else {
      logInfo("[StartupPhase] no_progressive_sources: skipping progressive loading")
    }
    sendStartSimulation(globalTimeManagerProxy)
  }

  private def handleProgressiveManagerRegistered(
    event: ProgressiveLoadManagerRegisteredEvent
  ): Unit = {
    if (!waitingForProgressiveRegistrationAck) {
      logDebug(
        s"Ignoring unexpected ProgressiveLoadManagerRegisteredEvent (lookAhead=${event.lookAheadTicks})"
      )
      return
    }

    waitingForProgressiveRegistrationAck = false
    logInfo(s"[StartupPhase] gtm_progressive_registration_ack: lookAhead=${event.lookAheadTicks}")
    sendStartSimulation(createSingletonProxy(GLOBAL_TIME_MANAGER_ACTOR_NAME))
  }

  private def sendStartSimulation(globalTimeManagerProxy: ActorRef): Unit = {
    if (simulationStartSent) return
    val startTick = pendingSimulationStartTick.getOrElse(configuration.startTick)
    simulationStartSent = true
    pendingSimulationStartTick = None

    logInfo("[StartupPhase] simulation_start_request_sent_to_gtm")
    globalTimeManagerProxy ! StartSimulationTimeEvent(
      startTick = startTick,
      actorRef = getPath,
      data = Some(StartSimulationTimeData(startTime = System.currentTimeMillis()))
    )
    if (loadBalanceManager != null) createSingletonProxy(LOAD_BALANCE_MANAGER_ACTOR_NAME) !
      StartSimulationTimeEvent(startTick = startTick)
  }

  private def getSelfProxy: ActorRef =
    if (selfProxy == null) {
      selfProxy = createSingletonProxy(SIMULATION_MANAGER_ACTOR_NAME)
      selfProxy
    } else {
      selfProxy
    }

  private def registerReporters(event: RegisterReportersEvent): Unit = {
    reporters = event.reporters
    startLoadData()
  }

  private var runtimeCoordinator: Option[ActorRef] = None

  private def registerPoolTimeManager(event: TimeManagerRegisterEvent): Unit = {
    poolTimeManager = event.actorRef
    runtimeCoordinator = event.runtimeCoordinator
    startLoadData()
  }

  private def startLoadData(): Unit =
    if (!loadDataStarted && poolTimeManager != null && reporters != null &&
      (!config.getBoolean("htc.load-balance-manager.enabled") || loadBalanceReady)) {
      loadDataStarted = true
      PhaseMetrics.recordPhaseStart("loading")
      loadManager = createSingletonLoadManager()
      createSingletonProxy(SNAPSHOT_MANAGER_ACTOR_NAME) ! SnapshotManager
        .RegisterSnapshotContextEvent(
          timeManagers = mutable.Map(configuration.timeManagerType -> poolTimeManager),
          reporters = reporters
        )
      logInfo(s"Sending LoadDataEvent with ${configuration.actorsDataSources.size} data sources")
      createSingletonProxy(LOAD_MANAGER_ACTOR_NAME) ! LoadDataEvent(
        actorRef = selfProxy,
        actorsDataSources = configuration.actorsDataSources,
        postLoadRegistrationClasses = configuration.postLoadRegistrationClasses
      )
    } else {
      logWarn(
        s"Not ready to load data: poolTimeManager=${poolTimeManager != null}, reporters=${reporters != null}"
      )
    }

  private def prepareSimulation(event: PrepareSimulationEvent): Unit = {
    PhaseMetrics.recordPhaseStart("config_load")
    if (configuration == null && !configLoadInProgress) {
      configLoadInProgress = true
      val ioDispatcher = context.system.dispatchers.lookup("pekko.actor.io-dispatcher")
      Future(loadSimulationConfig(event.configuration))(ioDispatcher).onComplete {
        case Success(loadedConfiguration) =>
          self ! SimulationConfigLoadedEvent(loadedConfiguration)
        case Failure(cause) =>
          self ! SimulationConfigLoadFailedEvent(cause)
      }(context.system.dispatcher)
      logInfo("Loading simulation configuration on io-dispatcher...")
      return
    }

    if (configuration == null) {
      return
    }

    prepareSimulation()
  }

  private def onSimulationConfigLoaded(event: SimulationConfigLoadedEvent): Unit = {
    PhaseMetrics.recordPhaseEnd("config_load")
    configuration = event.config
    configLoadInProgress = false
    core.util.SimulationUtil.installLocalScenarioSettings(configuration)
    prepareSimulation()
  }

  private def onSimulationConfigLoadFailed(event: SimulationConfigLoadFailedEvent): Unit = {
    configLoadInProgress = false
    logError(s"Failed to load simulation configuration: ${event.cause.getMessage}", event.cause)
    selfDestruct()
  }

  /** A scenario-wide mode-decision-engine pre-flight check failed (see
    * `core.actor.manager.load.ScenarioPreflightValidator`) — abort the whole simulation the same
    * way an unparsable `simulation.json` does. This always arrives before any Person/Node/Link
    * actor has been created, since both `LoadDataManager` and `ProgressiveLoadDataManager` run the
    * check before creating `creatorRef`/`creatorPoolRef`.
    */
  private def onScenarioPreflightValidationFailed(event: ScenarioPreflightValidationFailedEvent): Unit = {
    logError(s"Scenario load aborted: ${event.error.message}")
    selfDestruct()
  }

  private def prepareSimulation(): Unit = {
    if (simulationPrepared) {
      return
    }

    val cluster = Cluster(context.system)
    val members = cluster.state.members.filter(_.status == org.apache.pekko.cluster.MemberStatus.Up)
    val minMembers = context.system.settings.config.getInt("pekko.cluster.min-nr-of-members")
    logInfo(
      s"Cluster state at simulation startup: ${members.size} Up members " +
        s"(min-nr-of-members=$minMembers), selfAddress=${cluster.selfAddress}, " +
        s"leader=${cluster.state.leader.getOrElse("none")}"
    )

    if (members.size < minMembers) {
      if (!clusterRetryScheduled) {
        implicit val ec: scala.concurrent.ExecutionContext = context.system.dispatcher
        clusterRetryScheduled = true
        logWarn(
          s"Waiting for cluster quorum before starting simulation: " +
            s"${members.size}/$minMembers Up members. Retrying in 5 seconds."
        )
        context.system.scheduler.scheduleOnce(5.seconds, self, RetryPrepareSimulation)
      }
      return
    }

    clusterRetryScheduled = false
    simulationPrepared = true

    logInfo(
      s"Run simulation - Configuration loaded with ${configuration.actorsDataSources.size} data sources"
    )
    timeSingletonManager = createSingletonTimeManager()
    reportManager = createSingletonReportManager()
    snapshotManager = createSingletonSnapshotManager()
    postLoadRegistrationManager = createSingletonPostLoadRegistrationManager()
    createLoadBalanceManagerIfEnabled()
  }

  private def createSingletonTimeManager(): ActorRef =
    createSingletonManager(
      manager = timeManagerProps(),
      name = GLOBAL_TIME_MANAGER_ACTOR_NAME,
      terminateMessage = StopSimulationEvent()
    )

  private def timeManagerProps(): Props =
    if (configuration.timeManagerType == TimeManagerTypeEnum.TIME_WARP) {
      val config = context.system.settings.config
      OptimisticGlobalTimeManager.props(
        simulationDuration = configuration.duration,
        simulationManager = getSelfProxy,
        gvtMargin = SimulatorSettingsRegistry.getInt("htc.time-warp.gvt-margin", config).toLong,
        plateauRoundsRequired = SimulatorSettingsRegistry.getInt("htc.time-warp.plateau-rounds-required", config)
      )
    } else {
      ConservativeGlobalTimeManager.props(
        simulationDuration = configuration.duration,
        extendSimulationIfPendingEventsAfterEnd =
          configuration.extendSimulationIfPendingEventsAfterEnd,
        simulationManager = getSelfProxy
      )
    }

  private def createSingletonReportManager(): ActorRef =
    createSingletonManager(
      manager = ReportManager.props(
        simulationManager = getSelfProxy,
        timeManager = createSingletonProxy(LOAD_MANAGER_ACTOR_NAME),
        startRealTime = configuration.startRealTime
      ),
      name = REPORT_MANAGER_ACTOR_NAME,
      terminateMessage = StopSimulationEvent()
    )

  private def createSingletonSnapshotManager(): ActorRef =
    createSingletonManager(
      manager = SnapshotManager.props(
        timeManager = createSingletonProxy(GLOBAL_TIME_MANAGER_ACTOR_NAME)
      ),
      name = SNAPSHOT_MANAGER_ACTOR_NAME,
      terminateMessage = StopSimulationEvent()
    )

  private def createSingletonLoadManager(): ActorRef =
    createSingletonManager(
      manager = LoadDataManager.props(
        timeSingletonManager = timeSingletonManager,
        poolTimeManager = poolTimeManager,
        timeManagerType = configuration.timeManagerType,
        simulationManager = selfProxy,
        poolReporters = reporters,
        runtimeCoordinator = runtimeCoordinator
      ),
      name = LOAD_MANAGER_ACTOR_NAME,
      terminateMessage = StopSimulationEvent()
    )

  private def createSingletonPostLoadRegistrationManager(): ActorRef =
    createSingletonManager(
      manager = PostLoadRegistrationManager.props(
        simulationManager = getSelfProxy
      ),
      name = POST_LOAD_REGISTRATION_MANAGER_ACTOR_NAME,
      terminateMessage = StopSimulationEvent()
    )

  /** Creates the LoadBalanceManager singleton if enabled in configuration. */
  private def createLoadBalanceManagerIfEnabled(): Unit = {
    val loadBalanceEnabled =
      try
        config.getBoolean("htc.load-balance-manager.enabled")
      catch {
        case _: Exception => false
      }

    if (loadBalanceEnabled) {
      val settings = core.actor.manager.loadbalance.strategy.LoadBalanceSettings.read(config)

      loadBalanceManager = createSingletonManager(
        manager = LoadBalanceManager.props(
          timeManager = createSingletonProxy(GLOBAL_TIME_MANAGER_ACTOR_NAME),
          simulationManager = getSelfProxy,
          strategyType = settings.strategyType,
          worldBounds = settings.worldBounds,
          strategyConfig = settings.strategyConfig
        ),
        name = LOAD_BALANCE_MANAGER_ACTOR_NAME,
        terminateMessage = StopSimulationEvent()
      )

      logInfo(s"LoadBalanceManager created with strategy: ${settings.strategyName}")
    } else {
      logInfo("LoadBalanceManager disabled. Using default Pekko shard allocation.")
    }
  }

  /** Handles notification that LoadBalanceManager is ready. */
  private def handleLoadBalanceReady(event: LoadBalanceReadyEvent): Unit = {
    loadBalanceReady = true
    logInfo("LoadBalanceManager is ready and operational.")
    startLoadData()
  }

  private def createSingletonProgressiveLoadManager(): ActorRef =
    createSingletonManager(
      manager = ProgressiveLoadDataManager.props(
        poolTimeManager = poolTimeManager,
        timeManagerType = configuration.timeManagerType,
        simulationManager = getSelfProxy,
        poolReporters = reporters,
        runtimeCoordinator = runtimeCoordinator
      ),
      name = PROGRESSIVE_LOAD_MANAGER_ACTOR_NAME,
      terminateMessage = StopSimulationEvent()
    )

  private def handleProgressiveLoadingComplete(event: ProgressiveLoadingCompleteEvent): Unit = {
    PhaseMetrics.recordPhaseEnd("progressive_loading")
    logInfo(
      s"Progressive loading complete: ${event.totalActorsCreated} actors created during simulation"
    )
    val globalTimeManagerProxy = createSingletonProxy(GLOBAL_TIME_MANAGER_ACTOR_NAME)
    globalTimeManagerProxy ! TickWindowReady(
      readyUpToTick = Long.MaxValue,
      actorsCreated = 0
    )
  }

  private def handleStopSimulation(): Unit = {
    PhaseMetrics.recordPhaseEnd("simulation")
    logInfo("Received StopSimulationEvent. Stopping simulation managers gracefully")
    try {
      if (loadBalanceManager != null) {
        createSingletonProxy(LOAD_BALANCE_MANAGER_ACTOR_NAME) ! StopSimulationEvent()
      }
      if (loadManager != null) {
        createSingletonProxy(LOAD_MANAGER_ACTOR_NAME) ! StopSimulationEvent()
      }
      if (postLoadRegistrationManager != null) {
        createSingletonProxy(POST_LOAD_REGISTRATION_MANAGER_ACTOR_NAME) ! StopSimulationEvent()
      }
      if (progressiveLoadManager != null) {
        createSingletonProxy(PROGRESSIVE_LOAD_MANAGER_ACTOR_NAME) ! StopSimulationEvent()
      }
      if (reportManager != null) {
        createSingletonProxy(REPORT_MANAGER_ACTOR_NAME) ! StopSimulationEvent()
      }
      if (timeSingletonManager != null) {
        createSingletonProxy(GLOBAL_TIME_MANAGER_ACTOR_NAME) ! StopSimulationEvent()
      }
    } catch {
      case e: Exception =>
        logError(s"Error while forwarding StopSimulationEvent: ${e.getMessage}", e)
    }
    selfDestruct()
  }
}

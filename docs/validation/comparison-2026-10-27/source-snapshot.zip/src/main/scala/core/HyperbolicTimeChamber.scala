package org.interscity.htc
package core

import org.apache.pekko.actor.Props
import org.apache.pekko.actor.{ Actor, ActorSystem, DeadLetter }
import org.apache.pekko.cluster.Cluster
import org.apache.pekko.cluster.sharding.ClusterSharding
import org.htc.protobuf.core.entity.event.control.execution.StopSimulationEvent
import org.apache.pekko.cluster.singleton.{ ClusterSingletonManager, ClusterSingletonManagerSettings }
import org.apache.pekko.management.scaladsl.PekkoManagement
import org.apache.pekko.management.cluster.bootstrap.ClusterBootstrap
import org.interscity.htc.core.actor.manager.SimulationManager
import org.interscity.htc.core.api.ConfigApiServer
import org.interscity.htc.core.metrics.MetricsServer
import org.interscity.htc.core.metrics.system.InfrastructureMetrics
import org.interscity.htc.core.util.ManagerConstantsUtil.SIMULATION_MANAGER_ACTOR_NAME
import org.interscity.htc.core.util.{ ManagerConstantsUtil, SimulationUtil }

import scala.concurrent.Await
import scala.concurrent.duration.Duration

/** Subscribes to the Pekko DeadLetter stream and increments the Prometheus counter. Also logs
  * message type for diagnostics when dead letters are persistent.
  */
private class DeadLetterListener extends Actor {
  import org.slf4j.LoggerFactory
  private val log = LoggerFactory.getLogger(classOf[DeadLetterListener])

  override def receive: Receive = {
    case dl: DeadLetter =>
      val path = dl.recipient.path
      val recipientType = path.elements.toList match {
        case _ :: "sharding" :: shardRegion :: _ => shardRegion
        case elems                               => elems.lastOption.getOrElse("unknown")
      }
      val messageType = dl.message.getClass.getSimpleName
      InfrastructureMetrics.deadLetters.labels(recipientType, messageType).inc()
      log.debug(
        "Dead letter: msg={} from={} to={}",
        messageType,
        dl.sender.path,
        path
      )
  }
}

object HyperbolicTimeChamber {

  def start(): Unit = {
    val metricsPort = sys.env.get("HTC_METRICS_PORT").flatMap(_.toIntOption).getOrElse(9001)
    core.metrics.MetricsServer.start(metricsPort)

    val system = ActorSystem("hyperbolic-time-chamber")

    ConfigApiServer.start(system)

    val deadLetterListener = system.actorOf(Props(new DeadLetterListener), "dead-letter-listener")
    system.eventStream.subscribe(deadLetterListener, classOf[DeadLetter])

    try {
      val simulationConfig = SimulationUtil.loadSimulationConfig()
      actor.manager.RandomSeedManager.initialize(simulationConfig)
      system.log.info(
        s"RandomSeedManager initialized using seed: ${simulationConfig.randomSeed.getOrElse("timestamp-based")}"
      )
    } catch {
      case e: Exception =>
        system.log.warning(
          s"It was not possible load random seed configuration for RandomSeedManager: ${e.getMessage}"
        )
        system.log.warning("RandomSeedManager will be initialized with timestamp-based seed")
    }

    PekkoManagement(system).start()
    ClusterBootstrap(system).start()

    val cluster = Cluster(system)

    ClusterSharding(system)

    cluster.registerOnMemberUp {
      system.log.info(s"Member is up: ${cluster.selfMember}")
    }

    cluster.registerOnMemberRemoved {
      system.log.info(s"Member is removed: ${cluster.selfMember}")
    }

    try
      SimulationUtil.startShards(system)
    catch {
      case e: Exception if core.api.SimulationController.isApiWaitEnabled =>
        // API mode's whole point is to boot with no scenario chosen yet (see
        // ConfigApiServer's doc: "Simulation is IDLE — send POST /api/v1/simulation/start to
        // begin"), but startShards() needs a scenario's actorsDataSources to know which
        // classTypes to register as shard regions. Previously this threw uncaught here and
        // crashed the whole JVM before the REST API (already bound above via
        // ConfigApiServer.start) ever became reachable. Deferred: SimulationController.start
        // calls startShards again once a scenario is actually resolved (from the /start
        // request's configFile, or ApiConfigRegistry after /api/v1/scenarios/{name}/load).
        system.log.warning(
          s"startShards deferred: no scenario configured yet at boot (${e.getMessage}). " +
            "Shard regions will be registered when a scenario is started via the API."
        )
      case scala.util.control.NonFatal(error) =>
        system.log.error(error, "[SIMULATION-FAILED] Shard startup rejected: {}", error.getMessage)
        MetricsServer.stop()
        system.terminate()
        throw error
    }

    actor.manager.loadbalance.migration.MigrationWindowSubscriber.startOnNode(system)

    val simulation = system.actorOf(
      ClusterSingletonManager.props(
        singletonProps = Props(
          SimulationManager()
        ),
        terminationMessage = StopSimulationEvent(),
        settings = ClusterSingletonManagerSettings(system)
      ),
      name = SIMULATION_MANAGER_ACTOR_NAME
    )

    // Everything above is async actor-system setup — start() otherwise returns immediately,
    // and main()'s thread finishing would exit the JVM right after startup under `sbt run`/
    // `runMain` (confirmed directly: a single-node cluster formed, then the JVM exited before
    // the simulation ever ran). The assembled-jar/`java -jar` path has stayed alive incidentally
    // via Pekko's non-daemon dispatcher threads; blocking here makes that explicit instead of
    // relying on it.
    Await.ready(system.whenTerminated, Duration.Inf)
  }
}

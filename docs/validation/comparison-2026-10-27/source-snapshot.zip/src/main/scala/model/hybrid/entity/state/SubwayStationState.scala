package org.interscity.htc
package model.hybrid.entity.state

import core.types.Tick

import org.htc.protobuf.core.entity.actor.Identify
import org.interscity.htc.core.entity.state.BaseState
import org.interscity.htc.model.hybrid.entity.state.enumeration.SubwayStationStateEnum
import org.interscity.htc.model.hybrid.entity.state.enumeration.SubwayStationStateEnum.Start
import org.interscity.htc.model.hybrid.entity.state.model.{ SubwayInformation, SubwayLineInformation, SubwayRouteEntry }

import scala.collection.mutable

case class SubwayStationState(
  startTick: Tick,
  name: String,
  nodeId: Long,
  terminal: Boolean,
  garage: Boolean,
  lines: mutable.Map[String, SubwayLineInformation],
  subways: mutable.Map[String, mutable.Queue[SubwayInformation]],
  linesRoute: mutable.Map[String, mutable.Queue[SubwayRouteEntry]],
  people: mutable.Map[String, mutable.Seq[Identify]] = mutable.Map.empty,
  var status: SubwayStationStateEnum = Start
) extends BaseState(startTick = startTick)

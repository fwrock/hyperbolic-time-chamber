# Scenario Modeling Guide — Hybrid Urban Mobility Model

This guide explains how to define and structure a simulation scenario for the **Hybrid Micro-Meso Urban Mobility Model** in HTC. It covers every entity type, its JSON schema, the dependency graph between entities, and the `simulation.json` manifest that ties everything together.

---

## Table of Contents

1. [Overview](#1-overview)
2. [Scenario File Structure](#2-scenario-file-structure)
3. [simulation.json — Manifest](#3-simulationjson--manifest)
4. [Entity Reference](#4-entity-reference)
   - [4.1 Node](#41-node)
   - [4.2 Link (Road)](#42-link-road)
   - [4.3 RailLink](#43-raillink)
   - [4.4 TrafficSignal](#44-trafficsignal)
   - [4.5 BusStop](#45-busstop)
   - [4.6 BusStation](#46-busstation)
   - [4.7 Bus](#47-bus)
   - [4.8 SubwayStation](#48-subwaystation)
   - [4.9 Subway (Train)](#49-subway-train)
   - [4.10 Car](#410-car)
   - [4.11 Person](#411-person)
5. [city_map.json](#5-city_mapjson)
6. [ID Naming Conventions](#6-id-naming-conventions)
7. [Dependency Graph](#7-dependency-graph)
8. [Loading Strategies and Lifecycle](#8-loading-strategies-and-lifecycle)
9. [Simulation Modes: MESO vs MICRO](#9-simulation-modes-meso-vs-micro)
10. [Minimal Working Example](#10-minimal-working-example)
11. [Scaling Data Files](#11-scaling-data-files)
12. [Generating Scenarios from Real Data](#12-generating-scenarios-from-real-data)
13. [Dynamic Mode Choice](#13-dynamic-mode-choice)

---

## 1. Overview

A HTC hybrid scenario is a **collection of JSON files** that define the road network, transit infrastructure, and agents (persons and vehicles). The simulator reads these files at startup, instantiates one actor per entity, and then runs the discrete-event simulation.

The entity types available in the hybrid model are:

| Actor class | Role |
|---|---|
| `hybrid.actor.Node` | Road / rail intersection or endpoint |
| `hybrid.actor.Link` | Directed road segment (MESO or MICRO) |
| `hybrid.actor.RailLink` | Directed rail segment (subway-only) |
| `hybrid.actor.TrafficSignal` | Traffic signal controller |
| `hybrid.actor.BusStop` | Physical bus stop (passengers wait here) |
| `hybrid.actor.BusStation` | Bus route manager (spawns Bus actors) |
| `hybrid.actor.Bus` | Bus vehicle following a fixed route |
| `hybrid.actor.SubwayStation` | Subway station (spawns Subway actors) |
| `hybrid.actor.Subway` | Subway/metro train following rail links |
| `hybrid.actor.Car` | Private car (activated by Person) |
| `hybrid.actor.Person` | Agent that walks a plan of activities/legs, resolving mode choice as needed |

---

## 2. Scenario File Structure

```
<scenario_name>/
├── simulation.json            ← manifest (required)
├── scenario_metadata.json     ← metadata/statistics (optional)
├── GENERATION_REPORT.md       ← human-readable generation report (optional)
└── data/
    ├── city_map.json          ← in-memory graph (required)
    ├── transit_map.json       ← transit stop index for dynamic mode choice (optional)
    ├── nodes_0.json           ← Node actors (may be split into multiple files)
    ├── nodes_1.json
    ├── links_0.json           ← Link actors (may be split)
    ├── links_1.json
    ├── rail_links_0.json      ← RailLink actors
    ├── traffic_signals_0.json ← TrafficSignal actors
    ├── bus_stops_0.json       ← BusStop actors
    ├── bus_stations_0.json    ← BusStation actors
    ├── buses_0.json           ← Bus actors (pre-defined departures)
    ├── subway_stations_0.json ← SubwayStation actors
    ├── persons_0.json         ← Person agents
    └── cars_0.json            ← Car assets (owned by Persons)
```

> **Note:** Large entity sets (e.g., nodes, links) can be split across numbered files (`nodes_0.json`, `nodes_1.json`, …). Each file is registered separately in `simulation.json`.

---

## 3. simulation.json — Manifest

`simulation.json` is the single entry point. It defines simulation timing and lists every data source.

```json
{
  "id": "my_scenario",
  "name": "My City Scenario",
  "description": "A description of the scenario.",
  "startTick": 0,
  "endTick": 86400,
  "startRealTime": "2025-01-01T00:00:00.000",
  "timeUnit": "seconds",
  "timeStep": 1.0,
  "duration": 86400,
  "tickDuration": 1.0,
  "randomSeed": 42,
  "cityMapFile": "/app/.../data/city_map.json",
  "postLoadRegistrationClasses": [
    "org.interscity.htc.model.hybrid.actor.BusStop",
    "org.interscity.htc.model.hybrid.actor.SubwayStation"
  ],
  "actorsDataSources": [
    {
      "id": "nodes_0",
      "classType": "hybrid.actor.Node",
      "creationType": "LoadBalancedDistributed",
      "loadingStrategy": "EAGER",
      "entityLifecycle": "STATIC",
      "dataSource": {
        "sourceType": "json",
        "info": { "path": "/app/.../data/nodes_0.json" }
      }
    },
    {
      "id": "links_0",
      "classType": "hybrid.actor.Link",
      "creationType": "LoadBalancedDistributed",
      "loadingStrategy": "EAGER",
      "entityLifecycle": "STATIC",
      "dataSource": {
        "sourceType": "json",
        "info": { "path": "/app/.../data/links_0.json" }
      }
    },
    {
      "id": "persons_0",
      "classType": "hybrid.actor.Person",
      "creationType": "LoadBalancedDistributed",
      "loadingStrategy": "PROGRESSIVE",
      "entityLifecycle": "DYNAMIC",
      "dataSource": {
        "sourceType": "json",
        "info": { "path": "/app/.../data/persons_0.json" }
      }
    }
  ]
}
```

### Key fields

| Field | Description |
|---|---|
| `startTick` / `endTick` | Simulation time window (usually `0` to `86400` for a full day in seconds) |
| `tickDuration` | Duration of one tick in real-world seconds (`1.0` = 1 s/tick) |
| `cityMapFile` | Declared for documentation purposes, but not currently read by the loader — the road-map path actually used is `htc.mobility.city-map-file` / `HTC_MOBILITY_CITY_MAP_FILE` (see below) |
| `postLoadRegistrationClasses` | Classes that must register with their parent node after load (BusStop, BusStation, SubwayStation) |
| `loadingStrategy` | `EAGER` = load at startup; `PROGRESSIVE` = load on demand |
| `entityLifecycle` | `STATIC` = actor lives for the full simulation; `DYNAMIC` = actor may be created/destroyed |

### `dataSource.sourceType`

Each entry in `actorsDataSources` picks its own `dataSource.sourceType` independently, so a single
scenario can freely mix formats across files:

| `sourceType` | `info.path` points at | Backing strategy classes |
|---|---|---|
| `"json"` | a `.json` file (array of entity envelopes, as in [§4](#4-entity-reference)) | `JsonLoadData` (EAGER) / `ProgressiveJsonLoadData` (PROGRESSIVE) |
| `"sqlite"` | a `.db` file (SQLite, `actor_simulation` table) | `SqliteLoadData` (EAGER) / `ProgressiveSqliteLoadData` (PROGRESSIVE) |

```json
{
  "id": "person-source",
  "classType": "person",
  "loadingStrategy": "PROGRESSIVE",
  "entityLifecycle": "DYNAMIC",
  "dataSource": { "sourceType": "sqlite", "info": { "path": "/data/person.db" } }
}
```

Both formats carry exactly the same per-entity data — a `.db` is produced from the equivalent
`.json` (and vice versa) via `tools/scenario-db-converter/convert.py`, see [§11](#11-scaling-data-files).
Pick `sqlite` for any source you're loading `PROGRESSIVE`: the `.db`'s `actor_simulation` table has
an indexed `start_tick` column, so each tick window is fetched with a direct
`WHERE start_tick BETWEEN ? AND ?` query instead of the full-file re-scan the JSON path repeats per
window — see [§8](#8-loading-strategies-and-lifecycle) for why that matters at scale. For `EAGER`
sources (loaded once, in full, at startup) the two formats are roughly equivalent — `json` remains
the simpler default there.

---

## 4. Entity Reference

Every entity follows the same envelope schema. `id` is a bare `Long` — see
[§6](#6-id-naming-conventions) for the full id contract (the `"htcaid:..."` strings still shown
in some of the worked examples below are a pre-existing inconsistency in this doc, not the
current format):

```json
{
  "id": 42,
  "typeActor": "hybrid.actor.<ActorClass>",
  "data": {
    "dataType": "model.hybrid.entity.state.<StateClass>",
    "content": { ... }
  },
  "dependencies": { ... }
}
```

---

### 4.1 Node

Represents a road intersection, endpoint, or any geographic point in the network.

```json
{
  "id": "htcaid:node;42",
  "typeActor": "hybrid.actor.Node",
  "data": {
    "dataType": "model.hybrid.entity.state.NodeState",
    "content": {
      "startTick": 0,
      "latitude": 7393121.10,
      "longitude": 326090.09,
      "links": [],
      "connections": {},
      "signals": {},
      "busStops": {},
      "subwayStations": {},
      "signalWaitingCounts": {},
      "scheduleOnTimeManager": false
    }
  },
  "dependencies": {}
}
```

**Content fields:**

| Field | Type | Description |
|---|---|---|
| `latitude` / `longitude` | `Double` | Coordinates in the project's CRS (EPSG:32723 UTM metres recommended) |
| `links` | `List[String]` | Outgoing link IDs (populated at runtime by links registering themselves) |
| `connections` | `Map[String, Identify]` | Link-to-node routing table (populated at runtime) |
| `signals` | `Map[String, SignalState]` | Current signal state per incoming link (updated by TrafficSignal) |
| `busStops` | `Map[String, Identify]` | Bus stops registered at this node |
| `subwayStations` | `Map[String, Identify]` | Subway stations registered at this node |
| `signalWaitingCounts` | `Map[String, Int]` | Waiting vehicle count per signal link |
| `scheduleOnTimeManager` | `Boolean` | Usually `false` for static infrastructure nodes |

> **Tip:** `latitude`/`longitude` are used for routing and GPS calculations. Keep them consistent with the CRS used in `city_map.json`.

---

### 4.2 Link (Road)

A directed road segment connecting two nodes. Supports both MESO (aggregate) and MICRO (individual vehicle) simulation.

```json
{
  "id": "htcaid:link;1001",
  "typeActor": "hybrid.actor.Link",
  "data": {
    "dataType": "model.hybrid.entity.state.LinkState",
    "content": {
      "startTick": 0,
      "from": "htcaid:node;10",
      "to": "htcaid:node;11",
      "length": 250.0,
      "lanes": 2,
      "speedLimit": 50.0,
      "freeSpeed": 50.0,
      "capacity": 1800.0,
      "simulationMode": "MESO",
      "microTimeStep": 0.1,
      "microTicksPerGlobalTick": 10,
      "laneConfigurations": [
        { "laneId": 0, "type": "normal", "width": 3.5, "speedLimit": null },
        { "laneId": 1, "type": "normal", "width": 3.5, "speedLimit": null }
      ],
      "congestionFactor": 1.0,
      "currentSpeed": 50.0,
      "registered": [],
      "vehiclesByLane": {}
    }
  },
  "dependencies": {
    "from_node": { "id": "htcaid:node;10", "classType": "hybrid.actor.Node" },
    "to_node":   { "id": "htcaid:node;11", "classType": "hybrid.actor.Node" }
  }
}
```

**Content fields:**

| Field | Type | Description |
|---|---|---|
| `from` / `to` | `String` | IDs of the source and destination nodes |
| `length` | `Double` | Segment length in metres |
| `lanes` | `Int` | Number of lanes |
| `speedLimit` | `Double` | Legal speed limit in km/h |
| `freeSpeed` | `Double` | Free-flow speed in km/h (often equal to `speedLimit`) |
| `capacity` | `Double` | Maximum vehicle occupancy (how many vehicles physically fit on the link), used as the denominator in density-based speed/congestion calculations (`SpeedUtil.linkDensitySpeed`, `bprCongestionFactor`) — not a vehicles-per-hour flow rate |
| `simulationMode` | `"MESO"` \| `"MICRO"` | Simulation mode for this link |
| `microTimeStep` | `Double` | Sub-tick duration in seconds (used in MICRO mode) |
| `microTicksPerGlobalTick` | `Int` | Sub-ticks per global tick (e.g., `10` → 0.1 s resolution) |
| `laneConfigurations` | `List` | Per-lane configuration. Types: `normal`, `bus_lane`, `bike_lane` |
| `congestionFactor` | `Double` | Multiplier for congestion calculations (`1.0` = no bias) |

**Dependencies:** Both `from_node` and `to_node` must reference valid Node IDs.

---

### 4.3 RailLink

A directed rail segment used **exclusively** by Subway actors. Road vehicles are rejected by the actor.

```json
{
  "id": "htcaid:rail_link;line_1_segment_0",
  "typeActor": "hybrid.actor.RailLink",
  "data": {
    "dataType": "model.hybrid.entity.state.RailLinkState",
    "content": {
      "from": "htcaid:node;100",
      "to": "htcaid:node;101",
      "length": 1200.0,
      "lanes": 2,
      "speedLimit": 80.0,
      "capacity": 10.0,
      "freeSpeed": 80.0,
      "railType": "SUBWAY",
      "subwayLine": "line_1",
      "fromStation": "htcaid:subwaystation;station_A",
      "toStation": "htcaid:subwaystation;station_B",
      "gradient": 0.0,
      "curvature": 0.0,
      "simulationMode": "MESO",
      "laneConfigurations": [],
      "vehiclesByLane": {},
      "microTimeStep": 0.1,
      "microTicksPerGlobalTick": 10,
      "registered": [],
      "scheduleOnTimeManager": false
    }
  },
  "dependencies": {
    "from_node":    { "id": "htcaid:node;100",               "classType": "hybrid.actor.Node" },
    "to_node":      { "id": "htcaid:node;101",               "classType": "hybrid.actor.Node" },
    "from_station": { "id": "htcaid:subwaystation;station_A", "classType": "hybrid.actor.SubwayStation" },
    "to_station":   { "id": "htcaid:subwaystation;station_B", "classType": "hybrid.actor.SubwayStation" }
  }
}
```

| Field | Description |
|---|---|
| `railType` | Always `"SUBWAY"` for metro/subway lines |
| `subwayLine` | Line identifier — must match the line key in SubwayStation's `lines` map |
| `fromStation` / `toStation` | SubwayStation IDs at each end |
| `gradient` / `curvature` | Physical properties affecting speed (set `0.0` if unknown) |

---

### 4.4 TrafficSignal

Controls the green/red phases for a set of links at one or more nodes.

```json
{
  "id": "htcaid:signal;signal_42",
  "typeActor": "hybrid.actor.TrafficSignal",
  "data": {
    "dataType": "model.hybrid.entity.state.TrafficSignalState",
    "content": {
      "startTick": 0,
      "cycleDuration": 120,
      "offset": 30,
      "nodes": ["htcaid:node;200"],
      "phases": [
        {
          "origin": "htcaid:link;2001",
          "greenStart": 0,
          "greenDuration": 60,
          "state": "Red"
        },
        {
          "origin": "htcaid:link;2002",
          "greenStart": 61,
          "greenDuration": 57,
          "state": "Red"
        }
      ],
      "signalStates": {
        "htcaid:link;2001": { "state": "Red", "remainingTime": 0, "nextTick": 0 },
        "htcaid:link;2002": { "state": "Red", "remainingTime": 0, "nextTick": 0 }
      }
    }
  },
  "dependencies": {
    "htcaid:node;200": { "id": "htcaid:node;200", "classType": "hybrid.actor.Node" }
  }
}
```

| Field | Description |
|---|---|
| `cycleDuration` | Total cycle length in ticks (seconds) |
| `offset` | Phase offset in ticks — used to stagger signals on a corridor |
| `phases[].origin` | Incoming link ID controlled by this phase |
| `phases[].greenStart` | Tick within the cycle when green begins |
| `phases[].greenDuration` | Green duration in ticks |
| `phases[].state` | Initial phase state (always `"Red"` at creation) |
| `signalStates` | Initial state for each controlled link (all `"Red"`) |

> **Note:** `dependencies` is a flat map of `nodeId → {id, classType}` — one entry per signal-controlled node — matching how `TrafficSignal.scala`'s `NodeEventHandler` routes per-node state updates.

---

### 4.5 BusStop

A physical stop where passengers board and alight. One BusStop per stop per direction.

```json
{
  "id": "htcaid:busstop;stop_001",
  "typeActor": "hybrid.actor.BusStop",
  "data": {
    "dataType": "model.hybrid.entity.state.BusStopState",
    "content": {
      "nodeId": "htcaid:node;300",
      "label": "Central Station",
      "people": {}
    }
  },
  "dependencies": {
    "node": { "id": "htcaid:node;300", "classType": "hybrid.actor.Node" }
  }
}
```

| Field | Description |
|---|---|
| `nodeId` | The node where this stop is physically located |
| `label` | Human-readable name — must match the route label used in BusStation |
| `people` | Passenger queues per bus label (populated at runtime) |

> **Important:** `label` is the key that connects BusStop ↔ BusStation ↔ Bus. All three must use the same label string for a given route.

---

### 4.6 BusStation

The route manager for a bus line. Spawns Bus actors according to a schedule and computes routes.

```json
{
  "id": "htcaid:busstation;route_42",
  "typeActor": "hybrid.actor.BusStation",
  "data": {
    "dataType": "model.hybrid.entity.state.BusStationState",
    "content": {
      "startTick": 25140,
      "name": "Route 42 (operator)",
      "origin": "htcaid:node;300",
      "destination": "htcaid:node;350",
      "interval": 1200,
      "busStops": {
        "htcaid:busstop;stop_001": "htcaid:node;300",
        "htcaid:busstop;stop_002": "htcaid:node;310",
        "htcaid:busstop;stop_003": "htcaid:node;350"
      },
      "buses": [
        {
          "actorId": "htcaid:bus;route_42_bus_0",
          "capacity": 80,
          "size": 12.0,
          "numberOfPorts": 2,
          "label": "42"
        }
      ],
      "goingRoute": null,
      "goingBestCost": 1000000000000.0,
      "returningRoute": null,
      "returningBestCost": 1000000000000.0,
      "status": "Start"
    }
  },
  "dependencies": {
    "htcaid:node;300": { "id": "htcaid:node;300", "classType": "hybrid.actor.Node" },
    "htcaid:node;310": { "id": "htcaid:node;310", "classType": "hybrid.actor.Node" },
    "htcaid:node;350": { "id": "htcaid:node;350", "classType": "hybrid.actor.Node" }
  }
}
```

| Field | Description |
|---|---|
| `startTick` | First dispatch tick |
| `interval` | Headway between successive dispatches (seconds/ticks) |
| `busStops` | Map from BusStop ID → Node ID for all stops on the route |
| `buses` | Pre-defined bus definitions (one entry per bus; multiple entries for multiple initial buses) |
| `buses[].label` | Route label — **must match** `BusStop.label` and `Bus.label` |
| `goingRoute` / `returningRoute` | Computed at runtime; set to `null` initially |

**Dependencies:** Every Node referenced in `busStops` values must appear in `dependencies`.

---

### 4.7 Bus

A bus vehicle. Usually created dynamically by BusStation, but can be pre-defined in a JSON file.

```json
{
  "id": "htcaid:bus;route_42_bus_0",
  "typeActor": "hybrid.actor.Bus",
  "data": {
    "dataType": "model.hybrid.entity.state.BusState",
    "content": {
      "startTick": 25200,
      "label": "42",
      "capacity": 80,
      "origin": "htcaid:node;300",
      "destination": "htcaid:node;350",
      "routeId": "42",
      "stopSequence": [
        { "stopId": "htcaid:busstop;stop_001", "node": "htcaid:node;300", "arrivalOffset": 0,   "departureOffset": 0 },
        { "stopId": "htcaid:busstop;stop_002", "node": "htcaid:node;310", "arrivalOffset": 120, "departureOffset": 120 },
        { "stopId": "htcaid:busstop;stop_003", "node": "htcaid:node;350", "arrivalOffset": 240, "departureOffset": 240 }
      ],
      "bestRoute": null,
      "currentNode": null,
      "distance": 0.0,
      "status": "Start"
    }
  },
  "dependencies": {}
}
```

| Field | Description |
|---|---|
| `label` | Route label — shared with BusStop and BusStation |
| `capacity` | Maximum passenger count |
| `stopSequence` | Ordered list of stops with arrival/departure offsets in seconds |
| `stopSequence[].arrivalOffset` | Seconds after `startTick` to arrive at this stop |

---

### 4.8 SubwayStation

Manages one or more subway lines passing through a station. Spawns Subway (train) actors.

```json
{
  "id": "htcaid:subwaystation;station_A",
  "typeActor": "hybrid.actor.SubwayStation",
  "data": {
    "dataType": "model.hybrid.entity.state.SubwayStationState",
    "content": {
      "startTick": 0,
      "name": "Central",
      "nodeId": "htcaid:node;100",
      "terminal": true,
      "garage": true,
      "lines": {
        "line_1": { "interval": 300, "nextTick": 0 }
      },
      "subways": {
        "line_1": [
          {
            "line": "line_1",
            "actorId": "htcaid:subway;line_1_fwd_train_0",
            "capacity": 1200,
            "numberOfPorts": 8,
            "velocity": 22.22,
            "stopTime": 30
          }
        ]
      },
      "linesRoute": {
        "line_1": [
          {
            "stationNode": {
              "stationId": "htcaid:subwaystation;station_B",
              "nodeId": "htcaid:node;101"
            },
            "railLinkId": "htcaid:rail_link;line_1_segment_0"
          }
        ]
      },
      "people": {},
      "status": "Start"
    }
  },
  "dependencies": {
    "node": { "id": "htcaid:node;100", "classType": "hybrid.actor.Node" }
  }
}
```

| Field | Description |
|---|---|
| `terminal` | `true` if this is the origin terminus of the line |
| `garage` | `true` if trains are stored here (dispatched from here) |
| `lines` | Map of line ID → `{interval, nextTick}` |
| `subways` | Map of line ID → list of train definitions to dispatch |
| `subways[].velocity` | Cruising speed in m/s (e.g., `22.22` ≈ 80 km/h) |
| `subways[].stopTime` | Dwell time at each station in seconds |
| `linesRoute` | Ordered list of `{stationNode, railLinkId}` pairs forming the line's path |

---

### 4.9 Subway (Train)

A subway train. Created dynamically by SubwayStation; can also be pre-defined.

The train state is primarily managed by the SubwayStation that spawns it. Pre-defined entries in a JSON file are rarely needed — the SubwayStation's `subways` field is sufficient.

---

### 4.10 Car

A private car **asset** owned by a Person. Sits **Parked** until the owning Person sends a `StartTrip` message.

```json
{
  "id": "htcaid:car;person_42_v_car",
  "typeActor": "hybrid.actor.Car",
  "data": {
    "dataType": "model.hybrid.entity.state.CarState",
    "content": {
      "startTick": 28800,
      "origin": "htcaid:node;500",
      "destination": "htcaid:node;500",
      "actorType": "Car",
      "size": 4.5,
      "currentSimulationMode": "MESO",
      "microState": null,
      "status": "Parked",
      "bestRoute": null,
      "currentNode": "htcaid:node;500",
      "distance": 0.0,
      "eventCount": 0,
      "driverAttributes": {
        "aggressiveness": 0.5,
        "reactionTimeFactor": 1.0,
        "speedFactor": 1.0,
        "minGapFactor": 1.0
      },
      "scheduleOnTimeManager": false
    }
  },
  "dependencies": {
    "from_node": { "id": "htcaid:node;500", "classType": "hybrid.actor.Node" },
    "to_node":   { "id": "htcaid:node;500", "classType": "hybrid.actor.Node" }
  }
}
```

| Field | Description |
|---|---|
| `status` | Always `"Parked"` at creation |
| `origin` / `destination` | Parking location node (both set to the same node initially) |
| `driverAttributes.aggressiveness` | `[0, 1]` — influences gap acceptance and lane changes |
| `driverAttributes.reactionTimeFactor` | Multiplier on the base reaction time (default base = 1 s) |
| `driverAttributes.speedFactor` | Multiplier on the desired speed |
| `driverAttributes.minGapFactor` | Multiplier on the minimum gap |
| `scheduleOnTimeManager` | `false` — the car wakes up only when Person activates it |

---

### 4.11 Person

An agent that walks a **flat list of plan elements** (`originalPlan`/`cursor`) — activities,
already-resolved travel legs, and pending mode-choice decisions — one element at a time. See
[PERSON_AGENT.md](PERSON_AGENT.md) for the full model; this section covers only the JSON schema.

> **This schema replaced the old `dailySchedule: List[Activity]` + `currentActivityIndex` +
> `ArrivalLogistics` model without backward compatibility.** If you have older scenario files using
> `dailySchedule`/`arrivalLogistics`/`currentActivityIndex`, they must be converted to this shape —
> there is no runtime fallback for the old fields.

```json
{
  "id": "htcaid:person;42",
  "typeActor": "hybrid.actor.Person",
  "data": {
    "dataType": "model.hybrid.entity.state.PersonState",
    "content": {
      "ptWaitTimeoutTicks": 86400,
      "ownedVehicles": {
        "car": { "id": "htcaid:car;person_42_v_car", "classType": "hybrid.actor.Car" }
      },
      "totalDistanceTraveled": 0.0,
      "completedTrips": 0,
      "originalPlan": [
        {
          "kind": "Activity",
          "activityType": "home",
          "nodeId": "htcaid:node;500",
          "endTime": { "kind": "AtTick", "tick": 28800 }
        },
        {
          "kind": "PrivateVehicleLeg",
          "mode": "Car",
          "vehicle": { "id": "htcaid:car;person_42_v_car", "classType": "hybrid.actor.Car" },
          "driverAttributes": {
            "aggressiveness": 0.5,
            "maxSpeedFactor": 1.0,
            "reactionTime": 1.0,
            "minGapFactor": 1.0
          }
        },
        {
          "kind": "Activity",
          "activityType": "work",
          "nodeId": "htcaid:node;600",
          "endTime": { "kind": "AtTick", "tick": 64800 }
        },
        {
          "kind": "PrivateVehicleLeg",
          "mode": "Car",
          "vehicle": { "id": "htcaid:car;person_42_v_car", "classType": "hybrid.actor.Car" },
          "driverAttributes": {
            "aggressiveness": 0.6,
            "maxSpeedFactor": 0.95,
            "reactionTime": 1.1,
            "minGapFactor": 1.05
          }
        },
        {
          "kind": "Activity",
          "activityType": "home",
          "nodeId": "htcaid:node;500",
          "endTime": { "kind": "AtTick", "tick": 86400 }
        }
      ]
    }
  },
  "dependencies": {}
}
```

**Top-level `PersonState` fields:**

| Field | Type | Description |
|---|---|---|
| `originalPlan` | `List[PlanElement]` | The plan exactly as authored, in order — see below for the five element shapes. Immutable at runtime; kept only for provenance/debugging. |
| `ownedVehicles` | `Map[String, Identify]` | Mode string (`"car"`/`"bicycle"`/`"motorcycle"`) → the vehicle's `Identify`. Required for any `PrivateVehicleLeg` or any `PendingDecision` that may resolve to a private-vehicle mode. |
| `ptWaitTimeoutTicks` | `Long` | Max ticks to wait at a PT stop before giving up and triggering a replan. Default `86400` (one full day). |
| `modeChoiceWeights` | `ModeChoiceWeights` | Default weights passed to whichever `ModeDecisionEngine` resolves a `PendingDecision` — see [PERSON_AGENT.md §6.2](PERSON_AGENT.md#62-decisioncontext-e-pesos-modechoiceweights). Not needed at all if the plan has no `PendingDecision`. |
| `totalDistanceTraveled` / `completedTrips` | `Double` / `Int` | Usually `0.0` / `0` at scenario authoring time — accumulated at runtime. |

Do **not** set `cursor` in scenario JSON — there is nothing to resume on a fresh load. It is seeded
automatically from `originalPlan` on first initialization.

**Plan element shapes** (discriminated by a `"kind"` property):

| `kind` | Fields | Meaning |
|---|---|---|
| `"Activity"` | `activityType`, `nodeId`, `endTime` (an `EndTimeSpec`) | A stay at a location |
| `"WalkLeg"` | `originNodeId`, `destinationNodeId`, `precomputedRoute` (optional) | A resolved walking leg |
| `"PrivateVehicleLeg"` | `mode` (`"Car"`\|`"Bicycle"`\|`"Motorcycle"`), `vehicle` (`Identify`, required — never optional), `driverAttributes` | A resolved private-vehicle leg |
| `"TransitLeg"` | `mode` (`"Bus"`\|`"Subway"`), `line`, `boardingStop` (`StopRef`), `alightingStop` (`StopRef`) | A resolved PT leg |
| `"PendingDecision"` | `decision`: `{ allowedModes, strategyId, weightsOverride }` | A mode choice to be resolved at runtime by the named `ModeDecisionEngine` — see below |

`EndTimeSpec` is also discriminated by `"kind"`:

| `kind` | Fields | Meaning |
|---|---|---|
| `"AtTick"` | `tick` | Ends at this absolute simulation tick (departs one tick after arrival if the person arrives late) |
| `"Duration"` | `ticks` | Ends this many ticks after the person actually arrived (a late arrival shifts departure forward by the same amount) |

`StopRef` (used by `TransitLeg.boardingStop`/`alightingStop`):

```json
{ "actorId": "htcaid:busstop;busstop_42", "actorClassType": "hybrid.actor.BusStop", "nodeId": "htcaid:node;600" }
```

**Writing a leg you already know at authoring time:** write it directly as `WalkLeg`/
`PrivateVehicleLeg`/`TransitLeg` — no runtime resolution happens for it, exactly as in the example
above. **Writing a leg you want resolved dynamically at simulation time:** write a
`PendingDecision` instead — see [§13](#13-dynamic-mode-choice).

**`ownedVehicles`:** required whenever a `PrivateVehicleLeg` appears in the plan, or whenever a
`PendingDecision.decision.allowedModes` includes a private-vehicle mode and you want that vehicle
considered — only vehicles actually parked at the trip's origin (tracked via
`PersonState.vehicleCurrentNode`, mode → node id, updated automatically after every private-vehicle
leg) are offered as candidates.

---

## 5. city_map.json and transit_map.json

`city_map.json` is the **in-memory routing graph** loaded at simulator startup. Every router query (`GPSUtil.calcRoute`) uses this graph. It must contain all nodes and directed edges (links) present in the scenario.

Minimal structure (exact schema depends on the routing implementation):

```json
{
  "nodes": {
    "htcaid:node;10": { "lat": 7393000.0, "lon": 326000.0 },
    "htcaid:node;11": { "lat": 7393250.0, "lon": 326000.0 }
  },
  "edges": [
    {
      "id": "htcaid:link;1001",
      "from": "htcaid:node;10",
      "to": "htcaid:node;11",
      "weight": 250.0,
      "length": 250.0
    }
  ]
}
```

> The `weight` field is used by the shortest-path algorithm; it can be the physical `length` or a generalised cost.

### city_map.json — SQLite alternative

`CityMapUtil` picks the loader automatically from the configured path's extension: a path ending
in `.db` goes through `Graph.loadFromSqliteFile`, anything else through `Graph.loadFromJsonFile`.
No other configuration changes — `htc.mobility.city-map-file` / `HTC_MOBILITY_CITY_MAP_FILE` just
point at the `.db` file instead (`simulation.json`'s `cityMapFile` field is not read by the loader
either way — see [§3](#3-simulationjson--manifest)).

Unlike the `actor_simulation` format below, this is a pure load-time optimisation, not a
progressive-loading feature — `CityMapUtil` still loads the whole graph into a single permanent
in-memory singleton either way. It matters once the graph itself is large (a whole-city network can
be hundreds of thousands of nodes/edges): `NodeGraph`/`EdgeGraph` are flat, fully-typed case
classes, so they normalise into plain relational tables with no JSON parsing/blob overhead on load.

```sql
CREATE TABLE city_map_meta (directed INTEGER NOT NULL);
CREATE TABLE city_map_node (
  id TEXT PRIMARY KEY, resource_id TEXT, class_type TEXT,
  latitude REAL NOT NULL, longitude REAL NOT NULL
);
CREATE TABLE city_map_edge (
  id TEXT PRIMARY KEY, resource_id TEXT, class_type TEXT, length REAL,
  source_id TEXT NOT NULL REFERENCES city_map_node(id),
  target_id TEXT NOT NULL REFERENCES city_map_node(id),
  weight REAL
);
CREATE INDEX idx_city_map_edge_source ON city_map_edge(source_id);
CREATE INDEX idx_city_map_edge_target ON city_map_edge(target_id);
```

Convert an existing `city_map.json` with `tools/scenario-db-converter/convert.py`:

```bash
python convert.py city-map json-to-db city_map.json city_map.db
```

### transit_map.json

`transit_map.json` is an **optional** flat JSON array of transit access points (bus stops and subway stations) used exclusively by the [dynamic mode choice](#13-dynamic-mode-choice) system. It is **not** required for static-schedule simulations.

The file is configured via:
- Environment variable: `HTC_MOBILITY_TRANSIT_MAP_FILE`
- Config key: `htc.mobility.transit-map-file`

If neither is set, `TransitMapUtil.isAvailable` returns `false` and the system falls back to static logistics silently.

**Schema (flat array — no wrapper object):**

```json
[
  {
    "id": "htcaid:stop;bus_stop_123",
    "actorId": "htcaid:busstop;stop_001",
    "actorClassType": "hybrid.actor.BusStop",
    "nodeId": "htcaid:node;300",
    "latitude": -23.5505,
    "longitude": -46.6333,
    "stopType": "bus",
    "lines": ["42", "68"]
  },
  {
    "id": "htcaid:stop;metro_central",
    "actorId": "htcaid:subwaystation;station_A",
    "actorClassType": "hybrid.actor.SubwayStation",
    "nodeId": "htcaid:node;100",
    "latitude": -23.5461,
    "longitude": -46.6388,
    "stopType": "subway",
    "lines": ["blue_line"]
  }
]
```

**Field reference:**

| Field | Description |
|---|---|
| `id` | Unique stop identifier (used internally by `TransitMapUtil`) |
| `actorId` | Entity ID of the BusStop or SubwayStation actor — used for `RegisterPassenger` messages |
| `actorClassType` | Shard class type for actor routing (`hybrid.actor.BusStop` / `hybrid.actor.SubwayStation`) |
| `nodeId` | Road-network node ID where the stop is located |
| `latitude` / `longitude` | WGS-84 coordinates — used for haversine distance calculations |
| `stopType` | `"bus"` or `"subway"` |
| `lines` | List of line labels served — must match `BusStop.label` / `SubwayStation.lines` keys |

> **Note:** Distances between stops and origin/destination points are computed using the **haversine formula** (great-circle distance) rather than network Dijkstra, which makes the transit index an order of magnitude cheaper to query than full routing.

---

## 6. ID Naming Conventions

**Current contract: every entity id is a plain, opaque, monotonically increasing JSON `Long`
number — a bare integer, not a string, and never prefixed.** This applies to the top-level
envelope `"id"` on every actor (`ActorSimulation.id: Long`), every relationship/dependency
reference (`ShardActorId.entityId: Long`, the protobuf `Identify.id: Long`), and every field
that references another entity by id — `NodeState.links: List[Long]`, `LinkState.from`/`to:
Long`, `PersonState.originalPlan`'s `Activity.nodeId`/`WalkLeg.originNodeId`/
`destinationNodeId: Long`, `PersonState.ownedVehicles`/`vehicleCurrentNode: Map[String, Long]`
(values), `city_map.json`'s `NodeGraph`/`EdgeGraph.id: Long`, and so on. The runtime String
entity id used internally for actor paths/sharding (`BaseActor.getEntityId`) is just
`id.toString` (see `core.util.IdUtil.format(id: Long): String`) — e.g. `"6483859"` — never a
prefixed string.

```json
{ "id": 42, "typeActor": "hybrid.actor.Node", "data": { ... }, "dependencies": {} }
```

Ids are assigned by whatever generates the scenario (see `tools/sao-paulo/generate_hybrid_input.py`'s
`ScenarioIdRegistry`: `id_for(kind, source_id)` deterministically assigns the next free `Long`
the first time a given `(kind, source_id)` key is seen, and returns the same id on every later
lookup of that key, so a rerun with the same seed/inputs reproduces the same ids) — there is no
required numbering scheme (OSM id, sequential, hashed) beyond "globally unique across the whole
scenario, across every actor type."

**Two narrow exceptions stay opaque `String`, never `Long`** — both are matched only by exact
string equality, never parsed numerically:
- `transit_map.json`'s per-stop `"id"` field (`TransitStop.id: String`) — matched against
  `transit_routes.json`'s `stops[].stopId: String` ([§13](#13-dynamic-mode-choice)). Both are
  free-form labels; `actorId`/`nodeId` on the same `TransitStop` *are* `Long` (see [§5](#5-city_mapjson-and-transit_mapjson)).
- `dependencies`/relationship map **keys** (e.g. `"from_node"`, `"to_node"`, or an arbitrary
  label) — the map itself is `Map[String, ShardActorId]`; only the `id` *value* inside each
  entry is `Long`.

> **Historical note:** earlier scenario data (and every JSON example elsewhere in this
> document, which predates this section and has not all been converted) used a
> `"htcaid:<type>;<identifier>"` string convention instead. That convention is retired — treat
> any `"htcaid:..."` string you see in an example elsewhere in this doc as illustrative of the
> *shape* only, not the literal format to write; the `id` position holds a bare number. There is
> no automated conversion tool for existing old-format data yet — a scenario still using
> `"htcaid:..."` ids needs its ids reassigned by hand (or regenerated via
> `tools/sao-paulo/generate_hybrid_input.py`) until one is written.

---

## 7. Dependency Graph

The figure below shows which entities must exist before another can be fully initialised:

```
Node ←── Link (from_node, to_node)
Node ←── RailLink (from_node, to_node, from_station, to_station)
Node ←── TrafficSignal (node)
Node ←── BusStop (node)      ──── [post-load] ──→ Node registers BusStop
Node ←── BusStation (nodes)  ──── [post-load] ──→ Node registers BusStation
Node ←── SubwayStation (node) ─── [post-load] ──→ Node registers SubwayStation
Car  ←── Person (ownedVehicles)
```

**Loading order that satisfies all dependencies:**

1. `Node` (EAGER)
2. `Link`, `RailLink`, `TrafficSignal` (EAGER)
3. `BusStop`, `BusStation`, `SubwayStation` (EAGER, post-load registration)
4. `Bus` (pre-defined departures, PROGRESSIVE)
5. `Car`, `Bicycle`, `Motorcycle` (PROGRESSIVE, `Parked` until Person activates)
6. `Person` (PROGRESSIVE)

---

## 8. Loading Strategies and Lifecycle

| Strategy | Description | Typical use |
|---|---|---|
| `EAGER` | All actors loaded at simulation startup | Infrastructure (nodes, links, signals) |
| `PROGRESSIVE` | Actors loaded in batches as needed | Agents (persons, vehicles) |

| Lifecycle | Description | Typical use |
|---|---|---|
| `STATIC` | Actor exists for the full simulation | Infrastructure |
| `DYNAMIC` | Actor can be created or destroyed mid-simulation | Vehicles, persons |

### PROGRESSIVE loading: JSON vs SQLite

`PROGRESSIVE` sources are read in tick-windowed batches as the simulation advances, rather than all
at once at startup. How each window is fetched depends on `dataSource.sourceType`
([§3](#3-simulationjson--manifest)):

- **`json`** (`ProgressiveJsonLoadData`) — the file has no index into it by `startTick`, so each
  window re-scans the file, discarding records outside the requested `[fromTick, toTick]` range
  (see `TickIndexUtil`). Cost per window grows with total file size, not window size.
- **`sqlite`** (`ProgressiveSqliteLoadData`) — `startTick` is promoted to its own indexed column in
  the `actor_simulation` table (see [§11](#11-scaling-data-files) for the schema), so a window is
  fetched with `WHERE start_tick BETWEEN ? AND ?` directly against the index. Cost per window
  depends on the window's own size, not the file's.

This is the reason the SQLite format exists at all: at the scale this doc's scenarios run at
(tens of thousands of agents per file, millions across a scenario), repeated full-file rescans per
tick window are the dominant cost of `PROGRESSIVE` loading. `EAGER` sources don't see this
difference — they load the entire source once, so there's no window to index into.

---

## 9. Simulation Modes: MESO vs MICRO

Each Link independently selects its simulation mode via the `simulationMode` field.

| Mode | Behaviour | When to use |
|---|---|---|
| `"MESO"` | Aggregate speed-density model; vehicles move through the link in bulk | City-scale networks, outer areas |
| `"MICRO"` | Car-following (Krauss model) + lane changes; individual vehicle dynamics | Corridors of interest, downtown areas, BRT lanes |

**Enabling MICRO on a link:**

```json
{
  "simulationMode": "MICRO",
  "microTimeStep": 0.1,
  "microTicksPerGlobalTick": 10,
  "laneConfigurations": [
    { "laneId": 0, "type": "normal",   "width": 3.5, "speedLimit": null },
    { "laneId": 1, "type": "bus_lane", "width": 3.5, "speedLimit": 60.0 }
  ]
}
```

When a link is in MICRO mode, set `hasHybridConnections: true` on any adjacent Node.

**Lane types:**

| Type | Description |
|---|---|
| `"normal"` | Mixed traffic |
| `"bus_lane"` | Restricted to buses |
| `"bike_lane"` | Restricted to bicycles |

---

## 10. Minimal Working Example

The following is the smallest possible scenario — two nodes, one link, one car, one person — that exercises the full hybrid pipeline.

### Directory layout

```
my_scenario/
├── simulation.json
└── data/
    ├── city_map.json
    ├── nodes.json
    ├── links.json
    ├── cars.json
    └── persons.json
```

### data/nodes.json

```json
[
  {
    "id": "htcaid:node;1",
    "typeActor": "hybrid.actor.Node",
    "data": {
      "dataType": "model.hybrid.entity.state.NodeState",
      "content": {
        "startTick": 0, "latitude": 7393000.0, "longitude": 326000.0,
        "links": [], "connections": {}, "signals": {},
        "busStops": {}, "subwayStations": {},
        "signalWaitingCounts": {},
        "scheduleOnTimeManager": false
      }
    },
    "dependencies": {}
  },
  {
    "id": "htcaid:node;2",
    "typeActor": "hybrid.actor.Node",
    "data": {
      "dataType": "model.hybrid.entity.state.NodeState",
      "content": {
        "startTick": 0, "latitude": 7393500.0, "longitude": 326000.0,
        "links": [], "connections": {}, "signals": {},
        "busStops": {}, "subwayStations": {},
        "signalWaitingCounts": {},
        "scheduleOnTimeManager": false
      }
    },
    "dependencies": {}
  }
]
```

### data/links.json

```json
[
  {
    "id": "htcaid:link;1",
    "typeActor": "hybrid.actor.Link",
    "data": {
      "dataType": "model.hybrid.entity.state.LinkState",
      "content": {
        "startTick": 0,
        "from": "htcaid:node;1", "to": "htcaid:node;2",
        "length": 500.0, "lanes": 2,
        "speedLimit": 50.0, "freeSpeed": 50.0, "capacity": 1800.0,
        "simulationMode": "MESO",
        "microTimeStep": 0.1, "microTicksPerGlobalTick": 10,
        "laneConfigurations": [
          { "laneId": 0, "type": "normal", "width": 3.5, "speedLimit": null },
          { "laneId": 1, "type": "normal", "width": 3.5, "speedLimit": null }
        ],
        "congestionFactor": 1.0,
        "currentSpeed": 50.0, "registered": [], "vehiclesByLane": {}
      }
    },
    "dependencies": {
      "from_node": { "id": "htcaid:node;1", "classType": "hybrid.actor.Node" },
      "to_node":   { "id": "htcaid:node;2", "classType": "hybrid.actor.Node" }
    }
  }
]
```

### data/cars.json

```json
[
  {
    "id": "htcaid:car;p1_v_car",
    "typeActor": "hybrid.actor.Car",
    "data": {
      "dataType": "model.hybrid.entity.state.CarState",
      "content": {
        "startTick": 28800,
        "origin": "htcaid:node;1",
        "destination": "htcaid:node;1",
        "actorType": "Car",
        "size": 4.5,
        "currentSimulationMode": "MESO",
        "microState": null,
        "precomputedRoute": null,
        "distance": 0.0
      }
    },
    "dependencies": {
      "from_node": { "id": "htcaid:node;1", "classType": "hybrid.actor.Node" },
      "to_node":   { "id": "htcaid:node;1", "classType": "hybrid.actor.Node" }
    }
  }
]
```

### data/persons.json

```json
[
  {
    "id": "htcaid:person;1",
    "typeActor": "hybrid.actor.Person",
    "data": {
      "dataType": "model.hybrid.entity.state.PersonState",
      "content": {
        "startTick": 0,
        "scheduleOnTimeManager": true,
        "ptWaitTimeoutTicks": 86400,
        "ownedVehicles": {
          "car": { "id": "htcaid:car;p1_v_car", "classType": "hybrid.actor.Car" }
        },
        "vehicleCurrentNode": {
          "car": "htcaid:node;1"
        },
        "totalDistanceTraveled": 0.0,
        "completedTrips": 0,
        "originalPlan": [
          {
            "kind": "Activity",
            "activityType": "home",
            "nodeId": "htcaid:node;1",
            "endTime": { "kind": "AtTick", "tick": 28800 }
          },
          {
            "kind": "PrivateVehicleLeg",
            "mode": "Car",
            "vehicle": { "id": "htcaid:car;p1_v_car", "classType": "hybrid.actor.Car" },
            "driverAttributes": {
              "aggressiveness": 0.5, "maxSpeedFactor": 1.0,
              "reactionTime": 1.0, "minGapFactor": 1.0
            }
          },
          {
            "kind": "Activity",
            "activityType": "work",
            "nodeId": "htcaid:node;2",
            "endTime": { "kind": "AtTick", "tick": 86400 }
          }
        ]
      }
    },
    "dependencies": {}
  }
]
```

### simulation.json

```json
{
  "id": "my_scenario",
  "name": "Minimal Example",
  "description": "Two-node, one-link, one-car, one-person scenario.",
  "startTick": 0,
  "endTick": 86400,
  "startRealTime": "2025-01-01T00:00:00.000",
  "timeUnit": "seconds",
  "timeStep": 1.0,
  "duration": 86400,
  "tickDuration": 1.0,
  "randomSeed": 42,
  "cityMapFile": "/app/.../data/city_map.json",
  "postLoadRegistrationClasses": [],
  "actorsDataSources": [
    {
      "id": "nodes", "classType": "hybrid.actor.Node",
      "creationType": "LoadBalancedDistributed",
      "loadingStrategy": "EAGER", "entityLifecycle": "STATIC",
      "dataSource": { "sourceType": "json", "info": { "path": "/app/.../data/nodes.json" } }
    },
    {
      "id": "links", "classType": "hybrid.actor.Link",
      "creationType": "LoadBalancedDistributed",
      "loadingStrategy": "EAGER", "entityLifecycle": "STATIC",
      "dataSource": { "sourceType": "json", "info": { "path": "/app/.../data/links.json" } }
    },
    {
      "id": "cars", "classType": "hybrid.actor.Car",
      "creationType": "LoadBalancedDistributed",
      "loadingStrategy": "PROGRESSIVE", "entityLifecycle": "DYNAMIC",
      "dataSource": { "sourceType": "json", "info": { "path": "/app/.../data/cars.json" } }
    },
    {
      "id": "persons", "classType": "hybrid.actor.Person",
      "creationType": "LoadBalancedDistributed",
      "loadingStrategy": "PROGRESSIVE", "entityLifecycle": "DYNAMIC",
      "dataSource": { "sourceType": "json", "info": { "path": "/app/.../data/persons.json" } }
    }
  ]
}
```

---

## 11. Scaling Data Files

For large scenarios, split entity arrays across numbered files to control memory usage and parallelise loading:

```
nodes_0.json   ← first 50,000 nodes
nodes_1.json   ← next  50,000 nodes
...
```

Register each file as a separate entry in `actorsDataSources` with a unique `id`:

```json
{ "id": "nodes_0", "classType": "hybrid.actor.Node", ... },
{ "id": "nodes_1", "classType": "hybrid.actor.Node", ... }
```

The recommended maximum items per file is **50,000** (see `itemsPerFile` in the generation configuration).

### SQLite as the scaling path

Once a scenario reaches this scale — 50k agents per file, multiple files, a city-scale
`city_map.json` with hundreds of thousands of nodes/edges — the recommended path is to convert the
JSON data sources to SQLite (`sourceType: "sqlite"`, [§3](#3-simulationjson--manifest)) rather than
keep splitting into more numbered JSON files. The `actor_simulation` table's indexed `start_tick`
column also removes the full-file rescan `PROGRESSIVE` loading otherwise pays per tick window
([§8](#8-loading-strategies-and-lifecycle)).

Convert with `tools/scenario-db-converter/convert.py` (stdlib `sqlite3` + `ijson`; both directions
stream record-by-record, so memory stays bounded regardless of input size — see the script's
module docstring):

```bash
python convert.py actor-simulation json-to-db persons_0.json persons_0.db
python convert.py actor-simulation db-to-json persons_0.db persons_0.json   # round trip
python convert.py city-map         json-to-db city_map.json city_map.db
```

Only per-entity `ActorSimulation` data sources and `city_map.json` have a SQLite path.
`simulation.json` itself and `transit_map.json`/`transit_routes.json` remain JSON-only. Each cluster
node still needs its own local copy of any `.db` file, same as JSON today — SQLite's locking model
isn't safe for concurrent multi-node reads over a shared network filesystem.

---

## 12. Generating Scenarios from Real Data

The São Paulo scenario referenced in this repository was generated from:

| Source | Data |
|---|---|
| OpenStreetMap (OSM) | Road network (nodes, links) and rail infrastructure |
| GTFS feed | Bus routes, stops, schedules |
| EQAsim (MATSim) | Synthetic population activity chains |

The generation script (`generate_hybrid_input.py`) handles:

1. **OSM → Nodes + Links:** Converts the road graph, assigns `simulationMode` (`MESO` by default; `MICRO` for selected highway types), and splits into sharded files.
2. **GTFS → BusStops + BusStations + Buses:** Maps transit stops to nearest OSM nodes, builds route schedules.
3. **OSM rail/subway → RailLinks + SubwayStations:** Extracts rail topology, creates station-to-station rail segments.
4. **EQAsim population → Persons + Cars:** Samples the synthetic population at a given rate, maps activity locations to the nearest network node, and assigns private vehicle assets.
5. **OSM traffic signals → TrafficSignals:** Extracts signal-controlled intersections and assigns phase plans.

### Coordinate system

All coordinates in the scenario files are in **UTM metres** (WGS84 UTM zone 23S for São Paulo). If you are modelling a different city, convert all coordinates to the appropriate UTM zone before generating the scenario. The routing graph (`city_map.json`) and the actor coordinates must use the same CRS.

### Sample rate

The `sampleRate` parameter in the generation configuration controls what fraction of the full population is emitted. For São Paulo:

- Full population: ~19.8 million persons
- 0.1% sample: ~19,600 persons, ~3,000 cars

Increase the sample rate for higher fidelity; decrease it for faster prototype runs.

---

*For the actor API reference, see [API.md](API.md).*  
*For road infrastructure details, see [ROAD_INFRASTRUCTURE.md](ROAD_INFRASTRUCTURE.md).*  
*For bus system details, see [BUS_AGENT.md](BUS_AGENT.md), [BUS_STATION_AGENT.md](BUS_STATION_AGENT.md), [BUS_STOP_AGENT.md](BUS_STOP_AGENT.md).*  
*For subway details, see [SUBWAY_AGENT.md](SUBWAY_AGENT.md), [SUBWAY_STATION_AGENT.md](SUBWAY_STATION_AGENT.md).*  
*For person modelling, see [PERSON_AGENT.md](PERSON_AGENT.md).*

---

## 13. Dynamic Mode Choice

Dynamic mode choice lets a Person **resolve a trip's mode at simulation runtime** instead of
having it fixed in the authored plan. It works by placing a `PendingDecision` plan element (instead
of a concrete `WalkLeg`/`PrivateVehicleLeg`/`TransitLeg`) wherever you want the choice made
dynamically. See [PERSON_AGENT.md §6](PERSON_AGENT.md#6-escolha-de-modo--modelhybriddecision) for
the full model; this section covers only scenario-authoring mechanics.

> This replaces the old global `enableDynamicModeChoice` boolean + per-leg `fixedMode` flag. There
> is no scenario-wide switch anymore: a plan mixes fixed legs (write them directly as
> `WalkLeg`/`PrivateVehicleLeg`/`TransitLeg`) and dynamic legs (write a `PendingDecision`) freely,
> element by element.

### `PendingDecision` schema

```json
{
  "kind": "PendingDecision",
  "decision": {
    "allowedModes": ["Bus", "Subway", "Walk"],
    "strategyId": "travel-time",
    "weightsOverride": null
  }
}
```

| Field | Description |
|---|---|
| `allowedModes` | Modes (`"Walk"`\|`"Car"`\|`"Bicycle"`\|`"Motorcycle"`\|`"Bus"`\|`"Subway"`) the engine is permitted to resolve this decision to. A mode the underlying engine never evaluates (see the table below) is silently never a candidate — no special error, just `NoViableJourney` if nothing else works either. |
| `strategyId` | Which `ModeDecisionEngine` resolves this decision — see table below. Must match a registered engine id exactly; there is no fallback for a typo. |
| `weightsOverride` | `null` to use `PersonState.modeChoiceWeights`; otherwise a full `ModeChoiceWeights` object overriding it for this decision only. |

### Choosing a `strategyId`

| `strategyId` | Evaluates | When to use |
|---|---|---|
| `"raptor"` | Bus/subway multi-leg only (RAPTOR router). Never walk-only, never a private vehicle. | Multi-leg transit trips with transfers; requires `transit_route.json` (`HTC_MOBILITY_TRANSIT_ROUTES_FILE`) to be configured — see [PERSON_AGENT.md §6.4](PERSON_AGENT.md#64-fail-fast-na-carga-do-cenário) for how that requirement is enforced (scenario-load fail-fast, not a runtime surprise). |
| `"nearest-stop-utility"` | Walk + single-leg bus/subway (haversine-distance heuristic). Never a private vehicle. | Simple single-hop PT-vs-walk decisions where multi-leg transfers aren't needed. |
| `"travel-time"` | Walk, bus, subway, car, bicycle, motorcycle — **the only engine of the three that considers private vehicles.** | Any decision where car/bicycle/motorcycle should be a real candidate — required if you want a person to be able to choose to drive at a `PendingDecision`. |

> **If you want car to be a candidate at a dynamic decision point, `strategyId` must be
> `"travel-time"`.** Using `"raptor"` or `"nearest-stop-utility"` with `Car`/`Bicycle`/`Motorcycle`
> in `allowedModes` will never produce a private-vehicle leg — the underlying implementation those
> two engines wrap has no notion of a vehicle candidate at all.

### Fail-fast validation

`ScenarioLoadValidator.validateModeDecisionEngines` aborts the *entire* scenario load if any
`strategyId` referenced by a `PendingDecision` doesn't resolve to a registered engine, or if an
engine's data prerequisites aren't met (e.g. `"raptor"` without a transit routes file). It is wired
into the real load pipeline via `core.actor.manager.load.ScenarioPreflightValidator`, run before
any actor is created for both `EAGER` and `PROGRESSIVE` sources — see
[PERSON_AGENT.md §6.4](PERSON_AGENT.md#64-fail-fast-na-carga-do-cenário) for the full explanation.
A bad `strategyId` or missing transit data fails the scenario load up front, not at runtime.

### JSON example — Person with a mix of fixed and dynamic legs

```json
{
  "id": "htcaid:person;42",
  "typeActor": "hybrid.actor.Person",
  "data": {
    "dataType": "model.hybrid.entity.state.PersonState",
    "content": {
      "startTick": 0,
      "scheduleOnTimeManager": true,
      "modeChoiceWeights": {
        "includedModes": ["car", "bus", "subway", "walk"],
        "betaMode": 1.0,
        "betaAccess": 0.0036,
        "betaEgress": 0.0036,
        "modePrefSubway": 2.0,
        "modePrefBus": 1.0,
        "modePrefWalk": 0.0,
        "maxAccessDistanceM": 1500.0,
        "maxWalkDistanceM": 2000.0
      },
      "ownedVehicles": {
        "car": { "id": "htcaid:car;p42_v_car", "classType": "hybrid.actor.Car" }
      },
      "totalDistanceTraveled": 0.0,
      "completedTrips": 0,
      "originalPlan": [
        {
          "kind": "Activity",
          "activityType": "home",
          "nodeId": "htcaid:node;500",
          "endTime": { "kind": "AtTick", "tick": 28800 }
        },
        {
          "kind": "PendingDecision",
          "decision": {
            "allowedModes": ["Bus", "Subway", "Walk"],
            "strategyId": "nearest-stop-utility",
            "weightsOverride": null
          }
        },
        {
          "kind": "Activity",
          "activityType": "work",
          "nodeId": "htcaid:node;600",
          "endTime": { "kind": "AtTick", "tick": 64800 }
        },
        {
          "kind": "PrivateVehicleLeg",
          "mode": "Car",
          "vehicle": { "id": "htcaid:car;p42_v_car", "classType": "hybrid.actor.Car" }
        },
        {
          "kind": "Activity",
          "activityType": "home",
          "nodeId": "htcaid:node;500",
          "endTime": { "kind": "AtTick", "tick": 86400 }
        }
      ]
    }
  },
  "dependencies": {}
}
```

In the example above:
- The **outbound trip** (home → work) is a `PendingDecision` resolved by `"nearest-stop-utility"`
  at tick 28800 — if a bus/subway stop is within `maxAccessDistanceM` of node 500 with a closer
  alighting stop near node 600, the person boards PT; otherwise it falls back to walking (this
  engine never considers the car).
- The **return trip** (work → home) is a fixed `PrivateVehicleLeg` — always the car, never
  re-evaluated, because it was authored directly rather than behind a `PendingDecision`.

### Generating `transit_map.json` from GTFS

When generating a scenario from GTFS data, extract stop positions and line memberships and write them as a flat array. Each stop that serves multiple lines should appear **once** with all its lines in the `lines` array. The `actorId` and `actorClassType` must match exactly the corresponding BusStop/SubwayStation actor IDs in the scenario.

```python
# Pseudocode — GTFS → transit_map.json
stops = []
for stop in gtfs.stops:
    lines = [trip.route_id for trip in gtfs.trips_at(stop.stop_id)]
    stops.append({
        "id": f"htcaid:stop;{stop.stop_id}",
        "actorId": f"htcaid:busstop;{stop.stop_id}",
        "actorClassType": "hybrid.actor.BusStop",
        "nodeId": nearest_node(stop.lat, stop.lon),
        "latitude": stop.lat,
        "longitude": stop.lon,
        "stopType": "bus",
        "lines": list(set(lines))
    })
json.dump(stops, open("transit_map.json", "w"))  # flat array, no wrapper
```

### Runtime behaviour

When the `PlanCursor` reaches a `PendingDecision` (see
[PERSON_AGENT.md §7](PERSON_AGENT.md#7-ciclo-de-vida-do-agente)):

1. `PersonPlanManager.resolvePending` looks up `ModeDecisionEngineRegistry.get(decision.strategyId)`.
2. The engine's `decide(originNodeId, destinationNodeId, request, ctx)` is called — for
   `"nearest-stop-utility"`/`"travel-time"` this internally calls `TransitMapUtil.nearestStops` to
   find candidate stops within `maxAccessDistanceM`, scores every candidate (bus, subway, walk,
   and — for `"travel-time"` only — car/bicycle/motorcycle parked at the origin), and returns the
   best one; `"raptor"` runs a full RAPTOR search instead.
3. On success, the resolved `AtomicLeg`s are spliced into the plan exactly where the
   `PendingDecision` was (`PlanCursor.expandPending`), and the person proceeds to execute them.
4. On failure (`NoViableJourney`), the trip is aborted and the person resumes at the next
   `Activity` — see [PERSON_AGENT.md §6.5](PERSON_AGENT.md#65-o-que-acontece-quando-uma-decisão-não-tem-opção-viável).

> **Performance note:** `TransitMapUtil` performs a linear scan over stops filtered by type. For large stop sets (> 10,000), consider implementing a spatial index (k-d tree). For typical city scenarios with 2,000–5,000 stops this is negligible compared to actor message processing.

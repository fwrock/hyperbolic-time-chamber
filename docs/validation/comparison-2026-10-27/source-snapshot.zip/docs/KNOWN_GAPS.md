# Known Gaps

Honest gap assessment against the README/docs claims, based on a source-level audit. This module
has the platform's best documentation, but "best-documented" isn't the same as "fully accurate" —
update this file as gaps close.

Start with [MICRO implementation and validation status](MICRO_VALIDATION_STATUS.md)
for the consolidated current scope, evidence, scientific interpretation and next
acceptance gates. The dated sections below retain milestone history.

## Field input audit and fresh v2 — sample gate still open (2026-10-26)

The released v1 audit identifies the independently documented 35 mph site cap
(v1 used 50 km/h), mixed road/control contexts and sparse observed queue releases.
The cap correction alone does not resolve v1 error: former reserved following
RMSE rises from 2.223 to 2.363 m, while queue headway MAE stays 0.625 s. No
behavioral coefficient is tuned. The original 50 km/h predictions remain exact
after exposing the cap as an optional validation-adapter input.

A new frozen protocol uses fresh, session/vehicle-disjoint first-recording
episodes, same-section following and stopped prefixes aligned to observed head
release. Eight following episodes and four queues qualify after 135 exclusions.
All comparative and physical checks pass on that subset: following position
RMSE is 1.980 m versus rigid spacing 9.228 m, and queue headway MAE is 0.463 s
versus 0.999 s. The unchanged ten/five episode targets are not met, so the overall
gate remains inconclusive. The 50/56.32704/65 km/h trajectories coincide on this
restricted cohort; this is not evidence of each driver's desired speed.

The supporting attachment retrieved for signals is not a valid ZIP; no actual
phase state or clock alignment is inferred from it. Observed queue release is
not labeled as measured green. All 780 Scala tests in 154 suites and 49 Python
tests pass, with exact v2 replay from the repository snapshot. Broader empirical
adequacy, actual signal validation and independent network replication remain
open. See [audit and fresh v2 results](MICRO_FIELD_INPUT_AUDIT.md) and the
[machine record](validation/micro-field-v2-2026-10-26.json). Further sampling needs
a new preregistered cohort, not reduced targets or retrospective favorable pooling.

## Conditional urban field assessment — adequacy still open (2026-10-26)

A frozen new study uses official Lankershim NGSIM observations with disjoint
initialization/prediction intervals and reserved later time blocks. The Scala
adapter calls actual production Link physics with observed head-leader motion;
it changes no traffic parameters. Ten qualifying reserved following episodes
yield mean position RMSE 2.223 m versus 12.384 m for constant velocity. The mean
improvement against rigid spacing is 1.079 m, but its exploratory paired interval
includes zero, so that frozen comparative gate does not pass.

Only two of the required five queue episodes qualify after 62 trajectory
exclusions. Both discharge completely, with mean headway MAE 0.625 s, but the
declared data gate remains inconclusive. There are no predicted bumper overlaps.
The full engineering suite passes 779 Scala tests in 154 suites and 44 Python
tests; development/reserved predictions reproduce exactly offline. Raw responses,
exclusions, query/source/executable hashes, license and outcomes survive in the
repository [snapshot](validation/ngsim-following-discharge-snapshot-2026-10-26.zip)
and [machine record](validation/micro-field-2026-10-26.json).

This supplies conditional interacting-traffic evidence beyond the isolated
cruising pilot. It does not establish empirical adequacy or autonomous network
prediction. Observed leader motion omits controls and driver desired-speed
heterogeneity; some episodes traverse intersections. Do not attribute failures
to following coefficients alone or tune on the reserved outcomes. The next
scientific work is a development audit of these contexts and cohort availability,
then a new protocol and fresh field observations. See [methods and results](MICRO_FIELD_VALIDATION.md).

## Bounded single-lane MICRO spillback (2026-10-26)

Opt-in `LinkState.downstreamSpillback` retains a stopped lane footprint after
proactive MICRO exit until the Car's cleanup releases it. Followers and boundary
snapshots continue to see its rear bumper while Node capacity is full. The Link
keeps resolving its own ticks; admission retains the existing correlated Node
grant. Pending exit identity, cancellation cleanup identity and capacity-wait
timing are checkpointed. A geometric spacing cap handles abrupt count-gate stops;
unsupported vehicle entry or an entry without physical room fails explicitly.

The frozen new protocol passes reserved short-road, connector and blocked-horizon
fixtures under both policies. All ten report comparisons pass, including 9,291
connector rows across one/two JVMs and 4,468 delayed distributed Time Warp
rollbacks. Nine accepted executions contain 68 completed and 16 correctly censored
journeys, including repeated policies/layouts. The final suite passes 775 Scala
tests in 153 suites and 34 Python tests; assembly passes. Representative unchanged
SUMO, coarse-clock Car and cyclic transit regressions also pass. See
[the contract and acceptance](MICRO_SPILLBACK.md) and
[retained machine record](validation/micro-spillback-2026-10-26.json).

This is bounded engineering acceptance for static single-lane Cars, not general
network spillback or empirical traffic validity. Competing movements, multi-lane
behavior, arbitrary short-road chains and physical origin-injection queues remain
open. The hard safety clamp is not calibrated emergency braking. Car capacity
waiting time is now reported, but idle emissions during this post-exit dwell are
not integrated. Additional ticking/reporting/checkpoint costs remain unmeasured
at city scale. Earlier dated sections retain the pre-extension gap and evidence.

## Custom conservative load balancing (2026-10-26)

The production conservative runtime now supports the custom migration protocol:
closed causal batches, authoritative live cohorts after terminal retirement,
checkpointed accepted input, owner-authorized source stop and physical ActorRef
rebind preserving logical ownership/schedule handles. First-window loading and
new migration requests during resume settle before the next cut. A request after
the terminal cut is explicitly declined instead of failing a completed run.

All routing JVMs acknowledge typed shard assignments before eager/progressive or
station-created actor initialization. Complete cluster-wide live-count metrics
are applied on the manager thread. Planning is deterministic, includes idle nodes,
pins infrastructure, uses projected loads and preserves observed assignments until
placement is accepted. Fixed initial geographic cells and stable capacity overflow
replace the previously disconnected initial partitioning. Invalid strategy
configuration cannot silently select default parameters.

The retained two-JVM campaign compares complete physical output with a fixed
placement reference and exercises real migration while Cars occupy MESO roads,
queued waves, progressive cohort enrollment, station-created MICRO Bus/Subway
service, and explicit worker-loss abort. See
[Step 10](LOAD_BALANCING.md#step-10--production-conservative-ownership-live-metrics-and-traffic-acceptance-2026-10-26)
and [the acceptance record](DISTRIBUTED_LOAD_BALANCING_VALIDATION_2026_10_26.md).
Earlier dated migration sections below retain the original failures and narrower
milestone evidence; they do not override this current scope.

Custom balancing remains disabled by default. The active snapshot/directory/
allocation authorities are memory-only and require a fixed cluster cohort.
Independent restart/failover, membership growth, optimistic migration and live
geographic repartition remain unsupported. Weights measure live entity counts,
not CPU cost; useful city-scale performance, memory bounds and empirical
load-prediction quality remain unestablished.

## Cross-link MICRO following and v2 validation (2026-10-25)

Opt-in single-lane MICRO following now observes actual leaders across a Link
boundary and through an optional connector onto the next road. It requires one
physics step per runtime tick. Explicit stop-line gaps match the SUMO reference;
defaults preserve the existing mixed-model mode. On the inspected v1 seed 101,
trip-time MAE drops from 1.325 to 0.081 s and the final queued car changes from
3.2 s early to 0.1 s late, without a fitted node delay or car-following coefficient.

All four predeclared v2 physical cases and all five fresh 18-car demand seeds
pass the unchanged provisional criteria. The five-seed mean HTC-minus-SUMO
duration is +0.064 s, with exploratory 95% interval [+0.046, +0.083] s. A small
positive bias remains. These are different demand realizations from v1 below.

The final build passes **653 Scala tests in 135 suites** and **18 Python tests**.
All **19 SUMO comparisons** produce valid measurements for **260 completed cars**;
all **17 full-report comparisons** match, including two-JVM execution with 3,297
rollbacks, unchanged conservative physics across the stale-publication repair,
and legacy Car and cyclic transit behavior. An initial v2 Time Warp failure from
a publication outliving its rolled-back subscription was repaired and retained
as excluded evidence; all final validation uses the repaired executable.

**Empirical following/discharge validity remains open.** Competing junction
movements, multi-lane selection, capacity-blocked handoff/spillback and vehicles
waiting outside lane queues need separate representation and validation. Very
short successive roads can require an observation horizon beyond the next road.
Messaging/checkpoint costs at city scale are unmeasured. See the
[contract, ablations and reproduction](MICRO_CROSS_LINK_FOLLOWING.md) and
[retained v2 evidence](validation/micro-discharge-2026-10-25.json).

## Fractional MICRO timing and scientific workflow — prior v1 milestone (2026-10-25)

Opt-in 0.1-second runtime ticks and checkpointed step-remainder transfer correct
the accumulated boundary loss in the supported MICRO Car scope. Integer event
ordering, owner ledgers, cancellation and report commit rules are retained. On a
1.2 km development route, trip-time bias drops from 8.9 s at one-second ticks to
below 0.001 s at 0.1 s; remainder transfer also removes the remaining observed
position drift in that controlled case. The default one-second mixed-model mode
remains available. Fractional clocks currently reject Person, transit, two-wheelers,
MESO, dynamic routing feedback and plugins until their time-unit adapters exist.

The full suite passes **644 Scala tests in 134 suites** and **17 Python tests**.
All 21 real-SUMO runs produce valid measurements (169 completed cars). All four
frozen held-out scenarios meet the provisional numerical-equivalence criteria.
Eleven full-report comparisons match, including fractional-clock execution on
one/two JVMs, conservative/optimistic policies, legacy cyclic Bus service and a
censored field-initialized trajectory. The two-JVM optimistic geometry case
exercises 135 rollbacks and cross-owner transport. CSV physical timestamps and
MICRO relative-speed units are corrected; floating summaries use stable reduction
order rather than relaxing report comparison.

**General microscopic traffic accuracy is still unestablished.** All five frozen
randomized-demand realizations fail the trip-time/trajectory equivalence targets.
Their paired scenario-level mean HTC-minus-SUMO duration is −1.185 s, with an
exploratory 95% Student-t interval [−1.292, −1.078] s. In seed 101, error accumulates
through queued vehicles to 3.2 s early for the final vehicle. Following/discharge
dynamics need a focused audit and a new frozen validation set after any revision.
Matching halted-queue counts and completed-cohort throughput does not close that
gap or establish saturated capacity.

Three NGSIM field forecasts now use disjoint initialization/prediction intervals,
documented feet-to-metres conversion and continuity/lane/leader checks. Position
RMSE is 2.35–7.57 m over ten seconds. This conditional isolated-cruising pilot has
no field-derived acceptance threshold; it does not validate following or networks.
The original bounded responses, metadata, hashes and CC BY-SA attribution are
retained in a replayable snapshot. See
[methods, results and reproduction](MICRO_SCIENTIFIC_VALIDATION.md) and
[retained evidence](validation/micro-scientific-2026-10-25.json).

## Finite MICRO junction geometry (2026-10-24)

Opt-in junction movements now traverse fixed Link connectors with measured length,
metric paths and turn-speed limits. Approach physics brakes for the selected turn.
Node capacity grants retain the original road request identity while checkpointing
connector selection; replay, cancellation and cyclic Bus cursors preserve that
selection. Road lengths stop at the junction boundary, so internal distance is
counted exactly once. Existing point-node scenarios retain their defaults.

The full suite passes **635 Scala tests in 133 suites**, six focused cold-codec
follow-up tests and **11 Python harness tests**. Twelve real-SUMO runs with internal
lanes (52 completed cars) and two mixed MICRO transit runs on two JVMs pass physical
acceptance. All seven full-report policy comparisons match, including 39 Bus
connector crossings and a run with 129 rollbacks. Protected straight/left/right
movement trip-time errors are at most 1.7/1.2/1.2 s; queued right turns reach 1.9 s.
See [the geometry contract, measurements and costs](JUNCTION_GEOMETRY.md) and
[retained evidence](validation/junction-geometry-2026-10-24.json).

The accepted junction fixtures protect the selected movement and hold other
approaches red. Conflict priority/gap acceptance, shared conflict-area blocking,
multi-lane junction choice, turn-aware routing costs and a general city-network
geometry importer remain open. Whole-tick cross-link quantization also remains;
geometry does not remove it. Each movement adds a fixed Link LP with lane/shape
state and rollback history; these bounded tests establish no city-scale cost.

## Real SUMO comparison and MICRO node boundaries (2026-10-24)

The old sibling comparison harness has measurement, identity and current-schema
problems. A tracked replacement now compares fresh real-SUMO runs using matched
physical inputs, route-distance trajectories and actual terminal trip times. It
fails on invalid/missing output and includes explicit node/clock checks rather
than accepting a small RMSE computed over a partial trace.

MICRO now preserves physical crossing speed, stops adding a tick at a point node,
uses synchronous leader states and the leader's rear bumper, and applies entries
and signal phases to their correct physics intervals. A previously authorized
green crossing is retained when its rounded report reaches Node after red begins;
downstream capacity and reply identity remain accounted and checkpointed. Real
stops clear carried speed, and red stop-line vehicles cannot retire from the lane.
Link travel-time reports no longer count both endpoint ticks as extra elapsed time.

The accepted suite passes **626 Scala tests in 132 suites** and seven Python
measurement regressions. All ten real-SUMO cases pass bounded acceptance; ordinary
crossing trip-time error falls from 5.7 to 1.7 s, queued signal error from 8.7 to
1.8 s, and the isolated phase-boundary error from 31.7 to 1.7 s. Two mixed MICRO
transit/walking regressions also pass. All six complete policy report comparisons
match. See [the real-SUMO validation and scope](SUMO_MICRO_VALIDATION_2026_10_24.md)
and [retained evidence](validation/sumo-micro-2026-10-24.json).
Whole-tick boundary quantization remains a runtime limitation. This earlier
point-node campaign did not validate finite geometry; the opt-in connector stage
above covers that follow-up. Earlier SUMO artifacts are not current accuracy proof.

## Walking distance follow-up (2026-10-24)

Person now checkpoints the actual walking route's measured distance and arrival
tick, credits it only on arrival, and includes walking in leg metrics and daily
totals. Transitions between access walks, rides, transfers and egress walks preserve
the accumulated distance; the previous fresh-leg initialization reset that prefix.
Aborts retain completed legs without counting a completed trip. An unfinished walk
at the horizon remains uncounted, while an arrival exactly at the cap executes.

The full suite passes **614 tests across 131 suites**, including nonzero walking
checkpoint/replay, multimodal prefix preservation and failed-route/replan cases.
All ten bounded simulator cases pass physical acceptance; all seven full-report
comparisons match, including delayed two-JVM MESO and single-JVM MICRO Bus runs.
See [the walking contract](WALKING_DISTANCE.md) and
[machine-readable evidence](validation/walking-distance-2026-10-24.json) for scope
and reproduction.
This supersedes the walking exclusion in the historical milestone below.

## Horizon finalization and transit distance follow-up (2026-10-24)

Production policies now authorize reporting at the globally closed final horizon
cut, so an active vehicle whose next wake lies beyond the cap still emits a
censored journey/SUMO record. The shared hook covers Car, Bicycle, Motorcycle, Bus
and Subway, cannot send or schedule model work, and preserves normal execution at
the inclusive horizon. Optimistic reports flush strictly below GVT; conservative
completion also waits for final report receipts before storage draining. Censored
records cannot claim a destination arrival or unfinished-link distance.

Person transit distance now comes from checkpointed typed boarding identity and
vehicle odometer differences. Bus/Subway messages carry their existing cumulative
physical distance without adding another request/reply exchange. Subway counts a
rail arrival before station dwell, publishes arrival telemetry and checkpoints
the guard preventing cleanup from adding that link twice. Cyclic trains now have
explicit final journey/SUMO telemetry. Walking distance remains outside daily totals.

The full suite passes **605 tests across 130 suites**. All 14 bounded simulator
cases pass physical acceptance, including both policies with delayed two-JVM
MICRO transit. All eight physical-report comparisons match their references.
Measured rides are 400 m by Bus and 1400 m by Subway; exact-cap rail arrival and
interrupted Car/Bicycle/Motorcycle cases have explicit acceptance. See
[the reporting contract](HORIZON_AND_TRANSIT_REPORTING.md) and
[validation record](HORIZON_TRANSIT_VALIDATION_2026_10_24.md) for independent distance,
exact-horizon and interrupted-journey acceptance. Earlier milestone entries retain
their historical scope and reporting limitations.

## Accounted dynamic routing follow-up (2026-10-24)

Hybrid dynamic road feedback now has an explicit accounted adapter:
`htc.routing.cache-strategy=accounted` uses fixed EAGER/STATIC `RoutingService` LPs.
Link costs, mode decisions and direct vehicle queries cross the existing owner
ledgers as ordered model messages. Worker cost versions and requester obligations
are checkpointed; rollback retracts affected replies. Dynamic route calculations
cannot reuse a shared cached path. Unaccounted Kafka/in-memory feedback remains
rejected by production policies.

The implementation also corrects MICRO feedback that treated empty links as stopped
traffic and compared m/s lane speeds against km/h configured speeds. Published
costs now normalize units and restore free-flow cost on empty MICRO links.
Startup rejects absent, extra, duplicate, progressive, ephemeral or non-sharded
routing workers. Independent cold-codec and anti-message regressions cover the
new protocol. The full suite passes **596 tests across 128 suites**.
Eight MESO/MICRO scenarios under both policies on one/two JVMs pass independent
physical acceptance; all six full-report comparisons match their references,
including delayed TCP. Each case completes 6/6 journeys and 3/3 Person trips
with the expected 1300 m total and 12/12 matched link traversals.

See [the protocol and costs](ACCOUNTED_ROUTING.md) and
[validation/reproduction record](ACCOUNTED_ROUTING_VALIDATION_2026_10_24.md).
This closes the missing adapter for sampled hybrid road feedback; replicated
cost-map/checkpoint overhead, million-actor capacity, external live streams,
recovery/migration and uniform horizon reporting remain open. The historical
entries below retain their original milestone scope.

## Cross-JVM policy follow-up (2026-10-24)

The separate-JVM campaign exposed gaps hidden by one-process tests: Kryo implicit
numeric IDs could not be decoded by a cold peer, Class constructor arguments fell
through to disabled Java serialization, and LTM Props captured creator closures.
Production codecs now retain ordered explicit IDs and use class names for unlisted
types; remote LTM construction uses class/argument Props. Independent-codec tests
reproduce all three failures on the previous implementation.

Transit also exposed process-local settings installed only by SimulationManager's
singleton. Remote Persons had no RAPTOR routes and silently skipped their Bus leg.
Each node now installs scenario resource settings before shard creation. Startup
warm-up now dispatches on worker readiness rather than a one-time pool broadcast;
the late-input case reproduced a remote worker missing that broadcast and leaving
startup waiting indefinitely. Unique ACKs, node identity, worker loss/restart and
target failure are checked explicitly.

The full suite passes **582 tests across 124 suites**. Ten successful two-JVM
scenario runs (including delayed TCP) match physical expectations and references;
two worker-loss checks explicitly fail without successful completion. Fifteen
full report comparisons match. See the
[cross-JVM validation record](MULTI_JVM_POLICY_VALIDATION_2026_10_24.md) for physical
outcomes, reference comparisons, delayed transport, worker-loss evidence and exact
artifact identity. These are bounded loopback JVM checks; multi-host partitions,
coordinated recovery, migration, live distributed API settings, shared speculative
feedback and scale validation remain open. Earlier one-JVM records retain their
original scope.

## Accounted model-created birth follow-up (2026-10-24)

Both production policies now support one deterministic unique logical birth slot
per child ID. The owning LTM accounts initialization and buffers overtaking input;
the existing GTM authorizes membership without routing model payloads. Children
join inert and activate through an ordered positive. Optimistic cancellation uses
normal antis, restores dormancy and retracts descendant effects; physical retirement
waits for safe GVT and a monotone latest-accepted-input fence. Children inherit only
the policy selected before the run. No new global time coordinator was added.

Bus/Subway stations use this adapter instead of speculative initialization polling
or GVT-deferred creation at an older timestamp. Real transit validation exposed and
fixed additional model defects: null unload routing, subway speed units, conservative
subway leave correlation, missing subway stop-barrier obligations, Bus reporting
state outside checkpoints and Bus MICRO repeatedly entering an unconsumed path.
The Bus cyclic next-link peek now follows its actual route cursor for capacity and
signal checks. These defects affected independent outcomes, so mere engine completion
or policy parity was insufficient acceptance.

The actor-birth milestone build passed **571 tests across 121 suites**. Eight transit cases
(MESO, MICRO, late input and multiple births under both policies) and four car
regressions pass, with six matching full physical-report comparisons. Cyclic
services explicitly truncate at the horizon. A MESO bus whose next wake is beyond
the cap can lack final journey/SUMO output; uniform horizon finalization remains
a reporting gap and the validator records it separately.

See [the lifecycle contract](RUNTIME_ACTOR_BIRTH.md) and
[the validation record](RUNTIME_ACTOR_BIRTH_VALIDATION_2026_10_24.md). Earlier entries
below retain their milestone scope. ID recycling, shared speculative feedback,
coordinated recovery/migration, multi-JVM validation and million-actor capacity
remain open. PT person distance and Subway journey-completion telemetry also remain
incomplete; validation uses actual boardings/alightings and cyclic rail traversal.

## Progressive optimistic input follow-up (2026-10-24)

Production Time Warp now alternates acknowledged deterministic source windows with
execution. Accepted input caps the execution ceiling; its next unloaded tick stays
in GVT accounting until explicit closure. New LPs enroll only after committed
retirement with every owner paused, and the next fresh round includes them.
That source change excluded independent model birth; the follow-up above now
provides its separate reversible adapter. The existing GTM coordinates enrollment;
there is no new coordinator actor or policy mixing.

Source failures can no longer masquerade as successful empty windows. JSON and
SQLite async results update state through the mailbox and verify indexed counts.
The simulator matrix also exposed empty JSON arrays being decoded as records and
whole-file buffering in the shared parser. Record-by-record stream binding fixes
both, with buffer-refill and malformed/empty-input regressions.

The progressive milestone suite passed **532 tests across 112 suites**. All **12** MESO/MICRO
source-format/preloading cases complete 4/4 trips and 2/2 summaries with zero errors,
null-state discards or stalls. Ten full physical-report multiset comparisons match
the preloaded conservative references. Optimistic progressive cases start with
only the first person/car pair and accept the later pair after reaching the source
boundary. Conservative's larger bootstrap window preloads these particular cohorts;
its cases here serve as format/policy references, not late-enrollment evidence.

See [the protocol](PROGRESSIVE_OPTIMISTIC_RUNTIME.md) and
[latest validation](PROGRESSIVE_OPTIMISTIC_VALIDATION_2026_10_24.md). Background
prefetch, arbitrary live streams, shared feedback, recovery/migration,
multi-JVM validation and million-actor capacity remain open. Older preloading-only
claims and measurements below retain their historical scope.

## Bounded optimistic execution follow-up (2026-10-23)

Production optimistic runs now use a startup tick window, per-LP speculative-event
budget and cooperative per-turn input budget, with fossil collection after safe
GVT commitment. Queued work remains in the cut when throttled. Business reply
obligations stay in completion/retirement checks; their historical send timestamps
no longer pin distributed GVT below the future work needed to answer them. Orphaned
dispatches and waits without future work fail explicitly.

Strict-boundary collection retains a usable pre-GVT state floor and coast-forward
journals, and removes older processed/cancelled identities. Populated Link lane-map
snapshots now declare Integer key types: narrow-window rollback reproduced String
keys where lane arithmetic expected Int, which empty-map snapshots missed.
The larger bounded cohort also exposed next-round traffic arriving before the
receiver's local resume. Paused owners now queue that traffic while LPs stay frozen;
collection/commit/retirement remain closed. A held-resume regression covers the race.

The bounded milestone build passes 508 tests. Eight mobility cases, including one-tick MESO
and MICRO, and six repeated 32-person cohort runs pass strict output acceptance.
The same-executable cohort comparison lowers median peak retained logs from 1384
to 567 records and read journals from 128 to 64, with effectively unchanged timing
and no consistent rollback reduction. These are record counts, not heap-byte bounds.

See [the resource protocol](BOUNDED_OPTIMISTIC_EXECUTION.md) and
[current validation](BOUNDED_OPTIMISTIC_VALIDATION_2026_10_23.md). That milestone
did not provide a fixed heap budget, progressive optimistic input, model birth/recovery,
or evidence for one million actors; the progressive source gap is addressed above.
Earlier unbounded-history statements below describe the preceding reference implementations.

## Current production policy update (2026-10-23, distributed follow-up)

Production optimistic execution now uses LTM-owned transport and report ledgers;
the existing GTM aggregates frozen round summaries and no longer creates a central
message-routing coordinator child. Conservative execution retains its separate
channel-closed batch protocol. Neither run mixes or switches policies.

`LinkMetricsState` now checkpoints cumulative and per-tick SUMO counters. The
validated two-link MICRO reports match between policies, including the 67 summary
rows that previously differed. A larger cohort exposed a second model restore
bug: Node's `Map[Long, Int]` values became boxed Longs under the shared Jackson
configuration. Explicit Integer content annotations now preserve replay arithmetic;
the regression fails with the original cast error before the fix.

The distributed milestone suite passes 496 tests. See
[the distributed protocol](DISTRIBUTED_OPTIMISTIC_RUNTIME.md) and
[current validation](DISTRIBUTED_OPTIMISTIC_VALIDATION_2026_10_23.md) for the final
artifact, scenario matrices and performance limitations. Historical baseline
sections below preserve their original findings; their central-routing and open
counter-gap status statements are superseded by this update.

## Time Warp correctness and extensibility (reviewed 2026-10-22)

See [Extensible Time Warp Runtime](TIME_WARP_EXTENSIBLE_RUNTIME.md) for the current prioritized
core/model audit and [validation record](TIME_WARP_VALIDATION_2026_10_22.md) for tested evidence.
The historical margin-based estimator did not account for messages in transit. The
2026-10-23 accounted runtime replaces heuristic commitment, plateau termination,
and direct speculative destruction for fixed/preloaded optimistic runs. Shared
speculative feedback and live birth require model adapters and are rejected. This
patch fixes targeted-report buffering, cancellation retention, duplicate dispatch/input handling,
empty relationship restoration, Link control-state snapshots, replay observations, the fossil
floor boundary, and GVT subtraction overflow. These local fixes do not establish mode parity.

## Shared event ordering and schedule revisions (foundation added 2026-10-23)

`EventOrder` separates causal simulation time and stable logical identity from fresh
transport send counters. Interactions and spontaneous dispatches share the actor's
ordered queue; same-tick optimistic stragglers now restore the correct prefix.
The pending self-event is part of the checkpoint, and a received interaction cannot
overtake an already-known earlier self-event. This local queue does not establish
that conservative channels contain no earlier independent input.

Rollback uses atomic `ReplaceScheduleEvent` updates with monotone revisions.
Obsolete dispatches acknowledge their exact generation without model execution;
older schedule updates cannot erase a newer replacement. The requested tick is
preserved on the versioned path. LVT now includes queued ticks and the actual
in-flight tick after rollback, rather than using an older high-water mark for that
dispatch. Production optimistic execution now obtains its frontier from the
accounted cut described below; local LVT alone remains insufficient.

The accounted path now scopes transport identity by model/run/incarnation, accounts
model/control delivery, preserves speculative retirement, and drains committed
reports. Coordinated actor restart recovery remains unsupported and fails the run. The legacy
unstamped schedule adapter retains its old watermark semantics. See
[validation and remaining limits](TIME_WARP_VALIDATION_2026_10_23.md).

## Accounted optimistic commitment and retirement (2026-10-23)

`core/runtime/accounting/AccountedRuntimeCoordinator` freezes all registered LPs
and LTMs, drains delivery acceptance, and collects fresh round snapshots. Pending
positives, antis, self-events, in-flight dispatches, and reply obligations constrain
the frontier. Commitment uses time strictly below GVT. A terminal LP remains
rollbackable until retirement is authorized; raw destruction is rejected. A sink
receipt ACK and final asynchronous flush ACK are required before optimistic success.
LP retirement is now round-scoped: the LP checks that the coordinator authorized
the same committed round, the terminal and latest processed events are strictly below GVT, and no work
remains. Settled/truncated final cuts carry a separate coordinator marker. Any
accounted input delivered to an LP with null state fails before acknowledgement.
Default actor restart, lost participants, and work below published GVT fail the run.
The accounted path also disables pre-rollback “superseded reply” dropping: request
identity in a speculative suffix is not proof that an earlier input is dispensable.
A second reproduced core wait cycle is fixed by indexing queued dispatches separately:
a dispatch invalidated during a frozen rollback must release its LTM slot before
waiting for the restored earlier wake, including when another input precedes it.

Membership is fixed after eager and fully exhausted progressive loading. The model
validation hook rejects shared dynamic routing feedback and transit stations that
need live birth. Their old “wait for GVT then spawn at an earlier tick” pattern is
not a valid birth protocol, even with a safe GVT. External/live producers, reversible
birth, timestamped shared feedback, migration/recovery, bounded histories, and
multi-node validation remain open. This central reference coordinator is a separate
child of `OptimisticGlobalTimeManager`. It adds pauses and per-message ledger/ACK
overhead and remains a potential bottleneck; it has no scale or speedup claim.

The production conservative factory now selects `ChannelClosedGlobalTimeManager`
and `ChannelAwareLocalTimeManager`: interactions and acceptance ledgers stay with
LTMs, and the GTM agrees on the next causal batch only after channels drain.
Report receipt and final sink flush precede successful completion. The legacy
barrier class is retained for compatibility tests and does not provide those
guarantees when constructed directly. This change does not distribute the
optimistic coordinator. Both accounted paths reject live model birth and shared
dynamic routing until adapters exist. See
[the conservative protocol and limits](CONSERVATIVE_CHANNEL_RUNTIME.md).

The [channel validation](CONSERVATIVE_CHANNEL_VALIDATION_2026_10_23.md) passes all
487 tests and the bounded MESO/MICRO outcome checks. MESO physical payloads and
MICRO non-summary reports match between policies. MICRO cumulative SUMO `loaded`
and `ended` counters still differ: `LinkMetricsReporter` stores them outside Link's
checkpoint hooks, so replay can count the same entry/exit again. Full MICRO report
parity remains open until these counters restore with model state. This is separate
from channel closure and from the optimistic coordinator's scalability limitation.

See [protocol and supported scope](TIME_WARP_ACCOUNTED_RUNTIME.md) and
[validation](TIME_WARP_ACCOUNTED_VALIDATION_2026_10_23.md). Older entries below are
historical investigations; their margin/plateau safety claims are superseded.

## MESO Car departure and per-trip reporting (corrected 2026-10-23)

The final MESO departure used to complete the trip before `ReceiveLeaveLinkInfo`
added the last link's distance; intermediate departures could schedule the next
link before the earlier reply cleared link timing metadata. `Movable.leavingLink`
now waits for the MESO reply on every link. Its checkpointed exit-reported marker
preserves proactive MICRO completion without adding a cleanup wait. Car signal
handling initiates departure and leaves completion/terminal intent to the traversal
completion path. Car SUMO route lengths and journey-distance metrics subtract the
checkpointed trip-start odometer instead of counting previous trips again.

The full build passes 483 tests in 100 suites. Four seeded Car MESO cases and two
MICRO regressions pass distance, traversal, runtime, and applicable timing checks.
MESO person and SUMO trip lengths are 200/400 m, and completion ticks match across
policies in these one/two-link free-flow cases. Same-tick per-car density estimates
still differ in some entries, so full report parity and conservative channel
ordering remain open. Other vehicles, transit, congestion, and junction control
need their own validation. See [evidence and limits](MESO_POLICY_VALIDATION_2026_10_23.md).

## Conservative barrier does not close interaction channels (confirmed 2026-10-23)

`ConservativeGlobalTimeManager` releases the next global tick after every LTM has
reported, while ordinary `sendMessageTo` interactions travel directly through the
sharding region. The sender's `FinishEvent` and the interaction use different
recipients, so the GTM/LTM reports do not prove the interaction has reached the
receiver. Registered awaited replies only account for selected consistency-critical
requests; fire-and-forget sends are not represented in `hasPendingWork`. A late
delivery can therefore introduce work at or before a frontier already released by
the conservative barrier.

This makes the barrier's channel-closure proof incomplete. Separately, repeated
conservative runs of the fixed-seed two-link scenario with the same jar show a
model-level tie-order issue: both vehicles enter the second MICRO link at tick 35,
but the first vehicle to exit reverses between runs. Equal-position vehicles are
inserted in message arrival order in `LinkVehicleFlowHandler`, and the car-following
strategy uses lane queue order to choose each leader. This arrival-order
sensitivity is consistent with the conservative/optimistic first-link lead swap.
Do not attribute
that observed state difference to the conservative barrier without further evidence.

Equal-position MICRO lane order now uses descending position and ascending vehicle
ID at insertion and after simulation steps. Focused specs and repeated fixed-seed
runs pass strict trip, summary, and null-state-discard checks. Conservative
two-link runs still differ in the tick of the first link-11 arrival (33 versus 35),
so full event-tick determinism is not established. See the validation record for
the per-run outcomes.

The barrier still needs a conservative-run gateway that records each send before
forwarding, acknowledges receiver acceptance, and holds the frontier until all
relevant channel deliveries are settled. Fixed rounds, grace polls, and delays
cannot prove this condition. Add an injected delayed-channel protocol regression
to validate that independent gap. Details and protocol invariants are in
[`TIME_WARP_ACCOUNTED_RUNTIME.md`](TIME_WARP_ACCOUNTED_RUNTIME.md#conservative-same-tick-closure-investigation-legacy-path).

## Conservative premature termination during vehicle activation (fixed 2026-10-22)

The fixed-seed two-person MICRO scenario could stop at tick 10 after two `person_trip_started`
reports and no completed trips. Rebuilding the pre-review revision `200ba25` in an isolated
worktree reproduced the same failure, so it predates the review's uncommitted changes.

`Person` sent `StartTrip`, then finished its spontaneous event with no next tick. Its awaited
trip reply was recorded only in Time Warp mode, and conservative LTM reports represented only
scheduled ticks. Before `Car` had registered its first tick, all LTMs could report no schedule;
the global manager's extra idle-query round could finish before the activation arrived.

Both policies now retain registered reply obligations. Conservative LTM reports include an
additive `LocalTimeReportEvent.hasPendingWork` field; the GTM can advance scheduled actors while
another actor awaits a reply, but cannot declare idle termination while an obligation remains.
Accepted replies consume the registry entry in either mode. MICRO entry acknowledgements also
consume the corresponding EnterLink request. Final-link cleanup that completes without using
its reply does not register an unnecessary wait. After a proactive MICRO exit, the vehicle
also skips a redundant cleanup wait, using a checkpointed flag reset on its next link entry.

The original scenario now reports four completed 200 m trips, two completed daily schedules,
four MICRO entries and exits, no errors/stalls, and an engine stop after the final activity.
A two-link variant also completes four 400 m trips, eight matching MICRO entries/exits, and
two daily schedules of 800 m, then stops at tick 800 without errors or stalls.
See [the validation follow-up](TIME_WARP_VALIDATION_2026_10_22.md#conservative-termination-follow-up)
for the baseline comparison, tests, and artifacts. This fixes the tracked request/reply path;
it is not a replacement for the future complete transport/quiescence protocol.

## Optimistic replay initialization and rollback boundaries (fixed 2026-10-22)

The reproduced Person error, `Replay did not consume all recorded reads`, came from an initial
checkpoint taken before `onFinishInitialize` seeded its plan cursor. The live actor departed
normally, but restoring that floor gave replay an empty plan. Core initialization now runs that
hook before capturing the floor. `PersonReplayInitializationSpec` reproduces both the empty-cursor
restore and the original exception before the fix, then checks the restored plan, observed
decision, request identity, and cancellation/replacement of a completed trip.

Two further core defects appeared while rerunning the optimistic MICRO scenarios:

- Anti-messages rolled back by tick, undoing events processed before the cancelled message at
  that same tick. Cancellation now uses the exact processed-event sequence. Buffered reports
  carry that sequence so a surviving same-tick report is retained as well as its original send.
  Positive interactions undo strictly later ticks, preserving their existing same-tick causal
  prefix; otherwise a delayed reply could retract the very request it needs to answer.
- Earlier spontaneous events overwrote `currentTick` and executed against future state.
  They now restore the preceding history, cancel undone sends, execute, and reprocess surviving
  interactions. Their normal `FinishEvent` resolves the incoming dispatch; no extra rollback
  clear/reschedule exchange is sent for it.

Rollback also removes the complete processing suffix from its first affected event. Previously
a later-processed event with an earlier tick could remain in the log while missing from restored
state. Pure history tests cover that case and exact cancellation with checkpoint intervals 1,
2, and 50; actor tests cover surviving sends/reports and exactly one dispatch completion.

The private-vehicle adapter also omitted the active `StartTrip` request token and driver
attributes. A regression restored trip 1 after trip 2 overwrote those fields and observed a
completion with token 22 instead of token 11. Both fields now round-trip in namespaced model
snapshot metadata, without extending the core checkpoint schema. Car, Bicycle, and Motorcycle
share this adapter.

Car's journey reporter also supplied a physical input: `sumoArrivalSpeed` becomes the next
MICRO link's entry velocity. The focused replay test observed 5 m/s instead of the original
0 m/s after undoing a velocity update. Journey fields and completion guards now live in
`CarState.journey` (`CarJourneyState`), and the reporter accesses the current state through a
lambda. Restore therefore replaces physics/reporting inputs and guards together; Car no
longer clears its completion guards unconditionally after restoring a surviving prefix.

These changes preserve the existing single-policy-per-run configuration and add no mobility
dependency to core. They do not provide safe GVT, speculative lifecycle retirement, a global
same-tick order, or complete model snapshot coverage. See
[the replay validation follow-up](TIME_WARP_VALIDATION_2026_10_22.md#optimistic-replay-follow-up).

## [RESOLVED 2026-07-22] Headline Gap: an Undocumented, Orphaned Second Actor Package

**Resolution**: `model/mobility/actor/` (Car, Bus, BusStation, BusStop, Link, Node, Person, Subway,
SubwayStation, TrafficSignal, GPS — ~2,184 lines) has been deleted. Confirmed dead before removal:
a repo-wide grep found no scenario JSON, doc, or `typeActor` string outside the package itself
referencing it, with one exception — `DigitalTwinManager.entityTypeClassName` routed
`EntityType.SUBWAY`/`EntityType.PERSON` to `model.mobility.actor.Subway`/`Person` while every other
`EntityType` case already routed to `model.hybrid.actor`. That was a genuine mis-routing bug (the
digital-twin update path for Subway/Person entities would have hit the dead package), fixed as
part of this removal by routing both cases to `model.hybrid.actor` like the rest.
`model/mobility/entity`, `model/mobility/collections`, `model/mobility/util`, and
`model/mobility/types` were kept — they hold data types (`SubRoutePair`,
`VehicleLinkFlowData`, etc.) still imported by `JsonUtil.scala` and
`core/actor/manager/report/ClickHouseReportData.scala`; only the `actor` subpackage was orphaned.

Original finding, kept for history: README and `docs/*_AGENT.md` documented only
`model.hybrid.actor` (Car, Bus, Subway, Person, etc.). `model/mobility/actor/` was a second,
complete, parallel actor package not mentioned anywhere in the README or `docs/`, with
`model/mobility/actor/Person.scala` a 15-line stub — consistent with legacy/orphaned code, not an
active alternate simulation mode.

## [RESOLVED 2026-08-05] Dead Distributed Route-Forwarding Messages in model.hybrid

**Resolution**: `RequestRouteData`, `ForwardRouteData`, `ReceiveRouteData`, `RequestRoute`, and
`ReceiveRoute` (`model/hybrid/entity/event/data/`) have been deleted, along with the 3
corresponding `EventTypeEnum` cases (`RequestRoute`, `ForwardRoute`, `ReceiveRoute`) that existed
only for them. Confirmed dead before removal: a repo-wide grep found these 5 classes constructed
nowhere in `src/main` — the only references were the classes' own definitions and the unused
`EventTypeEnum` cases. Routing in the live hybrid model is entirely local and synchronous via
`GPSUtil.calcRouteCompact` (A*), called directly by `Car`/`Bicycle`/`Motorcycle`/`Movable`/
`PersonWalkingTripHandler`/`BusStationRouteCalculator`/etc. — there is no distributed hop-by-hop
route-forwarding protocol between Node/Link actors in the current codebase, though these classes'
shape (`requester: ActorRef`, an accumulating `path: mutable.Queue[(Identify, Identify)]` grown at
each "hop") strongly suggests one existed at some point and was replaced by the local A*
implementation without the messaging code being removed.

Found during the events/messages serialization audit
(`docs/EVENTS_MESSAGES_ANALYSIS.md`, recommendation 4) while investigating whether to optimize
the `Identify`-protobuf-nested-in-a-growing-queue shape these classes carried; the optimization
target turned out not to exist at runtime. `model/mobility/entity/event/data/{RequestRoute,
ForwardRoute,ReceiveRoute}Data` (the already-dead `model.mobility` package, see the gap above)
were left untouched — out of scope for this cleanup.

## Load Balancing: Promoted Migration Never Executed (Fixed 2026-10-25)

`ShardMigrationCoordinator.completeMigration` reserved the next waiting plan as
active, but LoadBalanceManager sent that plan through admission again. It was
rejected as `AlreadyMigrating`, leaving an active slot occupied by work that never
entered the execution queue.

Promoted plans now go directly into the manager's admitted execution queue.
Waiting shards are deduplicated as well as active shards, and invalid concurrency
limits fail at construction. Newly admitted/promoted work waits behind an open
wave's restore/window-close barrier; the next pause starts that work before any
ordinary simulation resume. Inactive completions cannot repeat the final resume,
and unexpected migration-safe messages cannot replace the current wave.

Validation: five pure coordinator tests and two bounded manager protocol tests
pass. The manager regression failed before the fix and now drains three waves in
order. It also covers new admission during a wave and handoff notifications that
arrive after window closure. Full `sbt test`: **660 tests in 137 suites passed**.
These tests use a one-member Pekko cluster and probe
notifications; they do not perform physical shard migration. Snapshot readiness
and source freezing were addressed separately in Step 3 below; destination
selection and other migration gaps remain open. Default custom balancing remains disabled. See
[load-balancing fix progress](LOAD_BALANCING.md#fix-progress).

## Load Balancing: Handoff Ran Model Destruction and Could Stall (Fixed 2026-10-25)

The custom `ActorCreatorUtil.createShardRegion` path configured `DestructEvent` as
Pekko's handoff stop message. That invoked model cleanup: Car could finalize a
journey and notify its owning Person, while a boarded Person could send an unload
response. The source then requested `Passivate(PoisonPill)` from a shard already
in its handoff phase. The real shard-coordinator regression reproduced this
request as unhandled, leaving the source alive until Pekko's handoff timeout.

The initial fix used `PoisonPill` directly; Step 3 extends this to a dedicated
`MigrationHandoffStopEvent` that also drains frozen inputs and awaits final capture.
Handoff stops the source without model
destruction, passivation round-trips or destruction-counter increments. Explicit
`DestructEvent` continues to perform normal modeled cleanup.

Validation: two new `ShardHandoffLifecycleSpec` cases run actual shard handoff and
re-creation for subclasses of Car and Person on a one-member cluster. They check
the absence of model effects, preserved captured state/reply identity after an
explicit snapshot restore, and normal trip/unload cleanup on later legitimate
destruction. Both cases failed before the fix because the handoff did not stop
the source. All 11 focused lifecycle/queue/passivation tests pass, and full
`sbt test` passes **662 tests in 138 suites**. These tests do
not establish multi-JVM delivery or the full snapshot-save/window protocol;
remaining migration gaps and the conservative-only scope are unchanged. See
[Step 2](LOAD_BALANCING.md#step-2--shard-handoff-without-model-destruction-2026-10-25).

## Load Balancing: Save Readiness and Source-to-Stop Lost Updates (Corrected 2026-10-25)

The controller previously opened the migration window after an elapsed delay,
without evidence that all source snapshots had reached SnapshotManager. Sources
also kept applying messages after capture, so their later state changes were
absent from the restored snapshot (Gap C below).

Batch registration now has an ACK before source preparation. Each source captures
once and freezes subsequent ordinary input. SnapshotManager validates and stores
the full expected set before acknowledging readiness; only then does the
controller publish window-open. Batch/phase/membership checks reject premature or
duplicate progress notifications. At actual Pekko handoff, while the region buffers
new arrivals, the source drains its retained inputs with their original senders
and saves a final snapshot including their effects. It stops only after the final
revision is acknowledged, without model cleanup. A late accepted input requires
another final revision. This avoids discarding a source-only stash or placing
earlier retained inputs behind the region's newer buffered inputs.

A target query for a registered entity without its final cut fails preparation;
it cannot restore the initial checkpoint or fall back to fresh initialization.
The checkpoint is retained. Final capture/save failures stop the source directly,
since the region is already buffering ordinary shutdown messages at this stage.

Missing storage, unroutable sources, conflicting saves, and capture failures stop
the run instead of resuming it with incomplete state. A correlated abort unfreezes
sources for shutdown. There is no elapsed-time fallback to handoff or normal
initialization. Independent failure recovery remains unsupported.

Tests cover the store barrier, duplicate/conflicting inputs, controller ordering,
failure without resume, control-message serialization between independent codecs,
and a bounded actual single-member shard handoff preserving frozen input and
sender, waiting for final acceptance, and restoring the resulting final state.
This does not establish durable storage, complete source membership,
multi-JVM allocator ownership/target selection. Acknowledged restore retention
was addressed separately in Step 4 below. The store remains singleton memory.
Rebalancing remains disabled by default; the accounted runtimes and
optimistic migration are outside this fix. See
[Step 3](LOAD_BALANCING.md#step-3--acknowledged-snapshot-preparation-and-source-freezing-2026-10-25).

Validation: **27 focused tests in five suites** and the full **676 tests in 139
suites** pass on 2026-10-25. These Step 3 results do not establish a full multi-JVM migration run.

## Load Balancing: Snapshot Removed Before Target Application (Corrected 2026-10-25)

`SnapshotManager.handleQueryMigration` removed the snapshot and counted an entity
as consumed when sending `MigrationContextEvent`. The target separately ACKed
LoadBalanceManager before its `onMigrationRestore` hook ran. Lost delivery or a
throwing hook could therefore lose the retained state or report success too early.

Queries now retain the final snapshot and bind an offer to entity, batch, target
ActorRef, random restore token, and final revision. Only the matching target's
confirmation after state application and completion of its restore hook permits
release. SnapshotManager sends `MigrationRestoreAcceptedEvent` to the controller;
raw target ACKs cannot close the migration window. Invalid or stale confirmations
cannot release state, and all expected entities must confirm before a batch ends.

Repeated queries return the same offer, and repeated target contexts resend the
confirmation without reapplying state or repeating the hook. Failed application
stops the target, fails the run, and retains the snapshot until shutdown; a later
success ACK cannot override that failed offer. Different target incarnations are
rejected rather than silently reinitializing. Lightweight latest-completion
receipts prevent duplicate queries from turning into `NoPendingMigrationEvent`.
Receipts also allow idempotent re-notification of store acceptance to the manager.

Validation includes store and target protocol specs, controller phase checks,
independent codecs for restore controls/context, and actual single-member
Car/Person shard handoff followed by querying the real SnapshotManager and
confirming application. The codec regression also exposed a missing serializer
binding for `MigrationContextEvent`; it now has an explicit Jackson CBOR binding.
Its cold-codec case includes runtime references and a nonempty reporter map.

This is acknowledged volatile retention, not durable recovery. Store state and
latest-entity receipts are cleared at simulation shutdown. Receipt memory grows
with distinct migrated entities. Independent restarts, asynchronous external
effect recovery, full multi-JVM migration, allocator installation, and enforced
destination selection remain outside this correction. Custom rebalancing remains
disabled, and no accounted conservative/optimistic migration support is added.
Destination selection is addressed separately in Step 5 below.
See [Step 4](LOAD_BALANCING.md#step-4--snapshot-retention-until-confirmed-target-application-2026-10-25).

Validation on 2026-10-25: **32 focused tests in six suites** and full `sbt test`
with **686 tests in 141 suites** pass. `git diff --check` passes.

## Load Balancing: Planned Destination Ignored and Actor-Type Commands Shared (Corrected 2026-10-25)

`LoadBalanceManager.triggerPekkoHandoff` selected the first indexed nonempty region
instead of resolving the plan's target node. The allocator could then silently
fall back if an explicit target was unavailable. Its command maps were shared
between physical actor types even though Pekko scopes shard IDs by type, so one
type's callback could consume another type's request for the same ID.

Preflight now resolves every represented dynamic actor type against its observed
source owner and the requested node's registered region, including idle regions.
Both nodes must be Up members. Missing/ambiguous membership or regions, wrong
source ownership, and source equal to target fail preparation. Logical groups
containing pinned infrastructure are rejected; static-only plans retain the
existing skip behavior. Destinations are checked again after window-open ACKs.
There is no arbitrary-region substitution.

The factory installs stable per-type child allocators. Desired placement,
rebalance requests, and authoritative callback indices are isolated by type.
Callback snapshots evict absent regions while retaining idle ones; local region
addresses are recorded explicitly. A missing explicit target causes allocation
failure rather than least-shards fallback. Initial unplanned allocation retains
its heuristic. Requests skipped while already in progress remain pending.

A bounded two-member cluster fixture moves a live actor from the source to the
requested idle target through the real manager, factory, shard coordinator,
source final-save barrier, SnapshotManager restore, and store confirmation. Its
value **23** survives; actual region-state queries prove the source no longer
hosts the shard and the requested target does. Unit/protocol cases cover strict
placement, idle targets, stale callbacks, colliding type-local IDs, cancellation,
pending requests, ambiguity, missing targets, and pinned/multiple-type groups.

The two ActorSystems share one JVM/allocator registry. The fixture supplies the
conservative pause response, node window ACKs, and target query explicitly, with
the global migration flag off for suite isolation. It does not validate separate
JVM allocator authority, complete membership discovery, failure recovery, or the
full distributed window/startup protocol. Step 6 separately replaces the old
monitor's request-consumption and retry-limit success notifications.
Custom balancing remains disabled; no accounted conservative/optimistic
migration adapter is added. See
[Step 5](LOAD_BALANCING.md#step-5--enforce-the-planned-destination-per-physical-shard-type-2026-10-25).

Validation on 2026-10-25: **47 focused tests in nine suites** and full `sbt test`
with **696 tests in 143 suites** pass. The two-member fixture also verifies that
duplicate ACKs from one node cannot replace the other node's open/close ACK.
`git diff --check` passes.

## Load Balancing: Request Consumption Reported as Completion (Corrected 2026-10-25)

The monitor treated removal from the allocator's pending set as completed
migration, although that only meant Pekko consumed the request. After 20 checks
it also reported success for a still-pending request. Completion messages carried
only a shard ID, so an old result could retire a newer attempt for that shard.

Each handoff now has a fresh UUID tied to its batch. The monitor queries the
preflight source and target region ActorRefs for every physical type. One round
must show the shard absent from every source and present at every planned target,
with complete, nonfailed region-state responses. Failed queries, partial state,
remaining source ownership, missing targets, and results from different rounds
cannot establish placement. Queries use `pipeTo(self)`; only actor message
handling changes migration state and queue/statistics bookkeeping.

There is at most one round in flight per attempt; failures are converted to
incomplete evidence before joining the queries, so one immediate failure cannot
start overlapping rounds while another query is pending. Incomplete rounds poll
again after 500 ms. The five-second query timeout never authorizes completion,
and there is no success-after-retry-limit path.

Placement and SnapshotManager's accepted restores must both finish for a logical
shard before internal completion can retire admission. Batch, attempt, verified
state, and self-sender checks reject stale, legacy, duplicate, or unsolicited
completion messages. Window closing additionally waits for every logical shard;
normal resume waits for window-close ACKs and the admitted queue. Shutdown no
longer sends a normal migration-complete notification, and failed/stopped runs
cancel polls and discard later observations. Static plans retain their explicit
skip behavior with correlated bookkeeping.

Tests cover both barrier orders, failed/partial observations, bounded in-flight
rounds, every physical type and cross-round isolation, repeated moves of the same
shard, stale batch/attempt/round notifications, unsolicited completion, queue
sequencing, failure/shutdown, static skip, and independent completion codecs.
The real two-member relocation fixture now completes through this monitor and
the store restore-confirmation path, preserving its value 23 at the planned target.

The fixture shares one JVM/allocator registry and explicitly supplies pause,
node window ACKs, and the target query. Separate-JVM allocator authority and
complete membership discovery remain unvalidated. Placement observations are not
an ownership lease or a node-loss/restart recovery protocol. An unreachable
region can keep the migration unverified until the run is stopped. Custom
rebalancing remains disabled and accounted conservative/optimistic migration is
not enabled. See
[Step 6](LOAD_BALANCING.md#step-6--observed-placement-accepted-restore-and-correlated-completion-2026-10-25).

Validation on 2026-10-25: **53 focused tests in nine suites** and full `sbt test`
with **702 tests in 143 suites** pass. `git diff --check` passes.

## Load Balancing: Allocation Authority Existed Only in the Singleton JVM (Corrected 2026-10-25)

Regions started on every JVM before LoadBalanceManager could register its local
allocator object. Worker coordinators could therefore retain Pekko's default
strategy while the controller mutated an unused object. Per-type isolation in
Step 5 did not distribute that authority.

Enabled factories now install remote per-type adapters, backed by an
ActorSystem-local node client and a cluster allocation-authority singleton.
Registered region references, addresses, and client incarnations are explicitly
acknowledged. The authority owns callback snapshots, controller binding, and
placement intents. Callbacks carry sequences; replies carry request identities
and authority epochs. A callback cannot consume intent by receiving a reply:
intent remains until observed placement, store-confirmed restoration, and
acknowledged controller retirement. Installing a logical move covers all its
physical types atomically. Explicit destinations cannot fall back.

The controller's preflight/install/retire exchanges are asynchronous and change
state through actor messages. Stale epochs or replacement callback owners,
regions, and controllers fail closed. Disabled custom allocation remains passive.
This supports one fixed run per cluster; it does not add independent recovery.

The first separate-JVM fixture also reproduced physical handoff without idle
entity recreation. After placement is observed, the enabled controller now
starts its known target cohort explicitly. Native start ACKs do not replace
SnapshotManager's restore confirmation. The real window flags trigger automatic
target queries. The subscriber no longer performs a blocking proxy lookup, and
ordinary membership transitions no longer restart the controller through MatchError.

An accepted independent-process fixture places the controller actor and active
shard coordinator in different JVMs. A live actor moves to the requested worker
with value 23 preserved; real source/target queries prove ownership and both
window flags close. Both local allocator registries are absent. The fixture uses
hash routing and controller-provided membership; the worker's spatial registry
is empty. Distributed spatial assignments/live cohort discovery are still a real
gap. The fixture pins the controller actor and supplies a pause probe, so full
SimulationManager/controller election and actual conservative traffic migration
remain separate acceptance work. No accounted-runtime migration is enabled.
See [Step 7](LOAD_BALANCING.md#step-7--allocation-authority-and-region-registration-across-jvms-2026-10-25)
and the [validation record](DISTRIBUTED_ALLOCATION_VALIDATION_2026_10_25.md).

Validation on 2026-10-25: **63 focused tests in ten suites**, full `sbt test`
with **712 tests in 144 suites**, and the independent-JVM run
`/tmp/htc-allocation-authority-20261025-3/` pass. The classpath is unchanged during
the run and content-hashed; both captured execution logs have zero engine errors.
The first idle-entity failure remains rejected evidence. `git diff --check` and
Python launcher compilation pass.

## Load Balancing: Spatial Membership and Classification (Component Corrected 2026-10-25; Distributed Integration Open)

Quadtree registration previously updated lookup maps without populating leaves,
so density-based refinement never activated. Its dormant branches redistributed
from a placeholder coordinate, lost membership during balance splits, reused
Morton-only IDs across depths, and could repeatedly consult an obsolete root.
Registration now retains coordinates and leaf membership; split/merge/balance
preserve entities and rebuild indexes. IDs include depth. Configuration and
coordinate validation prevent out-of-bounds registrations from silently mapping
to a branch ID. Hybrid/GeoAffinity and the manager share class-based classification
with a legacy-ID fallback. GeoAffinity no longer assigns each namespace the total
count of a mixed geographic region.
Invalid spatial registration now stops the run through the existing fatal path
instead of restarting the manager and losing previously published assignments.

Repairing population exposes a further integration gap: periodic refinement would
change IDs already returned to CreatorLoadData without updating all routing JVMs.
Strategy evaluation now preserves that published topology. The repaired component
is independently testable, but the integrated strategies keep their initial root
until coordinated partition publication exists. Distributed entity assignments,
live cohort discovery, and adaptive geographic integration remain open; custom
balancing remains disabled by default. See [Step 8](LOAD_BALANCING.md#step-8--spatial-membership-invariants-and-shared-classification-2026-10-25)
for validation and scope.

Validation: **31 focused tests in three suites**, followed by full `sbt test`:
**732 tests in 146 suites** pass. `git diff --check` passes. The repaired tree is
component-tested; distributed spatial migration remains outside this evidence.

## Load Balancing: Spatial Assignments Were Local to Creation JVMs (Directory Implemented 2026-10-25; Live Membership Open)

CreatorLoadData previously installed shard assignments only in its own process.
Other routing JVMs silently chose hash buckets for those same IDs, and the
controller's migration cohort could omit entities created elsewhere. A ten-second
creation timeout could also create hash-routed actors before a late spatial reply
rewrote the registry. Batch responses updated registries before checking whether
their chunk was still pending.

An authority now publishes typed immutable assignments to a replica on every Up
routing JVM and waits for all installation ACKs before the manager answers the
creator. Epoch/revision/replica identities gate readiness and completion. Enabled
native extraction requires a published entity/type row. Creator chunk correlation
precedes writes; the timeout-to-hash path is removed. Invalid publication/replies
stop the run. The supported directory has fixed cluster membership and no independent
recovery. These changes distribute creation assignments; initialized/live/retired
membership, progressive enrollment and adaptive partition publication remain open.
See [Step 9](LOAD_BALANCING.md#step-9--acknowledged-spatial-directory-publication-2026-10-25)
and the [directory contract](DISTRIBUTED_SPATIAL_DIRECTORY.md) for validation and limits.

Validation: **34 focused tests in four suites**, full `sbt test` with **745 tests
in 147 suites**, and two independent-JVM publication/migration cases pass. The
spatial case uses a production GeoAffinity assignment; both cases preserve value
23, route from each JVM to the same restored actor, close both windows, and capture
zero pre-teardown engine errors with an unchanged executable hash. See the
[validation record](DISTRIBUTED_SPATIAL_VALIDATION_2026_10_25.md). The controller
and safe-boundary fixture remain controlled; full traffic and live lifecycle
membership are not accepted by this evidence.

## Shard Migration Silently Drops Actor-Local Reply State (Currently Latent — Migration Is Disabled)

**[RESOLVED 2026-07-22] Gaps A and B below are fixed.** `PrivateVehicle` gained
`captureMigrationFields`/`restoreMigrationFields` (called from each concrete vehicle's
`buildMigrationSnapshot`/`applyMigrationSnapshot` override — `Car.scala`, `Bicycle.scala`,
`Motorcycle.scala`, since a trait with a self-type can't itself call `super` on a method it doesn't
extend), and `Person` got the equivalent override for `currentPTVehicleRef`. `MigrationSnapshot`
carries the new fields with safe defaults so old snapshots still deserialize. Round-trip coverage:
`src/test/scala/model/hybrid/actor/PrivateVehicleMigrationSnapshotSpec.scala` and
`PersonMigrationSnapshotSpec.scala`.
**[CORRECTED 2026-10-25] Gap C's source-to-stop window is addressed separately**
by source freezing and acknowledged preparation; see Step 3 above for tested
scope and remaining distributed migration limitations. Fixing A/B alone did not resolve it.

Root-caused while investigating why `Car`/`Bicycle`/`Motorcycle` could fail to emit `TripCompleted`.
The original fix attempt (`vehicleTripTimeoutTicks`, commit `932798f`) was correctly reverted in
`420b285` in favor of a structural guarantee (`Car.onDestruct` always calls
`onFinishPrivateVehicle` when `state.status != Finished`). That fixes the trip-lifecycle case, but
three related gaps traced back to one shared structural cause. The original
findings below are retained as history; A/B were fixed in July and C was corrected
in October within the scope stated above:

- **A — `PrivateVehicle` reply-linkage vars aren't covered by migration snapshots.**
  `ownerPersonRef`, `personCentric`, `tripOrigin`, `tripDestination`, `tripStartTick` live as plain
  `var`s on the actor (`PrivateVehicle.scala:33-69`), not inside `state: T`. `BaseActor.buildMigrationSnapshot`
  (`BaseActor.scala:286-291`) only serializes `state`, and no actor under `model.hybrid` overrides
  `buildMigrationSnapshot`/`applyMigrationSnapshot` to add these fields. If a vehicle migrates
  shard mid-trip, it rehydrates with `ownerPersonRef = None`; `reportTripCompletion`
  (`PrivateVehicle.scala:205-206`) becomes a silent no-op, and `personCentric` resetting to `false`
  also risks an incorrect `selfDestruct()` for a still-owned vehicle.
- **B — same pattern on `Person.currentPTVehicleRef`.** The Bus/Subway boarding-response barrier
  (`expectedUnloadResponses`) was correctly fixed in commit `531ca55` by having `Person.onDestruct`
  always answer the vehicle it's boarded on. That fix depends on `currentPTVehicleRef`, itself a
  plain actor-local `var`, not part of `PersonState` — so it reopens the same barrier deadlock if
  `Person` migrates shard while boarded.
- **C — [CORRECTED 2026-08-05, original diagnosis was stale] not a retry-loop/lossy-buffer bug;
  re-investigated and found a different, more precise real gap.** The original write-up named
  `Car.signalStateRetryCounter` (`Car.scala:252-262`) — **this no longer exists**, superseded by
  the `RequestLinkAccess`/`LinkAccessData` rework (the congestion-propagation feature): `Car` now
  genuinely deregisters (`onFinishSpontaneous(None)`) and waits for the Node's reply as a pure
  interaction event, no polling/retry counter at all. The original write-up also named `MessageBuffer`
  as "silently drops buffered messages once `maxBufferSize` is exceeded" — checked directly:
  `MessageBuffer.buffer()`, the only method that would ever enqueue a real message, **had zero
  callers anywhere in the codebase**. `ShardMigrationCoordinator` only ever called
  `startBuffering`/`drainBuffer`/`abortBuffering`/`totalBufferedCount` — bookkeeping methods that
  never actually intercepted a message. It provided no protection whatsoever, working or broken;
  it was dead scaffolding, not a flawed-but-active safety net. **Removed** (`MessageBuffer.scala`
  deleted; `ShardMigrationCoordinator`'s unused `messageBuffer` field and its call sites removed;
  `MigrationStats.totalBufferedMessages` removed, since it always reported 0 and nothing consumed
  it) rather than left as misleading dead code implying a protection that doesn't exist.

  **What actually protects in-flight messages during migration, confirmed by reading the real
  protocol end-to-end (`LoadBalanceManager.handleMigrationSafe`/`handleWindowAck`,
  `MigrationWindowSubscriber`, `SimulationBaseActor.preStart`)**: (1) `LoadBalanceManager` asks the
  TimeManager to pause at a safe tick boundary before migrating anything — no spontaneous events
  are in flight during the whole migration wave; (2) a distributed "migration window" protocol
  (`MigrationWindowOpenEvent`/`Close`, `DistributedPubSub`) sets a per-node
  `MigrationStateStoreRegistry.isMigrationActive` flag *before* Pekko's rebalance is triggered; (3)
  on the target node, `SimulationBaseActor.preStart` checks that flag — if set, the entity queries
  the `SnapshotManager` for its restored state and **genuinely `stash()`es every other incoming
  message** until `MigrationContextEvent`/`NoPendingMigrationEvent` arrives, then `unstashAll()`s;
  (4) the actual shard relocation goes through real `org.apache.pekko.cluster.sharding.ClusterSharding`
  (confirmed in `ActorCreatorUtil.scala`), which has its own native, well-tested hand-off buffering
  for messages arriving mid-rebalance. This is a real, working, reasonably sophisticated protocol —
  `MessageBuffer` was apparently an earlier or parallel design that got superseded by it and never
  cleaned up.

  **Historical corrected finding (addressed by Step 3 above)**: `LoadBalanceManager.handlePrepareForMigration`
  (via each entity's `BaseActor.handlePrepareForMigration`) captures a source entity's
  `MigrationSnapshot` and sends it to the `SnapshotManager` — but the source entity is **not**
  stopped, passivated, or put into any restricted mode at that point; it keeps processing messages
  completely normally until Pekko's rebalance is triggered later (only after every cluster node
  ACKs "window open", per `handleWindowAck`'s `PHASE_OPEN` branch). The TimeManager pause prevents
  the entity's *own* spontaneous activity in this window, but an **interaction-event reply from
  another actor** (e.g. a `LinkAccessData` a Car was already waiting on) can still arrive and be
  processed normally in that gap — mutating `state`/actor-local vars *after* the snapshot was
  already captured and sent. That mutation is never reflected in what gets restored on the target
  node: a genuine lost-update window, not a dropped message. At that review this was dormant (migration
  disabled — see below) and required a protocol design (e.g. have the source
  entity also enter a stash/reject mode the moment it sends `PrepareForMigrationEvent`, or
  re-snapshot immediately before the actual Pekko-triggered stop instead of once, early) — not
  attempted during that dead-code removal. The separate 2026-10-25 correction
  implements freezing and transport transfer with focused protocol/handoff tests.

  **Validation for the dead-code removal**: `sbt compile` clean, `sbt test` 172/172 (no test
  referenced `MessageBuffer`/`ShardMigrationCoordinator` at all — confirmed by grep before
  removing, so there was nothing to update). `sbt assembly` succeeds.

**Why this hadn't bitten anyone yet**: shard rebalancing/migration is currently kept disabled while
the project prioritizes simulation execution quality and performance — see `CLAUDE.md`'s Actor
State section. These gaps were real but dormant; A/B are now fixed (see above) so they no longer
become load-bearing if migration is turned back on. Gap C's
`PrepareForMigrationEvent`-to-actual-stop lost-update window was corrected in
Step 3. The other migration gaps documented in `LOAD_BALANCING.md` still need
resolution and acceptance evidence before rebalancing can be safely enabled.

## Simulation Runs Are Not Fully Reproducible for a Fixed Seed — Duplicate Spontaneous-Event Dispatch (Structural duplicate dispatch: RESOLVED 2026-07-25, TM-level fix; small residual timing drift still open)

Found 2026-07-24 while validating the new SQLite input format (see `SCENARIO_MODELING.md` §3/§8)
end-to-end against a real cluster run. Running the **identical** scenario (same `simulation.json`,
same `randomSeed`, same topology) twice produced materially different `enter_link`/`leave_link`
event totals for the same bus completing laps on a fixed 2-link loop (originally 9150 vs. 5527
`enter_link`s across two JSON runs — see git history for the full original table). All runs
reached the same final simulated tick, ruling out early termination; the divergence is caused by
`actSpontaneous` effectively firing extra times per run, at ticks that vary run to run, which
shifts how many laps fit in the same tick budget.

**Root cause, part 1 (fixed 2026-07-24): `BusStopHandler.requestLoadPassenger`/
`requestUnloadPeopleData` polled blindly instead of waiting for the async reply.**

`BusState.status` and `BusState.movableStatus` are **the same field** — `BusState.status` is a
`def`/`def _=` delegate straight onto the inherited `MovableState.movableStatus` var
(`BusState.scala:96-97`). This matters because `requestLoadPassenger` set
`state.status = WaitingLoadPassenger`, sent `BusRequestPassengerData` to the `BusStop`, and then
— before this fix — immediately called `onFinishSpontaneousFn(Some(currentTick + 1))`, an
unconditional "poll again next tick" pattern. `Bus.actSpontaneous`'s
`case WaitingLoadPassenger => enterLink()` cannot distinguish "still waiting for the stop's
`BusLoadPassengerData` reply" from "boarding just finished, proceed" — both look identical because
`handleBusLoadPeople` (the actual boarding-complete handler) reuses the exact same status value.
So: if the stop's reply took longer than one tick, the blind poll fired `enterLink()`
*prematurely*, sending a first `EnterLinkData`. When the stop's real reply arrived afterward,
`handleBusLoadPeople` reset `status` back to `WaitingLoadPassenger` and rescheduled again, and the
next dispatch's `case WaitingLoadPassenger => enterLink()` fired a *second*, genuinely duplicate
`EnterLinkData` for a link already registered. Confirmed directly via instrumentation (temporary,
since removed) showing, at every duplicate, `status=WaitingLoadPassenger` twice in a row across
consecutive ticks, each with its own `enterLink()` call.

Fix applied in `BusStopHandler.scala`:
- `requestLoadPassenger`/`requestUnloadPeopleData` now call `deferFinishSpontaneousFn()` (added as
  a new constructor lambda, wired to `SimulationBaseActor.deferFinishSpontaneous()` in `Bus.scala`)
  instead of polling — the spontaneous event is left unresolved until the stop's reply actually
  arrives, exactly the "consistency-critical" pattern `CLAUDE.md`'s Synchronization Discipline
  already prescribes.
- `handleBusLoadPeople`/`handleUnloadPassenger`'s own reschedule was changed from `scheduleEventFn`
  (a raw `ScheduleEvent` message) to `onFinishSpontaneousFn` (a proper `FinishEvent`). This was a
  **second, dependent bug**, only surfaced once the poll above was removed: `ScheduleEvent` adds
  the actor to `scheduledActors` but does **not** clear the TimeManager's `runningEvents`
  bookkeeping — only a `FinishEvent` does. The old poll's `FinishEvent` had been incidentally
  clearing `runningEvents` on every tick as a side effect; removing it without also fixing this
  caused the bus to permanently stick in `runningEvents` (confirmed: `[STALL]` /
  `[GTM-STALL] ... stuck actors: Bus/...` warnings after ~3-4 minutes). Switching both call sites
  to `onFinishSpontaneousFn` fixed the stall and preserved correct rescheduling.
- Also fixed the same "reused status value, blind poll" pattern in `Bus`/`Motorcycle`/`Bicycle`/
  `Subway`'s `case Ready => enterLink()` (and `Bus`'s `case WaitingLoadPassenger` re-entry path):
  `Movable.enterLink()` only ever sets `state.movableStatus = Waiting`, but only `Car` is
  incidentally protected by it (it has no explicit `case Ready` and falls through to `Movable`'s
  base `actSpontaneous`, which *does* check `movableStatus == Waiting`). The other four vehicle
  types match on `state.status` directly, so added an explicit `state.movableStatus == Waiting`
  guard before each of those `enterLink()` call sites too (belt-and-suspenders — see part 2 below
  for why this alone wasn't sufficient).

**Result, validated against the full 86,400-tick baseline scenario with the fixed `randomSeed`**:
same-link duplicate `enter_link` count dropped from the original ~30/1770 (~1.7%) baseline — which
itself had been made *worse* by the guard-only fix above in isolation (41-99/1790, ~2.3-5.5%,
across a few runs, before the `deferFinishSpontaneousFn`/`onFinishSpontaneousFn` fix landed) — down
to **16/1767 (~0.9%)**, with the first duplicate now appearing at tick ~26,000 instead of ~3,650.
111/111 tests pass; no stalls in the validated run.

**Root cause, part 2 (not fixed — architectural, affects every "send + immediately poll"
call site): late-arriving redundant `FinishEvent`s get bumped to the wrong tick by
`LocalTimeManagerBase.finishEvent`'s own orphan-prevention logic.**

The residual ~16 duplicates were traced (via temporary `Console.err` instrumentation with
JVM stack traces on every `onFinishSpontaneous`/`deferFinishSpontaneous`/`scheduleEvent` call for
the bus, since removed) to a *different* mechanism than part 1. At the tick where a bus leaves a
link, **three independent call sites** each call `onFinishSpontaneous(Some(currentTick + 1))` for
what is logically one resolution: `BusSignalHandler.requestSignalState` (waiting for the node's
signal reply), `Movable.leavingLink` (right after sending `LeaveLinkData`), and
`BusLinkHandler.handleLeaveLink` (the *link's* reply confirming the vehicle left). Normally this is
harmless — all three add the same `Identify` to the same `scheduledActors(tick+1)` `Set`, which
naturally de-duplicates. But if one of them (typically the link's reply — it has an extra
actor-hop, so it tends to arrive last) reaches the TimeManager *after* `localTickOffset` has
already advanced past that tick, it hits this guard in `LocalTimeManagerBase.finishEvent`:
```scala
val effectiveTick = if (tick <= localTickOffset) localTickOffset + 1 else tick
```
This logic exists to prevent a legitimately-late `ScheduleEvent`/`FinishEvent` from being silently
dropped (see the `scheduleEvent` comment on the same rationale) — but here it "rescues" an
already-redundant reschedule by bumping it to `localTickOffset + 1`, creating a **genuine extra
schedule entry one tick later than anything the actor's own code intended**. If that phantom tick
happens to land while the bus is mid-flight in an unrelated async wait (e.g. genuinely still
waiting on `WaitingLoadPassenger` for the stop's reply from part 1's fixed code path), the
`case WaitingLoadPassenger => enterLink()` branch fires on a status value that hasn't actually
changed, producing the same class of duplicate `EnterLinkData` as part 1, just via a different
trigger. Confirmed directly: at every residual duplicate, exactly this triple-`FinishEvent`
pattern preceded it by one dispatch cycle.

This is architectural, not a one-line fix: the "send a message, then unconditionally
`onFinishSpontaneous(Some(currentTick + 1))` to poll again" pattern is used at many call sites
across `Movable`/`BusSignalHandler`/`BusLinkHandler`/etc., each implicitly relying on the
`scheduledActors` `Set`'s natural de-duplication to make redundant reschedules harmless — which
holds *except* when the orphan-rescue bump above turns a late redundant reschedule into a distinct
tick.

**Attempted and reverted (2026-07-25): removing `Movable.leavingLink()`'s own redundant poll.**
`Movable.leavingLink()` sends `LeaveLinkData` then immediately polls
(`onFinishSpontaneous(Some(currentTick+1))`) — redundant with `BusSignalHandler.requestSignalState`'s
own poll one step earlier in the same leave sequence, and exactly the mechanism behind the
tick-3651-triple-`FinishEvent` example above. Replaced it with `deferFinishSpontaneous()`, relying
solely on the Link's `LinkInfoData` reply (`*LinkHandler.handleLeaveLink`) to resolve — same pattern
already applied successfully to `BusStopHandler` earlier in this investigation. **This caused a
genuine stall** (`[STALL] ... stuck actors: Subway/...` at tick 622, well before the bus's own
gap would even matter) — reverted immediately. Root cause of the stall, found before reverting:
`Subway.actHandleReceiveLeaveLinkInfo` **intentionally** does not always resolve the spontaneous
event —
```scala
// If status is already Waiting/Ready/Stopped the subway is managing its
// own scheduling; suppress the duplicate FinishEvent to avoid a spurious extra tick.
if (state.status == Moving) {
  state.status = Ready
  onFinishSpontaneous(Some(currentTick + 1))
}
```
— i.e. this reply handler is *itself* written assuming a fallback poll exists elsewhere to cover
the case where it silently no-ops. Removing the poll broke that assumption and the actor hung
until the watchdog. **This is strong evidence the "redundant poll" pattern is load-bearing by
design in multiple places, not accidental duplication** — every reply handler in this family
(`Bus`/`Car`/`Motorcycle`/`Bicycle`'s `handleLeaveLink` also have their own
`state.status == Parked || Finished` stale-discard guards, e.g.) was written on the assumption
that *some* poll elsewhere covers the case where it doesn't fire. Consequently: **do not attempt
to remove any individual poll site again without first either (a) auditing and making *every*
interacting reply handler unconditionally resolve on every branch, system-wide, in one
coordinated change, or (b) fixing this at the TimeManager level instead** — e.g. giving
`LocalTimeManagerBase` a way to recognize that a `FinishEvent` is stale relative to an actor that
has already been dispatched again more recently (a per-actor "last dispatched tick" map, comparing
against `FinishEvent.end`, would let `finishEvent` drop a stale/redundant reschedule instead of
bumping it into a phantom tick) without touching any actor-level logic or its careful
stale-suppression guards. This second option is the safer next step for whoever continues this,
precisely because it doesn't require touching (and re-verifying) every one of these interacting
state machines at once.

**Root cause, part 3 (found and fixed 2026-07-25): `handleBusLoadPeople` had no stale-reply guard.**
Classified all ~11 residual duplicates from a full 86,400-tick run (each traced via caller-tagged
`onFinishSpontaneous` logging, temporary, since removed) and found they shared one dominant
mechanism, distinct from part 2's leaving-link triple-poll: `BusStop`'s `BusLoadPassengerData`
reply to a `RequestPassenger` (sent by `requestLoadPassenger`) can arrive **after** the bus has
already moved on from that `WaitingLoadPassenger` cycle — e.g. it entered the next link via its own
`enterLink()` poll before the stop's reply made it through the mailbox. `handleBusLoadPeople` had
no guard against this: it unconditionally set `state.status = WaitingLoadPassenger` (recall this is
the *same field* as `movableStatus`, see part 1) and rescheduled, which made
`Bus.actSpontaneous`'s `case WaitingLoadPassenger => enterLink()` fire a second, spurious time for a
link already entered.

This is the **same class of bug as part 1**, just via a different stale-arrival path, and the fix
follows the same already-proven pattern already used elsewhere in this codebase for exactly this
situation (`BusSignalHandler.handleSignalState`'s `state.status != WaitingSignalState` check;
`Car`/`Motorcycle`/`Bicycle`'s `status == Parked || Finished` checks in their `handleLeaveLink`) —
**a stale-reply guard, not a resolver removal**. This is why it's safe where parts 2's two attempts
(removing `Movable.enterLink()`'s and `Movable.leavingLink()`'s polls, relying solely on the
reply) were not: those removed a resolver that other code depended on always firing; this only
skips a reschedule when the reply is *already known to be irrelevant* (state has moved on), and
never touches the always-on resolver path.

Fix applied in `BusStopHandler.handleBusLoadPeople`: compute
`isStaleReply = state.status != WaitingLoadPassenger` at entry, keep passenger boarding
unconditional (people are already committed by the stop, discarding the message would leak them
out of the simulation), but skip the `state.status = WaitingLoadPassenger` /
`onFinishSpontaneousFn` reschedule when `isStaleReply`.

**Result: 0/1759 and 0/1758 same-link duplicate `enter_link`s across two independent full
86,400-tick runs with the fixed `randomSeed`** (down from the original ~30/1770, and from
~11-16/1770 after parts 1+2's fixes). No `[STALL]`/`[GTM-STALL]` warnings in either run. 111/111
tests pass. This closes the non-reproducibility bug **for the bus-loop scenario tested** — two
back-to-back runs now produce identical `enter_link`/`leave_link` totals.

**Scope note — not a full architectural fix.** Part 2's finding still stands: the "send a message,
then unconditionally poll `onFinishSpontaneous(Some(currentTick+1))`" pattern, and the
correspondingly-necessary stale-reply guards on its reply handlers, are used throughout
`Movable`/`*SignalHandler`/`*LinkHandler`/`BusStopHandler` for `Car`/`Motorcycle`/`Bicycle`/`Subway`
too, not just for `Bus`'s load-passenger exchange. This session fixed the one instance proven (via
full-scenario instrumentation) to dominate the one bus-loop scenario tested; other vehicle
types/exchanges were not similarly stress-tested and may have their own not-yet-observed instances
of the same missing-stale-guard pattern (check any reply handler that unconditionally reassigns
`state.status`/`state.movableStatus` and reschedules, without first checking whether that status is
still current). The TimeManager-level fix suggested in part 2 (recognizing a `FinishEvent` as stale
relative to an actor's more recent dispatch, instead of "rescuing" it into a phantom tick) would
close the whole family of gaps at once rather than one reply handler at a time, and remains the
more complete option for whoever wants to close this permanently rather than reactively.

**Root cause, part 4 (implemented 2026-07-25): the TimeManager-level generation-counter fix
suggested above.** Closes part 2's remaining architectural gap without touching any actor-level
reply handler.

Added a per-actor **dispatch generation** counter to `LocalTimeManagerBase`
(`dispatchGeneration: mutable.Map[String, Long]`), incremented every time the TM actually sends an
actor a `SpontaneousEvent` (in `sendSpontaneousEvent(tick, identity)`, covering both the shard and
pool dispatch paths, and both `LocalDiscreteEventTimeManager`'s batching and
`LocalTimeSteppedTimeManager`). The new generation value is embedded in the `SpontaneousEvent`
itself (`SpontaneousEvent.generation: Long`, new field, default 0). `SimulationBaseActor` records
whatever generation it most recently received (`currentGeneration`, updated in `handleSpontaneous`)
and echoes it on **every** `FinishEvent` it sends (`FinishEvent.generation: Long`, new field) —
regardless of whether that `FinishEvent` is sent synchronously from `actSpontaneous` or later from
an async reply handler (`handleEnterLink`, `handleLeaveLink`, `handleBusLoadPeople`,
`handleSignalState`, etc.) — since `currentGeneration` isn't touched by
`actInteractWith`/interaction-event processing, only by receiving a new `SpontaneousEvent`.

`LocalTimeManagerBase.finishEvent` now checks, before doing anything else:
```scala
val currentGen = dispatchGeneration(finish.identify.id)
if (!finish.destruct && finish.generation < currentGen) {
  // stale — drop without touching scheduledActors/runningEvents/advanceToNextTick
  return
}
```
`destruct` events always bypass the check (destruction is terminal and one-way; there's no "newer
dispatch" scenario to protect against). `dispatchGeneration` entries are removed on destruct to
avoid unbounded growth over a long run with many transient actors.

**Why this closes part 2's mechanism precisely**: in the tick-3651 triple-`FinishEvent` example,
all three redundant calls (`requestSignalState`, `Movable.leavingLink`, `BusLinkHandler.
handleLeaveLink`) fire while the actor is still on the *same* generation (say `G`, from the 3651
dispatch) and normally collapse harmlessly into one `scheduledActors` entry. The failure required
one of them (typically the Link's reply — an extra round-trip) to arrive **after** the TM had
already dispatched the actor again (tick 3652, generation `G+1`). That straggler still carries
`generation = G` — by definition **provably stale**, since generation `G+1` could only have been
dispatched if the actor's `G`-cycle was already resolved by one of the other two. The fix requires
no case-by-case reasoning about *which* call site is "the real resolver": any `FinishEvent` whose
generation trails the actor's current one is, by construction, chasing an already-superseded
cycle.

**Note this is a different (complementary) mechanism from part 3's fix.** A stale
`handleBusLoadPeople` reply can arrive *after* the bus's own subsequent `enterLink()` poll has
already bumped `currentGeneration` — meaning by the time the stale reply is processed, it echoes
the *same, current* generation, not an older one (the actor's local `currentGeneration` field
reflects whatever `SpontaneousEvent` it most recently received, which can race ahead of a
still-in-flight reply). So this TM-level generation check, by itself, does **not** catch part 3's
mechanism — the `state.status`-based stale-reply guard added in part 3 is still required for that
case. The two fixes protect against genuinely different failure windows and are both kept.

**Validated**: three independent full 86,400-tick runs with the fixed `randomSeed`, no
`[STALL]`/`[GTM-STALL]` warnings in any of them, 0 same-link duplicate `enter_link`s in every run
(1750, 1752, then a third confirmed 0-duplicate run). 111/111 tests pass.

**However — diffing the exact tick-by-tick event sequences between two of these runs (not just
counts) revealed a separate, much smaller-magnitude divergence that neither this fix nor part 3's
was targeting**, and this one **was** root-caused (2026-07-25, same session).

**Root cause, part 5 (characterized, not fixed): the number of harmless "Waiting" poll cycles
before an async reply lands is itself a real-wall-clock race, not a logical value.**
`Movable.enterLink()` sends `EnterLinkData` then immediately polls
(`onFinishSpontaneous(Some(currentTick+1))`). Until the Link's reply actually arrives,
`state.movableStatus` stays `Waiting`, and every dispatch in between falls through to
`Movable`'s own `case Waiting => waitingTicksCounter += 1; onFinishSpontaneous(Some(currentTick+1))`
— a harmless, side-effect-free re-poll (unlike the `Ready`/`WaitingLoadPassenger` cases fixed in
part 1, calling `enterLink()` again here would be wrong, but this fallback correctly doesn't).
Traced with temporary tick+wall-clock-tagged logging (since removed) across two runs of the same
scenario/seed, isolating just the bus's very first `enterLink()` cycle (tick 3601, the first event
of the whole run):

| Run | Waiting polls before reply | Reply processed at | `enter_link` reported at |
|---|---|---|---|
| 1 | 2 (ticks 3602, 3603) | tick 3603 | tick 3604 (`Moving`) |
| 2 | 4 (ticks 3602–3605) | tick 3605 | tick 3606 (`Moving`) |

Both runs send `EnterLinkData` at the *same* tick (3601) and the Link receives it at the *same*
tick (3601) — genuinely identical up to that point. The divergence is entirely in **how many
logical ticks elapse before the Link's real, cross-actor-mailbox reply happens to be processed** —
i.e. a race between two things that run on different clocks: the "poll again next tick" cycle
(governed by the simulation's own tick-advancement machinery) and the actual Pekko message
round-trip for `EnterLinkData`/`LinkInfoData` (governed by real JVM thread scheduling, GC, and
whatever else the process happens to be doing at that wall-clock moment). Since the real round-trip
has no fixed relationship to the logical tick cycle, a slower JVM moment can let 1-2 extra
"Waiting" polls slip in before the reply wins the race, shifting the tick at which the transition
to `Moving` (and thus the `enter_link` report) is recorded — with no lost or duplicated events,
just a shifted timestamp. This is the exact same architectural pattern documented in part 2
(logical polling racing a real async reply) — the only reason it doesn't *also* duplicate a
registration here is that `Waiting`'s fallback handler is a no-op re-poll rather than a
side-effecting action like `enterLink()`.

**Consistent with all observed symptoms**: explains why the very first `enter_link` of the whole
run already differs (this race exists from the bus's first tick, independent of anything the
leaving-link/load-passenger fixes touch); explains the small, slowly-accumulating, plateauing
magnitude (each of the bus's ~875 `enterLink()`/`leavingLink()` waits across a run independently
has a small chance of landing on a different number of extra polls, ~0.1% aggregate effect, with
no mechanism for it to compound the way genuine duplicate registration did).

**Not fixed this session.** The direct fix — stop polling and rely solely on the Link's reply
(`deferFinishSpontaneous()` instead of the immediate poll) — is *exactly* the change already
attempted twice in part 2 (once for `enterLink`, once for `leavingLink`) and reverted both times
after causing real regressions (worse duplicate rate; an actual stall). There is no reason to
expect a third attempt at removing this specific poll would fare differently without first
addressing why removing it breaks other actors' assumptions (see part 2's `Subway` stale-guard
finding). This is deliberately left as a documented, understood, low-severity characteristic —
worth pursuing only if bit-exact reproducibility (not just "no structurally duplicated events") is
required, e.g. via part 2's suggested TimeManager-level generation check extended to also gate
*when* a `Waiting`-fallback re-poll is allowed to fire, or via a more fundamental redesign of the
`enterLink`/`leavingLink` wait pattern — not a quick fix.

**Ruled out as causes** (still valid from the original investigation):
- Concurrent-vehicle contention (the bus is the only vehicle on its own two links in this
  scenario).
- The known "skip-tick" catch-up mechanism (`Rewinding localTickOffset`/`Processing skipped tick`)
  — zero such log lines appear around any captured duplicate.
- **Ruled out (regression, not a fix): making `EnterLink` itself genuinely consistency-critical.**
  Attempted replacing `Movable.enterLink()`'s immediate `onFinishSpontaneous(Some(currentTick+1))`
  with `deferFinishSpontaneous()`, relying solely on the Link's reply
  (`*LinkHandler.handleEnterLink`) to resolve the spontaneous event. **Verified empirically against
  a full 86,438-tick run: duplicate rate got *worse*, not better** — 137 same-link duplicates vs.
  41 before this specific change, in a denser cluster around tick 9,000-35,000. Reverted in full.
  Given part 2's finding above, the likely explanation is that removing this specific poll shifted
  *relative* timing enough to expose the redundant-`FinishEvent`-bump race more often elsewhere,
  rather than fixing anything — consistent with part 2's diagnosis that this whole family of
  "poll-based" reschedules is inter-dependent and can't safely be changed one call site at a time.
- **Ruled out: duplicate registration across two different `LocalTimeManager` pool routees.**
  Instrumented `LocalTimeManagerBase.registerActor`/`scheduleEvent`/`finishEvent`/
  `sendSpontaneousEvent` (temporarily, since removed) to tag every bus-related event with the
  emitting TM's `self.path.name`. Result: the bus registers once and is dispatched exclusively by
  a single TM instance for the entire run. The pool has multiple `LocalTimeManager` routees
  (`htc.time-manager.max-instances-per-node = 4` locally), so this was a plausible mechanism, but
  it isn't what's happening here.

**Diagnostic method that worked, for whoever continues this**: run the tiny bundled
`simulations/input/sqlite_validation_test/simulation_json_baseline.json` scenario locally via
`sbt "runMain org.interscity.htc.main"` with `HTC_SIMULATION_CONFIG_FILE` and
`HTC_MOBILITY_CITY_MAP_FILE` (the latter isn't read from the scenario JSON's own `cityMapFile`
field — separate env var) pointed at it, with the JSON reporter enabled
(`htc.report-manager.default-strategy = "json"`, `enabled-strategies = ["json"]`,
`htc.report-manager.json.directory` pointed at a scratch dir) so `enter_link`/`leave_link` events
land in plain `.jsonl` files that can be counted with a short Python script (per-link
registration-state tracking — a bus can only be "entered" on one link at a time, so two
`enter_link`s for the *same* `link_id` with no intervening `leave_link` is an unambiguous signal;
naive event-list sorting by `tick` alone is **not** reliable across different links at the same
tick). The whole scenario (86K ticks) runs in under a minute locally. For root-causing the
*mechanism* (not just counting symptoms), add temporary stack-trace-tagged logging directly on
`onFinishSpontaneous`/`deferFinishSpontaneous`/`scheduleEvent` in `SimulationBaseActor` (filtered
to the entity under investigation) — this is what surfaced both part 1 and part 2 above; counting
alone (even per-link duplicate detection) cannot distinguish between the two mechanisms or reveal
new ones.

**Why this matters beyond the bus**: `state.registered`-based density speed
(`SpeedUtil.linkDensitySpeed`) is shared by every MESO `Movable` link handler (`CarLinkHandler`,
`BicycleLinkHandler`, `MotorcycleLinkHandler`) and the "send + poll" pattern is used throughout
`Movable`/`*SignalHandler`/`*LinkHandler` — the same class of run-to-run drift could in principle
have affected any of them, not just `Bus`. Part 4's TM-level generation-counter fix is
**general** — it applies to every actor dispatched through `LocalTimeManagerBase`, not just `Bus`,
so it should close the "redundant-poll-arrives-late-and-gets-bumped" mechanism platform-wide
without needing per-vehicle-type verification the way part 3's targeted guard did. **For the
bus-loop scenario actually tested, three independent full-length runs with the same seed now
produce zero structurally-duplicated `enter_link`/`leave_link` events** (parts 1/3/4 combined).
A separate, much smaller-magnitude (~0.1%) timing drift remains unexplained (see part 4's closing
note) — worth chasing for bit-exact reproducibility, but it is not the duplicate-dispatch class of
bug this investigation was scoped to, and does not threaten result validity the way the original
~1.7% structural-duplicate bug did.

## `scheduleEvent`'s Past-Tick Guard Discards Real Causal Time When Actors Share an LTM Instance (Found 2026-07-30, Fixed 2026-07-30 — Partial Improvement, Residual RMSE Unexplained)

**Different mechanism from the section above — do not assume part 4's generation-counter fix
already covers this.** Part 4 protects `finishEvent` against a *stale* `FinishEvent` from an
actor's own earlier dispatch generation arriving late. This gap is in the sibling guard,
`LocalTimeManagerBase.scheduleEvent` (lines ~103-121), and the request it discards is not stale —
it's the actor's own next legitimate tick, lost because a *different* actor sharing the same
`LocalTimeManager` pool instance advanced the shared `localTickOffset` further in the meantime.
`ScheduleEvent` is a protobuf message (`org.htc.protobuf.core.entity.event.communication.
ScheduleEvent`, no `generation` field in `src/main/protobuf/core/entity/event/communication.
proto`), unlike the plain-Scala `FinishEvent`/`SpontaneousEvent` that part 4's fix touched — so
extending that fix here isn't a drop-in reuse, it needs its own design (see below).

**Found investigating two HTC-vs-SUMO Krauss car-following accuracy artifacts** in
`tools/sumo_validation/` (a new validation harness comparing HTC MICRO-mode output against real
SUMO on hand-authored scenarios — see `tools/sumo_validation/README.md`): a fixed-looking ~10-13
simulated-second startup latency on early vehicles, and a much larger ~106-119 tick stall when a
previously-idle `Link` reactivates mid-run. Root-caused via a live run instrumented with
`-Dpekko.loglevel=DEBUG` (the existing `logDebug` calls in `scheduleEvent` are gated by Pekko's
log level, separate from logback, which is why prior `htc_run.log`s never showed this) — captured
directly:
```
ScheduleEvent tick=63 is at/behind localTickOffset=180; bumping to 181
```
`link_bc` asked to be rescheduled at tick 63 (its own next tick after its idle grace period).
The `LocalTimeManager` instance it shares with other, busier actors (Cars on other links; the LTM
pool is small — `htc.time-manager.max-instances-per-node = 4` locally, confirmed only 4 routees
for a 6-vehicle run) had already advanced `localTickOffset` to 180 servicing those other actors.
The guard at `LocalTimeManagerBase.scala:114-121` can't distinguish "this tick was already
processed and cleared for this specific actor" (the case it was written to protect against, per
its own comment) from "this actor's own request is genuinely earlier than the shared clock only
because unrelated actors on the same LTM instance ran ahead of it" — and bumps both cases the same
way, silently discarding 118 ticks of real causal time for `link_bc` in this example. Matches the
Parquet evidence exactly: nothing recorded for the affected vehicles between tick 70 and 181 in
`tools/sumo_validation/output/scenario_b/htc_parquet/`.

**Corrects an earlier hypothesis for the smaller artifact**: it isn't fixed JVM/Pekko-cluster
warm-up — it's the same registration-time bump (`ScheduleEvent tick=0 is at/behind
localTickOffset=0; bumping to 1` was also captured, for a car's initial registration), whose
magnitude is a genuine real-time race (how far the shared LTM's clock has advanced when the new
actor's registration is processed), which is why repeat runs of the same scenario showed
different-sized offsets for the same vehicles rather than a constant.

**Fixed via the proposed per-actor watermark, plus one keying bug caught during validation.**
Added `highestProcessedTick: mutable.Map[String, Tick]` to `LocalTimeManagerBase`, updated
whenever `sendSpontaneousEvent(tick, identity)` actually dispatches an actor (keyed on
`identity.id`, mirroring `dispatchGeneration`, and cleared on destruct alongside it).
`scheduleEvent`'s guard (`LocalTimeManagerBase.scala:112-136`) now bumps only when
`event.tick <= highestProcessedTick(actorId)` — i.e. only when *this* actor's own dispatch history
says the tick is stale — instead of comparing against the LTM-wide `localTickOffset`. `nextTick`
(`~281-297`) no longer filters `scheduledActors`/`scheduledTicksOnFinish` by `>= localTickOffset`,
since that filter was exactly what hid a legitimately-preserved earlier tick from
`reportGlobalTimeManager`; `processTick`'s pre-existing skip-tick catch-up logic
(`scheduledActors.keys.filter(_ <= tick).minOption`) already knows how to process an entry behind
`localTickOffset` once the GTM re-syncs this LTM to it, confirmed by reading
`LocalDiscreteEventTimeManager.processTick` and `GlobalTimeManager.calculateAndBroadcastNextGlobalTick`
(the latter takes `scheduled.map(_.tick).min` across LTMs, so an earlier-than-`localTickOffset`
report is an expected, supported case, not a foot-gun).

**Keying bug caught by validation, not by review — worth flagging for future changes to this
file.** `ScheduleEvent.actorRef` is *not* a stable actor-id key: `registerActor`
(line ~107) sets it to the entity id, but `SimulationBaseActor.scheduleEvent(tick)`
(`SimulationBaseActor.scala:759-775` — the actual self-reschedule path that produced this gap's
`link_bc` log evidence) sets it to `getPath`, the actor's Pekko path. A first pass keyed
`highestProcessedTick` off `event.actorRef` directly; it compiled and passed all 111 existing
specs, but the guard became a silent no-op for every self-reschedule (write side keys on
`identity.id` in `sendSpontaneousEvent`, read side never matched). Caught only by rerunning
`tools/sumo_validation/run_validation.py` and seeing no RMSE change from the pre-fix baseline.
Fixed by keying on `event.identify.map(_.id).getOrElse(event.actorRef)` instead, matching the key
`sendSpontaneousEvent` writes under.

**Validation performed:**
- `sbt compile` and `sbt test`: clean, all 111 existing specs still pass, both before and after
  the keying fix.
- `tools/sumo_validation/run_validation.py --scenarios a b` (path is `tools/sumo_validation/`, not
  `tools/sumo-validation/`, and the script is `run_validation.py` singular): real, substantial
  improvement on some vehicles, not full closure. Scenario A: `car_0` position RMSE 18.5m → 4.6m
  (now matches the unaffected baseline exactly); max travel-time delta 7s → 3s. Scenario B:
  `car_4` RMSE 75.5m → 6.8m; max travel-time delta 119s → 25s (down ~80%). But `car_1` in scenario
  A (~56-69m across repeated runs) and `car_0`/`car_1`/`car_2` in scenario B (~90-150m) remain
  elevated well above the ~4.6-6.8m baseline, and vary noticeably run-to-run even with the fix
  applied and the same nominal seed — this looks like a **separate, still-open issue**, not
  something this specific guard-plus-`nextTick` change was scoped to fix. Worth a fresh
  investigation rather than folding into this section.
- 86,400-tick reproducibility baseline (`simulations/input/sqlite_validation_test/
  simulation_json_baseline.json`, JSON reporter, method as in parts 4/5 above): ran to completion
  both before and after this fix (max tick observed 86,362 of 86,400 across both runs — the
  simulation itself finishes in under a minute; the `timeout` calls in ad-hoc verification runs
  were catching Pekko's slow *coordinated-shutdown* teardown afterward, not a simulation stall).
  Per-link duplicate-`enter_link`-without-intervening-`leave_link` check: **exactly one duplicate
  in both the pre-fix and post-fix run** (same subway train, different tick/link each run) — i.e.
  this fix neither introduces nor removes duplicate dispatches; the single duplicate is the
  pre-existing ~0.1% residual timing drift already flagged as unexplained in part 4's closing
  note above, not a new regression from this change.

**Remaining open question for whoever picks this up next**: what's causing the still-elevated
RMSE on the specific vehicles listed above. Given the fix here closed the *documented* mechanism
(confirmed by the `car_0`/`car_4` numbers landing exactly on the unaffected-vehicle baseline) but
left other vehicles untouched, the leftover pattern is probably a different bug, not a partial fix
of this one — recommend a fresh instrumented run (same DEBUG-log method used to find this gap)
scoped to `car_1` (scenario A) and `car_0`/`car_1`/`car_2` (scenario B) specifically, rather than
re-opening `scheduleEvent`/`nextTick` again without new evidence pointing there.

**Why this matters beyond these two small scenarios**: LTM pool sharing get more likely, not
less, as scenarios scale up (more actors, same small pool), so this class of lost-causal-time bug
plausibly affects large scenarios (e.g. São Paulo-scale) more than the tiny ones that surfaced it
— just less visibly, since there's no SUMO ground truth to diff against there. The underlying
Krauss car-following math itself was *not* implicated: vehicles unaffected by this scheduling bug
in the same validation runs tracked SUMO closely (~4.6 m position RMSE over a ~300 m trip).

**Update 2026-08-04: found the sibling code path this fix missed, likely explaining the ~0.1%
residual drift referenced throughout this section.** The fix above only patched `scheduleEvent`
(the `ScheduleEvent` message handler, used by `SimulationBaseActor.scheduleEvent(tick)`) to compare
against the actor's own `highestProcessedTick` watermark instead of the shared `localTickOffset`.
`finishEvent`'s own inline handling of `finish.scheduleTick` (`LocalTimeManagerBase.scala`, the
`onFinishSpontaneous(Some(tick))` path — used far more pervasively than `scheduleEvent` itself,
since it's how nearly every actor re-registers after resolving a wait, including e.g. a `Car`'s
`mesoExitTick`) still used `if (tick <= localTickOffset) localTickOffset + 1 else tick` unchanged.
Same mechanism, same silent-mis-scheduling failure mode (not a discard — the actor is still
scheduled, just at a later, physically-incorrect tick — whenever a busier sibling actor on the same
LTM instance has pushed `localTickOffset` past the correctly-computed tick in the meantime), just
on the far more heavily-used code path. Found while designing the congestion-propagation
link-capacity wait (`docs/CONGESTION_PROPAGATION_DESIGN.md`) — that feature creates much longer,
less-bounded dormancy periods than anything previously exercising this path, making the bug both
more likely to trigger and larger in magnitude. Fixed by applying the identical per-actor-watermark
guard to `finishEvent`'s `scheduleTick` handling.

**Re-run against `tools/sumo_validation` 2026-08-05 (three runs each, scenarios A and B), together
with this session's other fixes already landed (the `NodeEventHandler` approach-link fix and the
`Bus`/`Motorcycle`/`Bicycle` velocity-fallback fix above) — partially confirms the fix, but doesn't
fully close the residual gap this note was tracking.** Scenario A (no signal, so this fix and
today's signal fixes are the only variables in play): `car_1`'s RMSE landed at 68.366-68.463m
across two runs, matching the number already on record in the `sumo_validation` correction section
almost exactly — no regression, consistent with expectations. But `car_0`/`car_2` (normally at the
~4.6m unaffected baseline) showed real run-to-run variance in this batch (`car_0` travel-time delta
-6s vs -10s; `car_2` RMSE 4.6m in one run vs 122.987m in another) — this is the same *class* of
residual scheduling nondeterminism already documented in this section and the correction section
below (a wall-clock race in the shared `LocalTimeManager` pool, not a new bug), not something this
specific `finishEvent` fix was scoped to eliminate on its own. Scenario B: `car_2`-`car_5` (the
signal-queued cars) came back **byte-identical across all three runs** (RMSE 50.678/61.595/70.492/
55.941m, every time) — a genuine, reproducible improvement over this section's own original
finding of car-level RMSE varying `run-to-run even with the fix applied`. Max travel-time delta
stayed in an 8-9s band across all three runs, consistent with (not exceeding) the 8-9s already
recorded in the `NodeEventHandler` approach-link fix's own validation above — i.e. this fix and
that one are not fighting each other, and together they hold the signal-gated cars' behavior
stable. **Conclusion: this fix demonstrably closes the residual mis-scheduling for the
signal-queued/deterministic-wait cars it targeted (scenario B's `car_2`-`car_5`), but the separate,
already-documented free-running-car timing race (scenario A/B's `car_0`/`car_1`/`car_2` when not
signal-gated) remains exactly as unresolved as parts 2/4/5 and the correction section already
describe** — not a new finding, just confirmation that this fix didn't accidentally touch it either
way. `sbt test`: 170/170 (unchanged, no Scala edits this session).

## `TrafficSignalPhaseHandler` Never Transitions Past Its First Phase (Found 2026-07-30, Fixed 2026-07-31)

**Root cause: a code bug, not a data/config bug.** The exported traffic-signal JSON (`phases:
[{greenStart: 0, greenDuration: 30}], cycleDuration: 60`) correctly expresses "green for the
first 30s of a 60s cycle" — the same spec SUMO's `.tll.xml` uses, and SUMO cycles correctly on it.
The bug was entirely in `TrafficSignalPhaseHandler.handlePhaseTransition`
(`model/hybrid/support/trafficsignal/TrafficSignalPhaseHandler.scala`): the formula computing when
to next re-evaluate the signal,
`nextCycleStart = ((ticksSinceStart / cycleDuration) + 1) * cycleDuration`, always jumps to the
start of the next **full cycle** (tick 60, 120, ...), never to the phase's own Red-transition
boundary (`greenStart + greenDuration` = tick 30). For a phase with `greenStart = 0`, every one of
those full-cycle landing points is itself inside the Green window (`currentCycleTick = 0`), so the
computed state is Green every single time the actor re-checks — the signal notifies Green once at
tick 0 and then never changes again for the rest of the simulation.

**Found while investigating the residual scenario-B RMSE gap left after the `scheduleEvent`
past-tick-guard fix above.** Instrumented via the JSON reporter (not logs — Pekko's `-D
pekko.loglevel=DEBUG` alone doesn't reach the actual log line; this repo's `logback.xml` pins
`root level="INFO"` and Pekko's `Slf4jLoggingFilter` defers to it, so DEBUG-level `logDebugFn`
calls need a `-Dlogback.configurationFile=...` override, not just the Pekko system property):
across a full 240-tick run of `tools/sumo_validation`'s scenario B (60s signal cycle), exactly
**one** `signal_phase_change` event was ever recorded (Green, tick 0, `next_tick=60`) — no Red
transition, ever. Confirmed further that `NodeEventHandler.handleRequestSignalState`'s only
report()-emitting branch (`state.signals.get(identify.id) => Some(sig)`) was never reached either
— zero `node_signal_requested` events across the whole run — so every car's signal-state query
fell through to the "uncontrolled intersection, assume Green" fallback the entire time. The signal
had **zero** behavioral effect on any vehicle in that scenario, not just a delayed one.

**Not the cause of the ~20-40 tick stalls also observed on `car_0`/`car_3`/`car_4` in scenario B**
(see the section above's validation notes). Since the signal never gated anyone, those stalls are
a separate, still-open bug, most likely in `CarSignalHandler`'s request/retry round-trip
(`Car.scala:280-290`, `MaxSignalStateRetries = 100`) — worth a fresh look, but out of scope for
this fix.

**Fix**: replaced the next-tick formula with one that finds the earliest upcoming transition
boundary (`greenStart` or `greenStart + greenDuration`, for every phase) after the current
cycle-relative tick, wrapping to the next cycle only when a boundary has already passed within
this one:
```scala
val transitionPoints = state.phases.flatMap(p => Seq(p.greenStart, p.greenStart + p.greenDuration))
val nextTickTime = currentTick + transitionPoints.map { point =>
  val delta = point - currentCycleTick
  if (delta > 0) delta else delta + state.cycleDuration
}.min
```
Also simplified `remainingTime`/`nextTick` on `SignalState` to derive from this same corrected
`nextTickTime` (previously computed from the same broken `greenStart + greenDuration -
currentCycleTick` expression, which could go negative once the signal actually reached Red), and
removed a dead `changedOrigins` local (computed, never read). `nextTick` is not report-only — it's
consumed by `Car`/`Bus`/`Motorcycle`/`Bicycle` `SignalHandler`s to compute how long to wait at Red
— confirmed via grep before changing its derivation.

**Validation**:
- Added `TrafficSignalPhaseHandlerSpec` (`src/test/scala/model/hybrid/support/trafficsignal/`) —
  pure handler test, no Pekko, matching this repo's "prefer testing handlers over actors"
  convention. Asserts the exact scenario-B cycle (Green at 0, Red at 30, Green at 60, Red at 90,
  ...) alternates correctly across multiple cycles — the previous code would have failed this
  after the very first transition. 5 new specs, all passing; full suite (116 specs total) green.
- `sbt compile`: clean.
- `tools/sumo_validation/run_validation.py --scenarios a b`: the fix is logically verified correct
  in isolation (unit tests above), but scenario B's end-to-end RMSE did **not** show a clean
  aggregate improvement across two repeated runs (mean RMSE ~74-76m vs. ~65m before this fix; max
  travel-time delta improved on one run, 25s, but not the other, 57s). This is expected, not a
  regression from this change: scenario A (which has **no** traffic signal at all, so this fix
  cannot affect it) shows the same magnitude of run-to-run car-level RMSE swings (e.g. `car_2`
  jumped from its usual ~4.6m to 123m in one of the two runs) — confirming the swings are driven
  by the residual scheduling nondeterminism noted in the section above, compounded now by the
  still-open `CarSignalHandler` stall bug actually mattering more once the signal genuinely cycles
  (cars now really do queue at Red instead of sailing through on the old always-Green bug, so any
  latent race in the queue/retry path is more exposed than before, not less).
- 86,400-tick reproducibility baseline: not re-run — confirmed
  `simulations/input/sqlite_validation_test/` contains zero `TrafficSignal` actors, so this change
  is inert there.

**Update 2026-07-31: found the actual reason the phase-handler fix alone didn't move scenario B's
RMSE — a second, independent bug, this time in the validation harness's *data export*, not engine
code.** `tools/sumo_validation/htc_export/export.py`'s `_node_connections_and_signals` built
`Node.connections` keyed by `TrafficLight.controlled_link_id` directly — which is the SUMO-style
**approach edge** (`link_ab`, the link a car is arriving *on*, matching `.tll.xml`'s own
convention). But `NodeEventHandler.handleRequestSignalState` looks connections up by
`data.targetLinkId`, which `CarSignalHandler.requestSignalState` populates from
`getNextLinkFn()` (`Movable.getNextLink`) — the **outgoing** link a car is about to *enter next*
(`link_bc`). Confirmed via the exported `nodes_0.json`: node `n_b`'s `connections` had exactly one
entry, keyed `"htcaid:link;link_ab"`, which `handleRequestSignalState` could never match against a
query for `link_bc` — every single request across the whole run fell through to the "no connection
entry — uncontrolled intersection, assume Green" fallback, regardless of the (now-correctly-cycling)
signal phase. This is why the phase-handler fix alone produced no behavioral change for scenario
B's cars: the signal was cycling correctly internally, but genuinely disconnected from every car's
decision, both before and after that fix.

Fixed by keying `connections` on each node's *outgoing* link(s) instead (computed the same way the
exporter already computes `incoming_links` for the `Node.links` field, just mirrored on
`from_node`). Updated the one existing test that had encoded the old (wrong) key
(`test_export_htc_scenario_b_wires_traffic_signal_to_node_connection` in
`tools/sumo_validation/tests/test_htc_export.py`) to assert the corrected `link_bc` key instead.
All 22 harness tests pass.

**Result after both fixes (phase-cycling + connection-keying)**: scenario B's mean position RMSE
dropped from ~65-75m to **~25.6-25.8m** (stable across two repeat runs) — cars that now correctly
see and react to Red track SUMO's position closely while actually moving (`car_2`: 51m→7.4m,
`car_4`: 68m→6.8-16.3m). This is the real, load-bearing fix for the signal-gated portion of
scenario B; the earlier phase-handler-only fix was necessary but not sufficient on its own.

**New issue surfaced by this fix, not previously visible (the signal had zero effect before, so
nothing could react to it wrongly): whichever 1-2 cars end up genuinely queued at Red overshoot
their travel time enormously** — `+161` to `+167`s deltas in both repeat runs (vs. SUMO), for
different specific cars each run, despite good *position* RMSE (meaning they track correctly while
moving, then apparently wait far longer than warranted before being released). This is reproducible
in magnitude, not the small run-to-run noise discussed elsewhere in this doc, and is most likely in
`CarSignalHandler.handleSignalState`'s wait-duration calc
(`adjustedNextTick = data.nextTick + queuePosition * headwayTicks`) or in
`NodeEventHandler`'s `signalWaitingCounts` bookkeeping (reset-on-Green logic, keyed by the
connections map this fix just repointed) — not investigated further; flagged here rather than
expanding scope past "fix the signal bug" again.

**[RESOLVED 2026-08-05] Root-caused, not in `CarSignalHandler`/`signalWaitingCounts` as guessed
above — see "`NodeEventHandler` Notified the Wrong Link on Signal Phase Change" further down this
file.** The queue-position/headway math and the waiting-count bookkeeping were both fine; the real
cause was `handleReceiveSignalChangeStatus` broadcasting `LinkSignalStateData` to the OUTGOING link
instead of the APPROACH link, planting a virtual red-light leader on the wrong (downstream,
already-passed) link and braking vehicles that had nothing to do with that signal. Max travel-time
delta dropped from `+161-167s` to `8-9s` after the fix.

## `sumo_validation` Scenario A `car_1` RMSE Anomaly: Root-Caused to Part 5's `enterLink()`-Poll Race, Plus One New, Now-Fixed `CarMicroHandler` Bug (Found/Fixed 2026-07-31, Corrected 2026-08-01)

**Path correction first**: despite every reference in this doc reading `tools/sumo_validation/`,
the harness actually lives at `<htc-platform>/tools/sumo_validation/` — a **sibling** of this repo
(`hyperbolic-time-chamber/`), not a subdirectory of it. `hyperbolic-time-chamber/tools/` does not
exist. Run it from the platform root, one level up from this repo.

**Found and fixed first: the harness's own SUMO runner had a real, silent bug making every prior
`run_validation.py` invocation compare HTC against a stale SUMO trace.**
`runners/sumo_runner.py`'s `run_sumo` sets `cwd=sumocfg.parent` but then also passes the *same*
(possibly repo-root-relative) `sumocfg` path as the `-c` argument — SUMO looks for
`output/scenario_a/sumo/scenario.sumocfg` *inside* `output/scenario_a/sumo/`, doubly nested, which
never exists, so `sumo` exits 1 with `Error: Could not access configuration ...` every single run.
`run_validation.py` only logs this as a `WARNING` and continues, silently reusing whatever
`scenario_fcd.xml` happened to already be on disk (a 2026-07-30 file, confirmed by its mtime) as if
it were fresh ground truth. Every metrics run between 2026-07-30 and this fix was unknowingly
diffing HTC's (evolving, being-fixed) output against a frozen, un-refreshed SUMO baseline. Fixed by
passing `sumocfg.name` (the bare filename) instead of the full path, since `cwd` is already the
config's own directory. Added `tests/test_sumo_runner.py` (previously zero coverage for this
module) — one regression test reproducing the exact double-resolution failure via a fake `sumo`
executable that only succeeds on a bare filename, one sanity check that genuine failures are still
surfaced. Harness test count: 22 -> 24, all passing.

**The primary chase-down**: `car_1` in scenario A (~56-69m position RMSE vs. the ~4.6m baseline
every other unaffected car in both scenarios consistently hits) has **no traffic signal in its
scenario at all**, ruling out every already-documented signal-related mechanism above. Root-caused
by comparing `journey_started` (the tick a car's trip logically begins) against `enter_micro_link`
(the tick it actually starts moving) per car, across three independent runs, read directly from
the harness's own Parquet output — not assumed:

```
Run 1: car_0 journey_started=0  enter_micro_link=6   car_1 journey_started=6  enter_micro_link=6
Run 2: car_0 journey_started=0  enter_micro_link=13  car_1 journey_started=6  enter_micro_link=13  car_2 journey_started=12 enter_micro_link=13
Run 3: car_0 journey_started=0  enter_micro_link=10  car_1 journey_started=6  enter_micro_link=11
```

This is **the same mechanism as the "`scheduleEvent`'s Past-Tick Guard..." section above, still
not fully closed for an actor's very first dispatch** despite that section's 2026-07-30 fix: each
car's actual first micro-link entry lags its own `journey_started` tick by a real-time-race-sized
delay (6, 7, 10, and 13 ticks observed for `car_0` across different runs — not a fixed constant,
which is itself consistent with a wall-clock race in the shared `LocalTimeManager` pool, not a
deterministic logic bug). Scenario A's four cars are meant to depart 6 seconds apart specifically
to exercise Krauss gap-closing (see `tools/sumo_validation/README.md`'s scenario description) — but
when two cars' independent entry delays happen to land within 0-2 ticks of each other (as they did
in all three runs above), the follower's actual starting gap to its leader collapses from the
intended "6 seconds of free-flow travel" (tens of meters) to almost nothing, forcing genuine (given
the corrupted input, *correct*) Krauss emergency braking and a slow multi-tick recovery that
dominates that car's own position RMSE for the rest of its trip. Whichever car in a given run
*doesn't* get caught in a same-tick pile-up lands at exactly the same ~4.6m baseline as every other
unaffected car — confirming the Krauss car-following math itself is not implicated, only the timing
of when cars are handed their first real tick.

**Explicitly ruled out** (with direct evidence, not assumption):
- **Harness car-id mapping bug**: `journey_started` ticks tie out exactly to each car's configured
  `depart_tick` (`scenario/scenario_a.py`: `car_i` departs at `i * 6`) on both the HTC and SUMO
  sides — car identities are not being crossed or misaligned between the two parsers.
- **Leader/follower index bug in `DefaultMicroSimulationStrategy.processMicroLane`**: read the
  code directly (`model/hybrid/micro/strategy/DefaultMicroSimulationStrategy.scala:149-151`) — a
  vehicle's leader is `vehicles(i-1)` from a `Queue` that is re-sorted by descending position after
  *every* sub-tick (`vehicles.sortBy(v => -v.position)`, line 227-231), so the leader assignment is
  always positionally correct regardless of vehicle-ID order. Confirmed empirically too: in every
  run, whichever car is physically ahead is the one setting the pace, never the reverse.
- ~~**The residual ~0.1% `Waiting`-poll timing drift documented in part 5 above**: that mechanism
  produces rare (one-per-86,400-tick-run) duplicate dispatches later in a simulation, not a
  registration-time-only delay of 6-13 ticks affecting a car's very first dispatch. Different
  trigger, different magnitude, different point in the actor's lifecycle.~~ **Corrected
  2026-08-01 — this bullet was wrong; see the "Correction" subsection immediately below.** Part 5's
  *mechanism* (poll-vs-async-reply race) is exactly what produces this gap; only part 5's own
  *worked example* (2-4 polls, mid-run bus) had smaller magnitude than car_1's 6-13 polls, which is
  a difference in degree (four cars registering into one Link actor's mailbox in a tight window vs.
  a single bus with no contention), not a difference in mechanism or in which point of an actor's
  lifecycle it can strike.

### Correction (2026-08-01): the "still-open" framing above was wrong — this *is* part 5's mechanism, not a separate one

Re-investigated per a direct instruction to verify the "ruled out" bullet above with live
instrumentation rather than the static trace this section originally relied on. Added temporary
`Console.err` tick+`System.nanoTime()` tracing (same method as parts 1/2/5's own investigations,
since removed) at four points: `Movable.actSpontaneous`'s entry (status), `Movable.enterLink()`'s
`EnterLinkData` send, the `Waiting`-case re-poll, and `CarMicroHandler.handleMicroEnterLink` (where
`enter_micro_link` is actually reported). Ran `tools/sumo_validation`'s scenario A twice with this
build.

**Direct, unambiguous result — the entire `journey_started`-to-`enter_micro_link` gap is made of
`Waiting`-case re-polls, one per tick, with no other event in between:**

```
Run 2 (13-tick gap on car_0, the largest observed):
tick=0  car_0 ENTERLINK-SEND (journey_started)   status set to Waiting
tick=1..12  car_0 WAITPOLL (waitingTicksCounter 0..11)   -- 12 consecutive re-polls, one per tick
tick=13 car_0 MICROENTER (enter_micro_link reported)

Same run, car_1 (departs tick=6, a 7-tick gap):
tick=6  car_1 ENTERLINK-SEND      tick=7..12  car_1 WAITPOLL (counter 0..5)      tick=13 car_1 MICROENTER
```

Car_0's real entry (delayed 0->13 by its own poll race) and car_1's real entry (delayed 6->13 by
its *independent* poll race) land on the **exact same tick**, collapsing their intended 6-tick
departure gap to zero and forcing the Krauss emergency-braking recovery that dominates car_1's RMSE
(68.5m vs. the ~4.6m baseline) in that run. Car_2 (entering at tick 14, one tick behind car_1's 13)
picked up an elevated RMSE too (20.5m) in this same run for the identical reason, one tick less
severe. Car_3, whose poll race happened to finish with zero extra ticks (SEND and MICROENTER both
at tick 18, no contention left in the mailbox by then), landed exactly on the unaffected baseline.
A second run showed the same pattern with different magnitudes (car_0: 0->8, 8 ticks; car_1: 6->8,
2 ticks — same-tick collision again, same RMSE profile) — confirming, as part 5's own bus example
already found, that the number of extra `Waiting` polls before the async reply lands is a real
wall-clock race, not a fixed constant.

Also confirmed why no `TRACE-ENTERLINK-REPLY` (`Car.actHandleReceiveEnterLinkInfo`, the MESO
`ReceiveEnterLinkInfo` path part 5's own bus example used) ever fired in either run:
`LinkVehicleFlowHandler.handleEnterLinkMicro` (not `handleEnterLinkMeso`) answers `EnterLinkData`
for a MICRO-mode link like scenario A's, replying with `MicroEnterLinkData` directly instead of
`LinkInfoData`. Same race, same `Movable.enterLink()`/`Waiting` poll pattern — just resolved via a
different reply message on the MICRO branch than the MESO branch part 5 happened to trace.

**What this means for the "explicitly ruled out" bullet above and the "Status" note below**: they
were wrong. This is not a "registration/first-dispatch" mechanism distinct from part 5 — it is
part 5's poll-vs-async-reply race, observed for the first time at an actor's *very first*
`actSpontaneous` dispatch (which this investigation confirms fires exactly on the actor's own
`depart_tick`/`startTick`, with no additional delay *before* the first dispatch — `TRACE-ENTRY`
for `car_0` landed at tick 0 precisely). Scenario A's four cars registering into the same `Link`
actor's mailbox within a 0-18-tick window is what amplifies the race's magnitude (6-13 polls
observed here vs. part 5's 2-4) and, combined with this harness's Krauss gap-closing scenario being
sensitive to timing in a way part 5's duplicate-dispatch-counting validation never checked, is what
makes the resulting position error large and visible for the first time.

**Consistent with, not contradicting, the "`scheduleEvent`'s Past-Tick Guard..." section's own
2026-07-30 fix and its "remaining open question."** That fix targets a different guard
(`scheduleEvent`'s `localTickOffset` comparison) protecting against a different failure (an
actor's own legitimate next-tick request getting bumped forward because unrelated actors on the
same LTM advanced the shared clock first) — real, and correctly fixed, but not what's producing
*this* gap. This gap is entirely on the `enterLink()`/`Waiting`-poll side, which that fix never
touched.

**No code change made here — per the standing guidance in part 5 and part 2 above, do not attempt
to remove `Movable.enterLink()`'s poll a third time.** Both prior attempts (see part 2: `Subway`
stall; part 5: 137 vs. 41 duplicates, worse not better) are unrelated to *this* scenario but prove
the same architectural point: every reply handler in this family assumes a fallback poll exists
elsewhere, and removing one poll site in isolation has repeatedly caused regressions rather than
fixes. No new evidence surfaced during this investigation that changes that risk assessment — the
TimeManager-level "recognize a stale `Waiting`-fallback re-poll" approach part 5 sketches (extending
the existing `dispatchGeneration`/`highestProcessedTick` watermark machinery to also gate *when* a
`Waiting` re-poll is allowed to fire, not just whether a `FinishEvent`/`ScheduleEvent` is stale) is
still the only avenue that doesn't require touching every interacting reply handler at once, and
remains unimplemented, deliberately, for the same reason part 5 left it that way: it needs its own
dedicated investigation and full 86,400-tick reproducibility validation, not a delta landed
alongside a documentation correction.

**Validation for this correction**: `sbt compile` clean; `sbt test` — 119/119 specs pass (all
pre-existing, no new specs added — this session made no production code change, only temporary
instrumentation, added and fully reverted). All four instrumentation call sites confirmed removed
(`git diff` against `HEAD` for `Movable.scala`/`Car.scala`/`CarMicroHandler.scala` is empty).
`tools/sumo_validation/run_validation.py --scenarios a b` re-run against the freshly rebuilt,
instrumentation-free jar to confirm no behavioral change from the trace-and-revert cycle: scenario
A car_1 RMSE 68.463m, scenario B unaffected — both consistent with the numbers already on record
in this doc, confirming the instrumentation left no residue.

**Independent, real, now-fixed bug found along the way — contributes to, but does not by itself
explain, the anomaly's full magnitude.** `CarMicroHandler.handleMicroEnterLink`
(`model/hybrid/support/car/CarMicroHandler.scala`) computed a car's initial MICRO-mode velocity as
`state.microState.map(_.velocity).getOrElse(speedLimitMs * 0.8)`. The `.map` branch can **never**
actually fire: `handleMicroLeaveLink` always calls `state.deactivateMicroMode()` (clearing
`microState` to `None`) on link exit, before the next `handleMicroEnterLink` runs — so every single
micro-link entry, first-ever or chained, fell into the `getOrElse` fallback and started the car
cruising at a flat 80% of the link's speed limit (40 km/h on a 50 km/h link), regardless of whether
it had genuinely never moved before (SUMO's default `departSpeed=0` — cars there visibly accelerate
from a dead stop) or had just been cruising at the end of a previous chained micro-link (e.g.
scenario B's `link_ab` -> `link_bc`), whose real exit velocity was silently discarded every time.
Fixed by reading `journeyReporter.sumoArrivalSpeed` instead — it is `0.0` by construction until a
car's first `handleMicroLeaveLink` ever fires, then holds the real exit velocity from then on
(already being written correctly by both `handleMicroUpdate` and `handleMicroLeaveLink`, just never
read back on the next entry). **[RESOLVED 2026-08-05]** Same dead-fallback pattern found in
`BusMicroHandler.scala:51` (`speedLimitMs * 0.7`) and, more crudely, hardcoded unconditionally with
no `state.microState` check at all in `MotorcycleMicroHandler.scala:45` and `BicycleMicroHandler`'s
equivalent (flat `5.0` m/s) — see "`Bus`/`Motorcycle`/`Bicycle` Micro Handlers Had the Same
Dead-Fallback-Velocity Bug as `CarMicroHandler`" further down this file for the fix.

**Why fixing this alone did not close the `car_1` gap**: with initial velocity now correctly `0.0`
for a car's first-ever movement, two cars still entering the same link within 1-2 ticks of each
other (per the still-open scheduling delay above) now both depart from a dead stop instead of
already cruising at 11.1 m/s — this changes the specific shape of the resulting Krauss interaction
but does not remove the near-zero-gap collision itself. Re-running the harness after this fix
(Run 3's numbers above) still shows `car_1` at 68.7m RMSE, materially unchanged from before the
fix (66.7m) — exactly as this analysis predicts, since the dominant cause (entry-timing collision)
is untouched by a velocity-default fix.

**Validation**:
- `sbt compile` and `sbt test`: clean. Added `CarMicroHandlerSpec`
  (`src/test/scala/model/hybrid/support/car/`) — 3 new specs, no Pekko (pure handler test, per
  this repo's convention): a car's first-ever micro link departs at rest (0 m/s); a second,
  chained micro link resumes at the car's real carried-over exit velocity, not a flat fraction of
  speed limit; the reported `initial_velocity` event field matches what's actually stored. Full
  suite: 119 specs (116 pre-existing + 3 new), all green.
- `tools/sumo_validation` end-to-end, both before and after the `CarMicroHandler` fix (with the
  `sumo_runner.py` fix already applied so both comparisons are against genuinely fresh SUMO
  ground truth): scenario A `car_1` RMSE 66.7m -> 68.7m (no material change, as predicted above).
  Scenario B did show real improvement on some vehicles from this fix alone — `car_2` 52.2m ->
  4.3m, `car_4` 74.4m -> 6.8m — consistent with the fix's actual mechanism (chained-link velocity
  carryover matters most on scenario B's two-link `link_ab` -> `link_bc` route). Scenario B's
  travel-time deltas got *larger* for the cars genuinely queued at Red (up to +203s, vs. the
  already-documented +161-167s in the section above) — consistent with, and not a new instance of,
  the already-flagged, explicitly-out-of-scope "cars queued at Red overshoot their travel time"
  issue: correcting the departure-speed bug means more cars now *genuinely* reach and queue at the
  signal (instead of sailing past mid-cruise), so that pre-existing bug's effect is more exposed,
  not newly introduced.
- 86,400-tick reproducibility baseline: not re-run for this fix — it only changes which value is
  used as a micro-link's initial velocity (a value that, per the dead-code analysis above, could
  never previously be reached any other way), with no change to control flow, tick scheduling, or
  message ordering, so it cannot affect the duplicate-dispatch/reproducibility concerns tracked
  elsewhere in this doc.

**Status (corrected 2026-08-01 — see the "Correction" subsection above for the instrumented
evidence)**: root cause identified and confirmed. It is **not** a distinct registration/first-
dispatch mechanism, and it is **not** the `scheduleEvent`-past-tick-guard mechanism from the section
above (that guard was checked and correctly fixed on 2026-07-30, but protects a different code
path). It is part 5's already-documented `Movable.enterLink()`-send-then-poll race
(`onFinishSpontaneous(Some(currentTick+1))` racing the real, cross-actor-mailbox `EnterLinkData`/
`MicroEnterLinkData` round-trip), now observed to also strike an actor's very first dispatch and,
in this harness's multi-car-into-one-Link-mailbox scenario, to reach 6-13 polls instead of part 5's
2-4 — large enough to collapse two cars' intended 6-tick departure gap to zero and trigger the
Krauss emergency-braking recovery that produces the elevated RMSE. **Not independently re-fixed
here, deliberately**, for the same reason part 5 itself was left unfixed: the direct fix (stop
polling, rely solely on the reply) has been attempted and reverted twice already (part 2: caused a
`Subway` stall; part 5: made duplicate dispatch rates worse, 137 vs. 41), and there's no new
evidence from this investigation suggesting a third attempt would fare differently without first
either auditing every interacting reply handler system-wide or implementing the TimeManager-level
stale-repoll-detection part 5 sketches (extending the existing `dispatchGeneration`/
`highestProcessedTick` watermarks to gate *when* a `Waiting`-fallback re-poll may fire). What **is**
fixed in this section — the harness's silently-stale SUMO ground truth, and the `CarMicroHandler`
velocity-carryover/rest-start bug — are both real and independently worth having, but neither is
sufficient alone to close this specific RMSE gap, and no further code fix is safe to land without
the dedicated scheduler-level investigation part 5 and this correction both point at. Whoever picks
up that scheduling fix next has a harness that can immediately, correctly confirm it:
`tools/sumo_validation/run_validation.py --scenarios a b` from the platform root — watch `car_1`
(scenario A) and any car whose `MICROENTER`/`enter_link` tick collides with another car's within
1-2 ticks (scenario B).

## `deferFinishSpontaneous()` Holds an Entire LTM Batch Open for the Duration of an Unbounded Async Wait (Found 2026-08-04, Fixed 2026-08-05 — All Known Call Sites, Two Different Fix Shapes)

**Found while designing congestion-propagation/spillback work** (a car waiting at a `Node` for
downstream link capacity, discussed but not yet built), specifically while answering "does the
TimeManager actually guarantee this waiting car gets woken up, and does anything else stall in the
meantime?"

`deferFinishSpontaneous()` (`SimulationBaseActor.scala:720-721`, pre-existing —
`git blame` attributes it to commit `c03d70d`, 2026-06-10, "chore: refactoring hybrid actors", not
introduced by this investigation) suppresses the "did you forget to call `onFinishSpontaneous`"
safety net in `handleSpontaneous` **without sending any `FinishEvent`**. That safety net exists so
`actSpontaneous` never returns without resolving; `deferFinishSpontaneous()` is the sanctioned way
to say "I'll resolve later, from an interaction event, not right now."

The problem: `LocalTimeManagerBase`/`LocalDiscreteEventTimeManager` dispatch one **batch** of
`SpontaneousEvent`s per tick (`sendSpontaneousEvent`, adding every dispatched actor to
`runningEvents`), and **do not advance to the next tick until `runningEvents` is empty** —
`LocalDiscreteEventTimeManager.processTick`'s own doc comment: *"Time only advances when all
events at the current time have been processed."* `runningEvents` is only cleared by an actual
`FinishEvent` (`finishEvent`, `runningEvents.filterInPlace(...)`), regardless of `scheduleTick`.
`deferFinishSpontaneous()` sends no `FinishEvent` — so **every other actor scheduled in the same
batch on the same `LocalTimeManager` pool instance is blocked from its own next-tick dispatch**
until whatever this one actor is waiting on resolves and it finally calls the real
`onFinishSpontaneous(...)`.

**This is not a deadlock** (the wait does resolve — the counterpart always eventually replies in
every usage found so far) **but it is a real stall**, proportional to however long the async
operation takes, applied to every co-scheduled actor on that LTM instance, not just the waiting
one. Under load (busy shard, actor mailbox contention, slow dynamic-actor spin-up) this is
plausibly a contributor to the class of multi-tick stalls already documented in this file (the
past-tick-guard section above; the 10-13s startup latency and 106-119 tick idle-`Link`-reactivation
stall in the enterLink()-poll-race section) — not confirmed as the root cause of any specific one
of those, but the same shape of problem, and worth keeping in mind when chasing them.

**Already fixed**: the signal-wait exchange in `Car`/`Bus`/`Bicycle`/`Motorcycle`'s
`*SignalHandler.requestSignalState`/`handleSignalState` (this fix's own git history:
`deferFinishSpontaneous` was added there, found to hold the batch open, and replaced with the
pattern the project already used correctly for `Person`'s `StartTrip → Car` handoff — see
`LocalTimeManagerBase.scheduleEvent`'s `wasIdle` re-notification comment). The car now genuinely
deregisters (`onFinishSpontaneous(None)`, a real `FinishEvent`, clears `runningEvents`
immediately) when it sends `RequestSignalStateData`, and re-registers via `scheduleEvent(tick)`
(not `onFinishSpontaneous`) once the `Node`'s reply lands — `scheduleEvent` is required here, not
optional, because `finishEvent`'s own `scheduleTick`-add path has **no** `wasIdle`/Global-TM
re-notification logic; calling `onFinishSpontaneous(Some(tick))` a second time from an
already-fully-resolved context would silently add to `scheduledActors` without telling the Global
TM there's new work, risking premature simulation termination if this was the last scheduled item
on this LTM.

**2026-08-05: `BusStopHandler`'s two call sites fixed with the identical disengage-then-
`scheduleEvent` pattern. The other three (`BusStation`/`SubwayStation`, waiting on dynamic-actor-
spawn acks) were also converted the same way, then reverted after live validation showed the
conversion breaks the simulation.**

- **Fixed: `BusStopHandler.requestLoadPassenger`/`requestUnloadPeopleData`**
  (`BusStopHandler.scala`): both now call `onFinishSpontaneousFn(None)` (a real, immediate
  `FinishEvent`) right after sending the request instead of `deferFinishSpontaneousFn()`.
  `handleBusLoadPeople` and `handleUnloadPassenger` — the reply handlers that used to call
  `onFinishSpontaneousFn(Some(tick))` directly — now call a new `scheduleEventFn: Tick => Unit`
  lambda instead (wired to `scheduleEvent(tick)` in `Bus.scala`), for the same reason
  `CarSignalHandler.handleLinkAccess` already had to: a second `onFinishSpontaneous(Some(tick))`
  call from an already-disengaged actor silently adds to `scheduledActors` without re-notifying the
  Global TM. The `deferFinishSpontaneousFn` constructor parameter was removed from `BusStopHandler`
  entirely. This one is safe because both replies come from a single message round trip between two
  already-live actors (`Bus` ↔ `BusStop`/boarded `Person`s) — the same shape as the already-proven
  signal-wait fix.

- **Attempted, then reverted: `BusStation.actSpontaneous`'s `Working` case,
  `BusStation.dispatchFirstBus`'s two call sites, and `SubwayStation.scheduleNextTick`** (4 call
  sites). These defer while waiting for `onDynamicActorInitialized` — the callback fired after the
  full `ShardRegion.StartEntity → StartEntityAck → InitializeEvent → InitializeEntityAckEvent`
  dynamic-actor-spawn protocol completes for a newly-created `Bus`/`Subway`, a much longer,
  multi-hop async chain than a single request/reply message. Converting these to
  `onFinishSpontaneous(None)` + `scheduleEvent(tick)` in `onDynamicActorInitialized` (mirroring the
  `BusStopHandler` fix exactly) compiled clean and passed all 159 specs, but **broke the actual
  simulation**: run against the full 86,400-tick baseline
  (`simulations/input/sqlite_validation_test/simulation_json_baseline.json`), the simulation
  terminated after **0 ticks** — `GlobalTimeManager` log: `"No scheduled events: broadcasting
  QueryNextTickEvent grace-period probe to all LTMs"` immediately followed by `"No more scheduled
  events across local time managers. Terminating simulation"`. Root cause: `BusStation`/
  `SubwayStation` are dispatched very early (tick 0) in this scenario, and once they genuinely
  disengage, **nothing else is scheduled anywhere** until the newly-spawned `Bus`/`Subway` finishes
  its multi-hop registration — but the Global TM's "no scheduled events, terminate" grace period
  (a single `QueryNextTickEvent` probe, sized for a single in-flight message like
  `Car.handleStartTrip`, per its own code comment in `GlobalTimeManager.scala:70-73`) fires and wins
  the race before that registration completes, permanently ending the simulation. Confirmed this
  was a genuine regression, not a pre-existing bug: stashed the fix, rebuilt, reran the identical
  scenario — pre-fix reached 197,441 ticks cleanly. Reverted all 4 call sites back to
  `deferFinishSpontaneous()`/`onFinishSpontaneous(tick)` (verified `git diff` against `HEAD` for
  both files is empty after reverting). Re-ran with only the `BusStopHandler` fix applied: two
  independent full runs reached 195,044 and 198,129 ticks respectively, confirming the revert
  restored correct behavior and isolating the `BusStopHandler` fix as safe on its own.

**Why the signal-wait fix and `BusStopHandler` fix don't have this problem**: in both cases, the
thing being waited on (`Node`, `BusStop`/boarded `Person`s) is an *already-registered, already-live*
actor answering one message — fast enough that the Global TM's existing one-shot grace period
reliably catches the in-flight reply. Dynamic actor *creation* is categorically slower (cluster
sharding round trip, not a single message hop), so it needed a different fix shape, not a copy of
this one.

**2026-08-05, later the same day: `BusStation`/`SubwayStation` fixed too, with a bounded-poll
shape instead of full disengage.** Per the "still open" note above, the safe option that doesn't
touch shared `GlobalTimeManager`/`LocalTimeManagerBase` code is: stay *genuinely registered*
(never fully disengage) for the duration of the dynamic-actor-spawn wait, by scheduling a real,
immediate `FinishEvent` with a short `scheduleTick` (1 tick out) instead of either
`deferFinishSpontaneous()` (holds the batch open) or `onFinishSpontaneous(None)` (fully disengages,
races the GTM's grace period). This resolves each individual tick's `FinishEvent` right away — so
it never holds the LTM batch open — while the station stays in `scheduledActors` throughout, so the
LTM is never reported idle to the Global TM and the 0-tick termination race cannot occur.

Implementation (`BusStation.scala`, `SubwayStation.scala`):
- **`BusStation`**: new `awaitingDynamicInit: Boolean` actor-local var and
  `dynamicInitPollIntervalTicks: Tick = 1L` constant. All three `deferFinishSpontaneous()` call
  sites (the `Working` case, and `dispatchFirstBus`'s two create-bus branches) now set
  `awaitingDynamicInit = true` and call `onFinishSpontaneous(Some(currentTick + 1))` instead.
  `onDynamicActorInitialized` just flips the flag back to `false` — it does **not** call
  `onFinishSpontaneous`/`scheduleEvent` itself, since the station is never disengaged and doesn't
  need re-registering. `actSpontaneous` gained two guards at the top, checked before the existing
  `state.status match`: if `awaitingDynamicInit`, re-poll at `currentTick + 1`; else if
  `pendingSpawnTick` (the precomputed "create the *next* bus at this tick" target, unchanged from
  the original design) is still in the future, jump straight there in one dispatch — so once the
  ack lands, the station goes back to the same single-scheduled-event performance profile as
  before, only paying the extra bounded polls during the brief ack-wait window itself.
- **`SubwayStation`**: same shape, but reusing the existing `pendingSubwayAckCount` (already a
  fan-out counter, one per spawned `Subway`) as the guard condition directly instead of adding a
  separate boolean — `actSpontaneous` polls at `currentTick + 1` while `pendingSubwayAckCount > 0`,
  then jumps to `pendingSubwayNextTick` once it reaches 0 (also unchanged from the original
  design). `onDynamicActorInitialized` only decrements the counter, no resolve call.

**Why this is safe where the full-disengage attempt wasn't**: the station's `Identify` never leaves
`scheduledActors` during the wait — every poll tick re-adds it for the very next tick before the
current one's `FinishEvent` is even sent, so `LocalTimeManagerBase.hasSchedule` (and therefore the
Global TM's `scheduled.isEmpty` check) never sees this LTM as idle on account of this actor,
regardless of how long the underlying spawn protocol actually takes. There is no dependency on the
Global TM's one-shot grace period at all for this wait, unlike the reverted full-disengage version.

**Validation**: `sbt compile` clean; `sbt test` — 159/159 specs pass (all pre-existing). Full
86,400-tick baseline scenario (method per the diagnostic section elsewhere in this doc, JSON
reporter, `batch-size=1` for guaranteed per-event flush) run twice with the complete fix (all 7
`deferFinishSpontaneous()` sites converted — `BusStopHandler`'s two plus these five): run 1 reached
198,085 ticks with 0/2048 duplicate `enter_link`s; run 2 reached 199,263 ticks with 0/2436
duplicates. Both `bus_created`/`subway_created` counts matched the pre-fix baseline exactly (2 and
2), confirming dynamic actor creation itself is unaffected — only the TimeManager registration
shape around the wait changed.

**[RESOLVED 2026-08-05]** Added `LocalTimeManagerBatchStallSpec`
(`src/test/scala/core/actor/manager/time/`), exercising `LocalDiscreteEventTimeManager`'s real
`runningEvents`/`scheduledActors` bookkeeping directly on `underlyingActor` (same pattern
`PrivateVehicleMigrationSnapshotSpec` uses for a `PersistentActor` under test — protected methods
called directly, bypassing the mailbox for the outer call while still routing through the actor's
real `handleEvent` for messages that need it, e.g. `UpdateGlobalTimeEvent` to trigger dispatch).
`TestProbe`s stand in for the "actors" (`PoolDistributed`/`actorSelection`-addressed, matching
`sendSpontaneousEventPool`, so no cluster sharding is needed — `pekko.actor.provider = local`
throughout). Two specs:
1. A co-scheduled sibling actor's own next tick becomes reachable (`runningEvents` clears,
   `reportGlobalTimeManager(hasScheduled = true)` reaches the parent) once a genuinely-disengaged
   actor sends its `FinishEvent(scheduleTick = None)` — the fixed pattern.
2. A fully-disengaged actor (idle LTM, `reportGlobalTimeManager(hasScheduled = false)` reaches the
   parent) can be re-woken later via a fresh `ScheduleEvent`, and the LTM's `wasIdle`
   re-notification correctly reaches the parent — the exact protocol `BusStation`/`SubwayStation`
   depend on after a dynamic-actor-spawn ack, whose absence would reproduce the 0-tick termination
   race this section's first (reverted) fix attempt hit.

**Verified the test actually catches the regression, not just passes vacuously**: temporarily
removed spec 1's genuine-disengage `FinishEvent` call (simulating `deferFinishSpontaneous()`'s
"send nothing at all") and re-ran — failed exactly as expected
(`Set("actor-a") was not empty`, i.e. the batch stayed held open), confirmed via `git diff`-clean
revert back to the real assertions afterward. `sbt test`: 172/172 (170 pre-existing + 2 new).

## `NodeEventHandler` Notified the Wrong Link on Signal Phase Change — Root Cause of the "+161-203s Signal-Wait Overshoot" (Found/Fixed 2026-08-05)

**Follows up directly on the "cars queued at Red overshoot their travel time" note left open in
the `TrafficSignalPhaseHandler`/connection-keying section above.** That section's 2026-07-31
connections-keying fix (approach-edge key -> outgoing-edge key) correctly fixed
`NodeEventHandler.handleRequestLinkAccess`'s lookup, closing the "signal always assumed Green"
bug and getting `CarSignalHandler`'s queue-position/headway wait mechanism working — but it broke
a second, unrelated consumer of the same `connections` map that needed the opposite keying, and
that's what was still producing the residual multi-hundred-second overshoot.

**Root cause**: `NodeEventHandler.handleReceiveSignalChangeStatus` computed `linksForThisPhase`
from `state.connections` — the same map `handleRequestLinkAccess` uses, keyed by the OUTGOING
link (the link a car is about to enter next, e.g. `link_bc` for a car approaching node `n_b` on
`link_ab`) since the 2026-07-31 fix. It then sent `LinkSignalStateData` (the message that sets
`Link.signalAtExit`, consumed by `DefaultMicroSimulationStrategy` to plant a virtual
zero-velocity leader at `position = linkLength`, causing IDM/Krauss to smoothly brake a vehicle
approaching *that link's own end*) to whichever Link actor owns that outgoing link. For scenario
B's intersection, this meant every Red/Green phase change was broadcast to `link_bc` — the link
*leaving* the signalized node — not `link_ab`, the link a car is actually traveling on as it
approaches the signal. A vehicle already past the intersection and mid-transit on `link_bc`
(no signal of its own) would suddenly find a virtual stopped vehicle planted at `link_bc`'s far
end whenever the (irrelevant, already-passed) upstream signal turned Red, decelerating to a near
stop and only resuming once that signal cycled back to Green — completely disconnected from its
own actual progress. Confirmed directly via Parquet trace: `car_1` (scenario B) entered `link_bc`
at tick 29 (already cleared the signal on Green), then decelerated from 13.9 m/s toward ~0 exactly
across ticks 30-60 (the node's Red window) before snapping back to speed at tick 61 (the next
Green), losing 34 ticks on a 100 m link that should take ~8s free-flow — the same tick-for-tick
alignment with the signal's Red window is what the original `+161-167s` finding's cars were
independently exhibiting, just not previously root-caused past "somewhere in `CarSignalHandler`
or `NodeEventHandler`'s bookkeeping" (see that section's own "next step" note).

**Verified the mechanism, not just correlation**: `git blame` traces the "Notify the outgoing
Link" wording back to `a03ed61` (2026-06-11), written when `connections` was still keyed by the
SUMO-style approach edge — i.e. the comment mislabeled what was, at the time, actually the
*approach* link; the 2026-07-31 connections-keying fix (`docs/KNOWN_GAPS.md`'s
`TrafficSignalPhaseHandler` section, "Update 2026-07-31") then took that comment literally and
re-keyed the map to genuinely be outgoing-only, silently flipping this call site's semantics along
with it. Also confirmed real-world production scenario generators
(`tools/sao-paulo/generate_hybrid_input.py`, `tools/toulouse/generate_hybrid_input.py`,
`tools/interscsimulator_scenario/convert_interscsimulator.py`,
`hyperbolic-time-chamber/scripts/scenario/generate_tiny_validation_scenario.py`) all currently
emit `"connections": {}` unconditionally — this bug has been latent in production the whole time,
never triggered outside `tools/sumo_validation`'s hand-authored scenario B, the only place any
scenario populates `connections` at all. **[PARTIALLY RESOLVED 2026-08-05]** See "Production
Scenario Generators Never Wire `Node.connections`/`approachConnections`" further down this file —
`tools/interscsimulator_scenario/convert_interscsimulator.py` now wires `approachConnections`;
`tools/sao-paulo/generate_hybrid_input.py` needs a pipeline-ordering fix, not attempted; Toulouse
and the tiny-validation generator have no signal generation to wire at all.

**Fix**: added a second field, `NodeState.approachConnections: mutable.Map[String, Identify]`,
keyed by the APPROACH link (opposite direction of `connections`). `handleReceiveSignalChangeStatus`
now computes two separate sets — `outgoingLinksForThisPhase` (from `connections`, unchanged,
still drives `signalWaitingCounts`/`tryDrainCapacityQueue` bookkeeping, which mirrors
`handleRequestLinkAccess`'s own outgoing-link keying) and `approachLinksForThisPhase` (from the
new `approachConnections`, used only for the `LinkSignalStateData` MICRO notification). `Node.scala`
interns the new map's keys alongside the existing ones. `tools/sumo_validation/htc_export/export.py`
gained `_node_approach_connections`, populating the new field directly from
`TrafficLight.controlled_link_id` (already the approach edge, no translation needed — it's
`_node_connections_and_signals`, the outgoing-keyed one, that has to remap).

**Validation**:
- Added `NodeEventHandlerSpec` regression coverage: one test asserting `LinkSignalStateData` is
  sent to the approach link (from `approachConnections`) and never the outgoing link (from
  `connections`) on a phase change; one confirming `signalWaitingCounts`/capacity bookkeeping still
  keys off the outgoing link even though notification now uses the separate map — the two
  consumers needed genuinely different keys, not a single collapsed fix. `sbt test`: 161/161 pass
  (159 pre-existing + 2 new). Added `tools/sumo_validation/tests/test_htc_export.py` coverage for
  `approachConnections`'s exporter output; harness suite: 24/24 pass.
- `tools/sumo_validation/run_validation.py --scenarios a b`, three full runs after the fix:
  scenario B's max travel-time delta dropped from the pre-fix (but post-connections-keying-fix)
  **27s** to **8-9s**, and the previously wildly run-to-run-varying queued cars (`car_2`-`car_5`)
  became exactly reproducible across two independent runs (identical RMSE/delta figures both
  times) — consistent with these cars now being genuinely, deterministically gated by the (correct)
  approach-link virtual leader instead of racing an independent message round-trip against
  whatever position MICRO simulation happened to free-run them to. Scenario A (no traffic signal,
  should be entirely inert to this change): `car_1` RMSE landed at exactly **68.463m**, the same
  figure already on record in this doc's `sumo_validation` correction section — confirms zero
  behavioral change there, as expected.
- **New, smaller side-effect observed, not chased further**: `car_0`/`car_1` in scenario B (both
  clear the signal on Green, before it ever turns Red) show *higher* position RMSE post-fix
  (~90-110m vs. ~45-72m before) despite the fix not changing anything semantically relevant to
  their trip. Root cause not confirmed, but the mechanism is almost certainly the already
  extensively-documented wall-clock-race timing sensitivity above (parts 2/4/5 and the
  `sumo_validation` correction section) — this fix adds one additional harmless
  `LinkSignalStateData(Green)` message to `link_ab` at tick 0 (the signal's initial state
  broadcast, now correctly targeting the approach link instead of the then-empty outgoing link),
  and this scenario has already been shown to be sensitive enough to a single tick's dispatch-order
  shift that it can collapse an intended 6-tick departure gap to zero (see the `sumo_validation`
  `car_1` correction section). Not re-investigated here — the primary target of this fix (the
  multi-hundred-second overshoot) is closed, and chasing this residual noise is the same
  already-flagged, already-scoped TimeManager-level investigation (extending
  `dispatchGeneration`/`highestProcessedTick` to gate `Waiting`-fallback re-polls) as everywhere
  else in this doc, not a new problem this fix introduced.

## `Bus`/`Motorcycle`/`Bicycle` Micro Handlers Had the Same Dead-Fallback-Velocity Bug as `CarMicroHandler` (Found/Fixed 2026-08-05)

**Same bug class as the already-fixed `CarMicroHandler` finding** (see the `sumo_validation`
scenario A `car_1` RMSE section above) — flagged there as "not fixed, out of scope" for the other
three vehicle types, closed now. All three `*MicroHandler.handleMicroEnterLink` implementations
computed a vehicle's initial MICRO-mode velocity from a hardcoded fallback instead of the
vehicle's real carried-over exit velocity:

- **`BusMicroHandler.scala`**: `state.microState.map(_.velocity).getOrElse(speedLimitMs * 0.7)` —
  same shape as Car's original bug. `state.microState` is always `None` at this point
  (`handleMicroLeaveLink` calls `state.deactivateMicroMode()` on every exit, clearing it, before
  the next `handleMicroEnterLink` runs), so the `.map` branch could never fire; every micro-link
  entry fell into the `getOrElse`, starting every bus — first-ever trip or mid-route chained link
  alike — cruising at a flat 70% of the link's speed limit.
- **`MotorcycleMicroHandler.scala`** / **`BicycleMicroHandler.scala`**: worse — no
  `state.microState` check at all. Motorcycle unconditionally set `velocity = speedLimitMs * 0.9`;
  Bicycle unconditionally set a flat `5.0` m/s regardless of speed limit. Neither ever had a code
  path that could read a real prior velocity, chained or otherwise.

**Fix**: all three now read `journeyReporter.sumoArrivalSpeed` instead, mirroring
`CarMicroHandler`'s fix exactly — `0.0` by construction until a vehicle's first
`handleMicroLeaveLink` ever fires (matching SUMO's `departSpeed=0` default for a genuinely fresh
trip), then holds the real exit velocity from then on (already being written correctly by each
handler's own `handleMicroUpdate`/`handleMicroLeaveLink`, just never read back on the next entry).

**Validation**: added `BusMicroHandlerSpec`, `MotorcycleMicroHandlerSpec`, `BicycleMicroHandlerSpec`
(mirroring `CarMicroHandlerSpec`'s three cases each: fresh-trip rest start, chained-link velocity
carryover, reported `initial_velocity` matches stored state) — 9 new specs, no Pekko, all passing.
Full suite: 170 specs (161 pre-existing + 9 new), all green. Not independently re-run against
`tools/sumo_validation` — scenario A/B only exercise Car; no equivalent Bus/Motorcycle/Bicycle
harness scenario exists yet to measure a direct RMSE effect, same caveat `CarMicroHandler`'s own
fix noted for its own validation scope.

## Production Scenario Generators Never Wire `Node.connections`/`approachConnections` — Signals Have Zero Effect Outside `tools/sumo_validation` (Found 2026-08-05, Partially Fixed)

**Direct follow-up to the flagged-but-not-done note in the "`NodeEventHandler` Notified the Wrong
Link" section above.** All four scenario generators found in the platform
(`tools/sao-paulo/generate_hybrid_input.py`, `tools/toulouse/generate_hybrid_input.py`,
`tools/interscsimulator_scenario/convert_interscsimulator.py`,
`hyperbolic-time-chamber/scripts/scenario/generate_tiny_validation_scenario.py`) emit
`"connections": {}` (and, before this session, no `approachConnections` field at all)
unconditionally — meaning every traffic signal ever generated for a real scenario has had zero
behavioral effect on any vehicle, MICRO or MESO, network-wide, for the platform's entire history.
`tools/sumo_validation`'s hand-authored scenario B is the *only* place any scenario has ever
populated these fields. Investigated each generator individually; findings differ enough per tool
that a single fix doesn't cover all four:

- **`tools/interscsimulator_scenario/convert_interscsimulator.py` — fixed.** This is the
  "explicit, per the platform maintainer... robust, well-tested part" of the converter (its own
  module docstring), and it already had everything needed: `signals.xml` gives each phase an
  explicit approach-node origin, and `build_traffic_signal_actors` already resolves that to the
  real incoming link id (`_incoming_link_id`) to key `TrafficSignalState.signalStates`/`phases`.
  Added `wire_node_approach_connections(node_actors, signals, links)`, called right after
  `build_traffic_signal_actors` in `run()`: reuses the same `_incoming_link_id` resolution to patch
  each controlled node's `approachConnections` in place (mutates the already-built actor dicts, no
  re-merge needed since `actors` holds the same dict references). Also added the
  `"approachConnections": {}` default field to `build_node_actors`'s per-node content dict
  (previously missing entirely, not just empty). Two new regression tests
  (`test_wire_node_approach_connections_keys_by_approach_link_on_the_controlled_node`,
  `test_wire_node_approach_connections_against_real_base_scenario`) added to
  `tests/test_convert_interscsimulator.py`; full suite 43/45 passing (2 new; the same 4 pre-existing
  failures — `test_end_to_end_*sqlite*`/`*json*` — reproduce identically with this session's changes
  fully reverted, confirmed by diffing a manually-reverted copy of the file and re-running; root
  cause not investigated, looks like a `tools/scenario-db-converter/convert.py`/`ijson` environment
  issue in whatever venv runs this suite, unrelated to node-connection wiring).
- **`tools/sao-paulo/generate_hybrid_input.py` — investigated, NOT fixed; needs a deliberate design
  decision before attempting.** `TrafficSignalGenerator` already computes exactly the needed
  per-node incoming-link list (`self._node_incoming_links`, keyed by node id, populated during
  `_write_links()`) — the raw data isn't missing. The blocker is purely one of *pipeline ordering*:
  `_build_node_actor`/`self._node_writer.add(...)` streams each node actor to disk immediately
  during the single-pass OSM XML iterparse (`OsmNetworkParser`'s own architecture, deliberately
  memory-bounded for real full-city-scale runs — see the class's docstrings), which happens
  *before* `_write_links()` (and therefore `_node_incoming_links`) has run at all. Node actors are
  gone to disk by the time incoming-link data exists, so there's no in-memory dict left to patch
  the way `wire_node_approach_connections` does for InterSCSimulator above. Two possible fixes,
  neither attempted: (a) buffer signal-tagged node actors in memory instead of streaming them
  immediately, patch and flush after `_write_links()` — bounded by signal-node count, not total
  node count, so probably safe even at city scale, but changes the class's core memory-bounding
  invariant and needs care; (b) a separate post-hoc pass that reads back the already-written
  `nodes_*.json` files after `TrafficSignalGenerator.generate()` runs, patches matching signal
  nodes, rewrites — more surgery, but doesn't touch the existing streaming architecture at all.
  **Not attempted in this session because `tools/sao-paulo/` has zero test coverage of any kind**
  (confirmed: no `tests/` directory, unlike `interscsimulator_scenario/`) — implementing either
  fix blind, in a 3,982-line generator whose whole design is built around a memory constraint,
  without a way to verify correctness first, was judged too risky to guess at. Whoever picks this
  up next should probably stand up at least minimal pytest coverage for `_write_links`/
  `TrafficSignalGenerator` first.
- **`tools/toulouse/generate_hybrid_input.py` — not applicable, different gap entirely.** This
  generator has no traffic-signal generation code at all (confirmed: no `TrafficSignalGenerator`,
  no `include_signals` flag, no OSM `highway=traffic_signals` handling — `grep` for
  `signal|traffic_light` only matches the static `"signals": {}` placeholder). There is no signal
  data to wire connections to in the first place. Adding real signal generation here would be a
  new feature (presumably portable from `tools/sao-paulo/`'s `TrafficSignalGenerator`, since both
  are OSM-based), not a wiring fix — separate scope, not attempted.
- **`hyperbolic-time-chamber/scripts/scenario/generate_tiny_validation_scenario.py` — same as
  Toulouse.** No signal generation; `"connections": {}` is the only signal-adjacent content, a
  static placeholder with nothing to wire.

**Separate, deeper architectural gap surfaced by this investigation, affecting even the fixed
InterSCSimulator path**: `connections` (outgoing-link keyed, required for MESO-mode admission
control — `Car.actSpontaneous`'s `case Moving if !isMicroMode` calls `requestSignalState()`, which
depends entirely on `connections`, not `approachConnections`, which only matters for MICRO's
`signalAtExit`) is **not** wired by this fix, deliberately. Resolving it correctly requires
per-(incoming-link, outgoing-link) turn-movement data — "does traffic from this specific approach
have a green for this specific exit" — that none of network.xml/signals.xml/OSM `highway` tags
provide. A naive heuristic (e.g. "gate every outgoing link of a signalized node by whichever
incoming phase was processed last") risks silently mis-gating a legal movement, which is worse than
today's status quo of no MESO gating at all — considered and rejected for that reason rather than
implemented speculatively. Since most real São Paulo-scale traffic is expected to run MESO (MICRO
is reserved for small/dense/validation scenarios per `_select_mode`'s `micro_ratio` config), this
means even a fully-fixed São Paulo generator would only gate MICRO-mode vehicles near a signal
until this deeper gap is addressed — a genuine `htc-architect`-level design question (does HTC's
signal model need turn-movement-aware admission control, and if so what data/format would supply
it), not a follow-up wiring task. Flagged here, not designed or implemented.

## `PersonPlanManager.handlePTUnloadRequest` Silently Drops the Reply When a PT-Boarding Timeout Races the Real Ride (Found 2026-08-07, Not Fixed)

Found during a `docs/TIME_WARP_DESIGN.md`-driven audit checking whether `model/hybrid`'s
consistency-critical request/reply handlers actually follow this repo's own CLAUDE.md
"Synchronization Discipline" (every consistency-critical request handler must reply on *every*
branch, including no-op ones). **Not Time-Warp-specific** — reproduces identically under the
conservative barrier; found while looking for Time Warp gaps, but it's a general correctness bug.

**The gap**: `PersonPlanManager.handlePTUnloadRequest` (`support/person/PersonPlanManager.scala:378-419`)
only sends a reply inside its `case t: Traveling if t.ptWait.isDefined` branch (delegating to
`PersonPTTripHandler.handlePTUnloadRequest`, itself verified to reply on every branch). The fallback:

```scala
case _ =>
  logWarn(s"$personId received PT unload request from ${event.actorRefId} while not waiting on a PT leg — ignoring (already handled)")
  None
```

sends **no reply at all** — `Person.actInteractWith` (`actor/Person.scala:228-240`) consumes the
`Option[PlanStepResult]` via `.foreach`, so a `None` here silently drops the interaction with zero
message back to the requesting `Bus`/`Subway`.

**Why the fallback branch is actually reachable, not just defensive dead code**: `ptWait`
(`TripExecutionState.Traveling.ptWait`) is set when a transit leg starts
(`PersonPlanManager.scala:180-191`), alongside a self-scheduled timeout wake at
`currentTick + state.ptWaitTimeoutTicks`. Boarding (`Person.actInteractWith`'s
`PassengerBoardedVehicleData` case, `Person.scala:225-226`) only sets the actor-local
`currentPTVehicleRef` — it never clears/reschedules that pending timeout, and there's no API in this
TM to cancel an already-scheduled tick. `ptWait` is only cleared on true arrival
(`PersonPlanManager.scala:414`, inside the same branch that replies). So if the PT ride itself (after
boarding) takes longer than `ptWaitTimeoutTicks` — plausible under congestion if that timeout was
tuned for "wait for the bus to *arrive*," not "wait out the whole ride" — the Person self-wakes
mid-ride, sees `Traveling(ptWait = Some(...))`, and dispatches `replanAfterPTTimeout`
(`PersonPlanManager.scala:245-310`), which unconditionally drops the current leg run and replans —
with no awareness the person is already physically seated on the vehicle. When the real vehicle
later reaches the alighting stop and sends its unload request, `tripExecution` no longer matches
`Traveling(ptWait = Some(...))`, so the request falls into the silent-`None` branch above.

**Consequence**: the vehicle's `expectedUnloadResponses` counter (`BusStopHandler.scala:174`,
`SubwayPassengerHandler`'s equivalent — both actor-local, not part of `BusState`/`SubwayState`)
never reaches `countUnloadReceived`, so `handleUnloadPassenger`'s completion branch
(`BusStopHandler.scala:100-147`, gated on `state.countUnloadReceived >= expectedUnloadResponses`)
never fires — the vehicle is permanently stuck in `WaitingUnloadPassenger` for that stop specifically
because of this one passenger. No TM-level hang (the vehicle had already called
`onFinishSpontaneous(None)` before waiting and relies on a later `scheduleEvent` call to re-enter the
schedule, the same "immediate-`None`-finish + reschedule-on-reply" pattern verified clean everywhere
else in the vehicle↔`Node` signal/capacity exchange during the same audit) — this manifests as a
silently-corrupted trip/ridership/completion metric, not a crash.

**Not fixed** — flagged for whoever picks this up. The real fix is upstream of the reply handler
itself: `PassengerBoardedVehicleData` handling needs to cancel or account for the pending
`ptWaitTimeoutTicks` wake once boarding actually happens, not patch the fallback branch to
paper over a still-possible desync between `tripExecution` and physical vehicle occupancy.

**Also surfaced, not a bug**: the vehicle↔`Node` signal/link-access exchange (`CarSignalHandler`
and its Motorcycle/Bicycle/Bus equivalents) doesn't literally implement CLAUDE.md's "withhold
`onFinishSpontaneous` until the reply arrives" wording — it finishes with `None` immediately and
relies on the reply handler's `scheduleEvent` call to re-enter the schedule. Functionally sound today
(`NodeEventHandler.handleRequestLinkAccess` replies on every branch, verified), but worth noting the
failure mode differs from CLAUDE.md's literal example: a future missing-reply bug introduced here
would silently strand a vehicle forever rather than hang the Time Manager, since the requester is
already unregistered from `runningEvents`/`scheduledActors` by the time it's waiting.

## Time Warp: `Movable` Route State (`movableCurrentPath`/`bestRoute`) Not Correctly Reconstructed After a Rollback (Found 2026-08-07, Not Fixed)

Found running a real conservative-vs-optimistic comparison on the tiny end-to-end scenario, as a
continuation of the Time Warp report-flush-race work (`docs/TIME_WARP_DESIGN.md` §4). Two prior
layers of that race were fixed and verified first (see that doc's implementation log): (1) an
ack-based handshake (`DestructAckEvent`/`LocalDestructCompleteEvent`) so `OptimisticGlobalTimeManager`
only tells `ReportManager` to stop once every force-destructed actor's flush has actually been sent,
closing a race where `ReportManager` routinely closed its parquet writers before Time-Warp-buffered
reports arrived; and (2) a `hasStarted` gate on `OptimisticLocalTimeManager.onActorRescheduled`, since
`registerActor`/`scheduleEvent` can arrive during the load/warm-up phase (well before this LTM's own
`StartSimulationTimeEvent`), and dispatching then — as the unconditional immediate-dispatch behavior
used to — handed EAGER actors like `SubwayStation`/`BusStation` their first `SpontaneousEvent` before
the infrastructure it depends on (`Node`, the dynamic-actor-spawn machinery) was ready.

Both fixes are real and independently verified (unit tests, plus confirmed via live logs that
`SubwayStation`/`BusStation` now actually run — route calculation, dynamic `Bus`/`Subway` spawn, real
interaction traffic — none of which happened at all before either fix). But the comparison run's
parquet output is still far short of parity with conservative mode (0 rows vs. conservative's 285),
and the reason is a third, distinct, and larger gap:

**The gap**: `Bus`/`Subway` (and by construction, anything sharing `Movable`) genuinely roll back
under Time Warp once real activity starts — confirmed via repeated `"anti-message for
unknown/already-pruned messageId"` log lines for both actors, meaning `RollbackHistoryHandler`
detected a straggler and unwound processed events. After one of these rollbacks, `BusSignalHandler`
starts logging `"No current node"` (`support/bus/BusSignalHandler.scala:72`) — `getCurrentNode`
(`Movable.scala:271`) reads `state.movableCurrentPath`, and that field comes back empty/`None` even
though `Movable.enterLink()` (`Movable.scala:159-202`) always sets it *synchronously*, before ever
sending anything, so this isn't the fire-and-forget `EnterLinkData` exchange racing ahead of a reply
(that was the first hypothesis; ruled out by reading `enterLink()`/`getCurrentNode` directly — no
reply is ever awaited to populate this field in the first place). The only mechanism that could make
an already-synchronously-set field revert to empty is replay: `RollbackHistoryHandler`'s
checkpoint-plus-forward-replay reconstructing this actor's state after a rollback without correctly
reproducing every mutation `Movable` subclasses make to their route-position fields along the way.

**Why conservative mode never surfaces this**: it doesn't roll back at all — no stragglers, no
replay, so whatever gap exists in replay's fidelity for `Movable` state is invisible under the
barrier. This is a genuine Time-Warp-only correctness gap, not a report-buffering/flush-ordering
issue like the other two fixed this round — it sits at the semantic level of "does replaying logged
events actually reproduce the same state as live execution did," specifically for `Movable`'s
route-tracking fields (`movableCurrentPath`, `movableBestRoute`, `currentPathPosition`, and siblings
across `Car`/`Bus`/`Motorcycle`/`Bicycle`/`Subway`).

**Not fixed** — this is a materially bigger and riskier area than the two flush/registration-timing
fixes above (core vehicle movement state, not Time Warp plumbing), so it's flagged here rather than
attempted at the end of an already-long session. Whoever picks this up should start by checking
whether `RollbackHistoryHandler`'s `recordProcessedEvent`/`rollbackTo` replay path
(`core/actor/rollback/RollbackHistoryHandler.scala`) re-runs `Movable.enterLink()`/`leavingLink()`'s
full mutation sequence on each replayed event, or only a partial subset (e.g. if replay short-circuits
side effects that were originally driven by an interaction-event reply rather than the spontaneous
event itself — `Movable`'s route fields are mutated across *both* `actSpontaneous` and
`actInteractWith` handling, and it's plausible only one of those paths is captured correctly by
whatever `LoggedEvent` replay currently reconstructs).

## `BusStation`/`Subway` Crash Every Tick — Jackson Silently Leaves `Map[Long, Long]` Keys as `String` at Runtime (Found 2026-08-26, Fixed 2026-09-11)

`hybrid.actor.BusStation` and `hybrid.actor.Subway` throw `ClassCastException: java.lang.String
incompatible with java.lang.Long` on every `actSpontaneous`, inside
`BusStationRouteCalculator.orderedBusStopIds` (`state.busStops.keys.toList.sorted`, where
`BusStationState.busStops: mutable.LinkedHashMap[Long, Long]`). Reproduced in isolation with a
throwaway synthetic case class and a `{"4":2,"5":3}` JSON payload run through the exact
`JsonUtil` mapper: Jackson/jackson-module-scala silently leaves `Map[Long, X]` **keys** as raw
`String` at runtime despite the declared type (values coerce fine — `println` even prints the
keys looking like numbers, but the first `.asInstanceOf`/unboxing to `Long` throws).

**Root cause, precisely identified 2026-09-11**: this is not a generic Jackson/Long bug — it is
specific to Scala 3 case classes. jackson-module-scala only preserves a case class's full Map
key/value generic signature for the constructor's *first* parameter; every later `Map[Long, _]`
parameter has its key type erased to `Object` by the time Jackson resolves a key deserializer, so
the key silently stays the raw JSON field-name `String`. A **mapper-wide** `KeyDeserializer`
registration for `java.lang.Long` (or its primitive `TYPE`) via `SimpleModule` is provably never
consulted for these fields — confirmed by instrumenting the deserializer and observing zero
invocations even with the registration present. The only mechanism Jackson actually honors here is
the **per-field** `@JsonDeserialize(keyAs = classOf[java.lang.Long])` annotation, which bypasses
the broken type inference entirely.

**Fixed**: this annotation was already applied (uncommitted, working-tree-only) to every
non-first-position `Map[Long, _]` field across `model.hybrid.entity.state` (`BusStationState`,
`BusState`, `SubwayState`, `NodeState`, `TrafficSignalState`) by an earlier session, each with a
comment explaining the rule. **One field was missed**: `MigrationSnapshot.linkVehicleEntryTick` /
`linkVehicleWaitingSeconds` (`core.actor.manager.loadbalance.migration.MigrationSnapshot`) — these
round-trip through the exact same `JsonUtil` mapper on every shard-migration
save/restore (`BaseActor.saveMigrationState`/`restoreMigrationState`), feeding
`Link.vehicleEntryTick`/`vehicleWaitingSeconds` via `++=`. Without the annotation this would have
**silently corrupted** per-vehicle link timing state after every migration restore (a missed key
lookup, not a crash, since `Map[Long,Long]#++=` doesn't unbox eagerly) — directly relevant to Time
Warp's rollback/migration-snapshot correctness. Added the same `@JsonDeserialize(keyAs = ...)`
annotation to both fields; full `sbt test` (339 tests) passes.

An audit of every `Map[Long, _]` in the codebase (`grep -rn "Map\[Long" src/main/scala`) found no
other case-class constructor parameter missing the annotation — the remaining unannotated hits are
all actor-local `var`s/handler-method parameters/`java.util.HashMap`s that never round-trip through
`JsonUtil` directly (they get captured into an already-annotated state/snapshot field instead, or
use a different serialization path e.g. `CompactGraph`'s `java.util.HashMap`).

## Time Warp: Rollback-Orphaned Reply Permanently Hangs an Actor Waiting on a Signal/Link Reply (Found/Fixed 2026-09-05)

Found chasing an unrelated `tls_test` livelock, not the `Movable` route-replay gap above (that one
is still open). **Root cause**: an actor sends a request (e.g. `RequestLinkAccessData`) and
disengages via `onFinishSpontaneousFn(None)`, relying entirely on the reply handler to reschedule
it. If a Time Warp rollback then restores `state.status` to its pre-request value before the
genuine, un-retractable reply arrives, the old `state.status`-only staleness guard
(`state.status != WaitingSignalState && state.status != WaitingCapacity`) sees the "wrong" status
and silently drops the reply as stale. Nothing else can ever reschedule that actor — it's
permanently orphaned, hanging its LTM/GVT.

**Fixed** via a new rollback-immune, actor-local tracker (`core/actor/AwaitedReply.scala`,
`SimulationBaseActor.registerAwaitedReply`/`isAwaitingReply`/`consumeAwaitedReply`) consulted
alongside the existing `state.status` guard — see `docs/TIME_WARP_DESIGN.md`'s 2026-09-05 log
entries for the full mechanism and reasoning (including why this is correctly actor-local and not
`state`, per this doc's "Shard Migration Silently Drops Actor-Local Reply State" entry above:
losing this on a migration costs a stale-reply false-positive, not a hang). First pass wired it
into `Car`'s signal handler and the shared `Movable` enter/leave-link path (covering
`Car`/`Bicycle`/`Motorcycle`'s link handlers); a follow-up pass the same day ported the identical
fix to `BicycleSignalHandler`/`MotorcycleSignalHandler`, `BusSignalHandler`/`BusLinkHandler`, and
`Subway`'s inline enter/leave-link handling — all of which had been missed and carried the exact
same live bug (Bus/Subway had it in both the signal-wait and, for `BusLinkHandler`, a
previously-unguarded leave-link path). All five `Movable` subclasses now carry the fix; this
class of bug is closed. Regression tests: `SimulationBaseActorAwaitedReplySpec` plus
`BicycleSignalHandlerSpec`, `MotorcycleSignalHandlerSpec`, `BusSignalHandlerSpec`,
`BusLinkHandlerSpec`, `SubwayAwaitedReplySpec`. Full suite: 315 tests, 0 failures.

## Time Warp: Dynamic Actor Spawn (`BusStation`/`SubwayStation` → `Bus`/`Subway`) Bypasses Anti-Message Tracking, Duplicate-`InitializeEvent`s a Live Actor on Rollback (Found/Fixed 2026-09-07)

`BusStation`/`SubwayStation` create their `Bus`/`Subway` actors via `SimulationBaseActor.spawnDynamicActor`,
which talks directly to the `ShardRegion` (`shardRegion ! ShardRegion.StartEntity(...)`) rather
than going through `sendMessageTo`. That means the spawn is never captured in
`currentEventSentMessages`/`LoggedEvent.sentMessages`, so `AntiMessageCascade` can never generate
an anti-message for it. If the station's Time Warp rollback target lands before the tick where it
dequeued a bus/subway and called spawn, replay re-dequeues the same `BusInformation`/
`SubwayInformation` (the dequeue itself is fine — `state.buses`/`state.subways`/`state.lines` are
checkpointed and restored correctly) and re-spawns with the same deterministic entity id.
`ShardRegion.StartEntity` on an already-live id just re-delivers `InitializeEvent` to the running
actor, and `SimulationBaseActor.onInitialize` has no idempotency guard (unlike `BaseActor
.onInitialize`'s `if (!isInitialized)`), so the live `Bus`/`Subway` gets its state and
`RollbackHistoryHandler` reset mid-flight. Intermittent — only when the station's rollback target
crosses the exact dequeue tick.

**Fixed** by deferring the one truly irrevocable step — `spawnDynamicActorFn` (plus the
actor-local `dependencies` registration that has to go with it, since `dependencies` is not part
of checkpointed `state` and so isn't restored by rollback either) — until GVT has passed the
dequeue tick, reusing the same "wait for a GVT watermark, then do the irrevocable thing" pattern
already used for `SimulationBaseActor.reportBuffer`/`flushBufferedReportsUpTo`
(`SpontaneousEvent.gvt`, piggybacked on every `SpontaneousEvent` an `OptimisticLocalTimeManager`
sends). Everything else about creating a bus/subway (route validation, building the state object,
`report()`) is either pure or already Time-Warp-safe, so it still runs eagerly at dequeue time in
both modes.

Concretely: `BusStationBusCreator.createBus`/`SubwayStationCreator.createSubway` (private) were
split into `prepareBus`/`prepareSubway` (route + state build + `report()`, returns the state JSON,
never calls `spawnDynamicActorFn`) and `spawnPrepared`/`spawnPreparedSubway` (the metrics
increment + the actual `spawnDynamicActorFn` call). `createBus`/`createSubway` still chain both in
sequence, so the non-Time-Warp path is byte-for-byte unchanged. `SubwayStationCreator` also gained
`prepareSubwaysFrom`, the prepare-only counterpart of `createSubwayFrom` (it can dequeue+prepare
more than one line's subway per call).

Under Time Warp, `BusStation`/`SubwayStation` stash the prepared `(bus/subway, dequeue tick, state
JSON)` locally (`pendingBusSpawn: Option[...]` / `pendingSubwaySpawns: mutable.Map[Long, ...]`)
instead of spawning immediately, and poll every tick in `actSpontaneous` until
`event.gvt.exists(_ >= dequeueTick)`, at which point `firePendingBusSpawn`/
`firePendingSubwaySpawns` finally calls `spawnPrepared`/`spawnPreparedSubway` and registers the
`dependencies` entry. This is safe by GVT's own monotonicity invariant (`MarginBasedGVTEstimation`:
`GVT = min(reported LVTs) - margin`, the point below which no rollback can ever reach again): once
GVT has passed the dequeue tick, the station provably can never roll back to before it again, so
firing the deferred spawn needs no anti-message mechanism. Conversely, if the station rolls back to
before the dequeue tick before GVT gets there, the stash is simply discarded — nothing external
was ever created, so nothing needs undoing.

That discard is a new `protected` hook on `SimulationBaseActor`, `onRollbackDiscardPending
(targetTick: Tick)` (default no-op), called unconditionally from `rollbackAndCascade` right after
the existing `reportBuffer.filterInPlace(_._1.tick < targetTick)` line — both existing call sites
into `rollbackAndCascade` are already inside `isTimeWarp &&` guards, so no extra gating was needed
at the hook's call site. `BusStation`/`SubwayStation` override it to drop any stash entry whose
dequeue tick is `>= targetTick`, mirroring the reportBuffer filter's `< targetTick` convention.

Non-Time-Warp (discrete-event/conservative) mode is unaffected by construction: the deferred-spawn
path is gated on `getCurrentTimeManagerType == TimeManagerTypeEnum.TIME_WARP`, and
`pendingBusSpawn`/`pendingSubwaySpawns` are simply never populated outside Time Warp.

Regression tests: `BusStationBusCreatorSpec`, `SubwayStationCreatorSpec` — both plain-ScalaTest,
no Pekko, covering: `prepareBus`/`prepareSubway` never touch the spawn lambda;
`spawnPrepared`/`spawnPreparedSubway` call it with exactly the JSON `prepare*` produced;
`prepareBus`/`prepareSubway` still throw `IllegalStateException` on an empty/missing route exactly
as the old `createBus`/`createSubway` did; `prepareSubwaysFrom` dequeues+prepares without ever
spawning and re-enqueues on failure; `createBus`/`createSubwayFrom` (the non-Time-Warp path) still
spawn immediately, unchanged. Full suite: 330 tests, 0 failures.

## Time Warp: `OptimisticLocalTimeManager.localVirtualTime` Understated GVT for Two Real Reasons (Found/Fixed 2026-09-11) — But GVT-Plateau Termination Itself Was Never the Bug; the Real, Now-Quantified Gap Is Report Loss/Duplication (Found 2026-09-11, Not Fixed)

**History of this investigation, since the framing changed twice in one session — read this before
trusting either fix in isolation.** An earlier session's diagnosis attributed a "GVT plateaued at
-100 while report data shows real progress" symptom to the `deferFinishSpontaneous()` dynamic-spawn
pattern — already fully removed by the time this was rechecked (see that section above, fixed
2026-09-07). Rerunning `simulations/input/tw_livelock_repro` (endTick=3600, 1 bus line, 20 cars, 5
bicycles) under `time-warp` against a real docker-compose cluster (after this session's Jackson
`Map[Long,_]` fix unblocked `Bus`/`Subway` running at all — see that entry above) reproduced the
exact same log line, `"GVT plateaued at -100 with all LTMs idle for 3 rounds — terminating"`, ~1.5s
after load. Two real bugs in `OptimisticLocalTimeManager.localVirtualTime` were found and fixed
(below) on the assumption this explained premature termination. **It didn't, and termination was
never premature in this scenario** — see "The actual explanation" below, established only after
adding a real conservative-mode baseline run that no prior session had done for this scenario.

**Bug 1 (fixed): idle-instant collapse.** `localVirtualTime` (`OptimisticLocalTimeManager.scala:237`
at the time):
```scala
protected def localVirtualTime: Tick =
  if (runningEvents.nonEmpty) runningEvents.map(a => highestProcessedTickOf(a.id)).min
  else nextTick.getOrElse(localTickOffset)
```
The `if` branch is correct. But the instant `runningEvents` goes empty — routine between one batch
resolving and the next being dispatched, not just at genuine end-of-simulation — LVT fell back to
`nextTick.getOrElse(localTickOffset)`. `localTickOffset` starts at `initialTick` and in this class
is only ever moved *backward* (by `resyncScheduleAfterRollback`'s rollback resync), never forward
as actors genuinely progress — so any such idle instant silently discarded all of
`highestProcessedTick`'s real history. **Fix**: added `LocalTimeManagerBase.minHighestProcessedTick`
(the min `highestProcessedTick` across every actor this LTM still owns, persists across idle gaps,
removed only on `completeDestruct`) and floor the idle-branch at `min(nextTick, that)` instead.
Regression test: `OptimisticLocalTimeManagerSpec` — "should report LVT as the actor's real
high-water mark once idle, not collapse back to localTickOffset."

**Bug 2 (fixed): permanently-empty routee collapse.** `MarginBasedGVTEstimation.estimate` takes
`min` over *every* reporting LTM unconditionally. An LTM pool routee that has never had (or no
longer has) a single actor assigned — plausible whenever the pool has more instances than the
scenario has actors (`HTC_TIME_MANAGER_INSTANCES=16` for this ~90-actor scenario) — reported
`localTickOffset` (`0`) forever via the same fallback, permanently pinning the global `min` near
`0 - margin` regardless of how far every *other*, genuinely busy LTM progressed. **Fix**: when
`registeredActors.isEmpty`, report `Long.MaxValue` (no constraint) instead. Regression test:
"should report LVT as Long.MaxValue... for a routee with zero actors ever assigned."

Both fixes are real, safe (only ever make LVT *more* accurate, never invent progress — preserves
the "underestimate is safe" invariant), and covered by new passing tests (full suite: 341 tests).
**Neither changed the live symptom** — rerunning the same scenario after both fixes still logged
`"GVT plateaued at -100"` at the same ~1.5s mark. Chased a third hypothesis (Link/Node actors in
MESO mode call `onFinishSpontaneous(None)` and never self-reschedule, so their contribution to
`highestProcessedTick` freezes at their first dispatch tick even while they keep handling
interaction events for the rest of the simulation — interactions never update `highestProcessedTick`
at all) — real observation, but turned out to be a red herring for *this* symptom too.

**The actual explanation, established by finally running a real conservative-mode baseline of this
exact scenario** (`timeManagerType: "discrete-event"`, same docker-compose cluster): conservative
mode **also** stops producing events at max `tick=1801` — identical to time-warp. This is not a
coincidence: every `Person`'s plan here is `home (→300) → trip → leisure (→1800) → trip → home
(→86400)` — after the second trip completes (~tick 1801), nothing is scheduled again until tick
86400, far past this scenario's `endTick=3600`. `BusStation` (the one actor type that genuinely
self-reschedules every tick) ran for real all the way to `"BusStation 36 reached simulation end
tick=3600, stopping scheduling"` before the plateau fired. **The GVT-plateau termination decision
itself is correct** — there really is no more spontaneous work to dispatch anywhere once every
actor's plan is exhausted. The `-100` number is a red herring for a real symptom that isn't the one
it looks like: it never caused an early stop, and reads confusingly low mostly because of the two
now-fixed calculation bugs above, plus whatever residual imprecision Bug 3 above still contributes
(not chased further, since it no longer has an observable symptom attached to it).

**What the baseline comparison actually revealed — the real, now-precisely-quantified gap**:
report count. Both runs reach `tick=1801`; conservative produced 660 parquet rows, time-warp only
252, for the *same* activity window. Breaking down by `event_type`, the pattern is not uniform
under-counting — it's a mix of near-total loss and duplication:

| Pattern | Event types | Example |
|---|---|---|
| Near-total loss (≥90% missing) | `leave_link` (0/26 survive), `enter_link`, `journey_started`/`journey_completed`, `sumo_tripinfo`, `route_planned`, `person_trip_completed`/`person_trip_metrics`/`person_leg_metrics`, `vehicle_event_count` | conservative has 51 `enter_link` rows, time-warp has 15, and only 1 of those 15 ticks overlaps with a conservative row at the same `(entity_id, tick)` |
| Duplication (same entity+tick reported 3-4×) | `person_schedule_complete` (conservative: 30, time-warp: **58** — more than conservative, not less) | entity `45` has 4 separate `person_schedule_complete` rows all at `tick=300` |

**Cause 1, found and fixed same session: `journeyFinishedReported`/`sumoTripInfoReported` are
actor-local, not `state`.** `CarJourneyReporter.finishJourney`/`reportSumoTripInfo` (and the
identical pattern in `BusJourneyReporter`/`BicycleJourneyReporter`/`MotorcycleJourneyReporter`) each
guard against duplicate reporting with a `private var ...Reported: Boolean = false`, set `true` on
first call and never reset except by the per-trip `reset()` (called only at genuine new-trip start,
via `resetTripState()`). A Time Warp rollback restores `state` via `RollbackHistoryHandler` but has
no way to know about this actor-local flag, so it survives untouched. Sequence: a trip's real
completion fires once (flag → `true`, report buffered); an overlapping rollback undoes back to
*before* that completion (discarding the now-invalid buffered report, correctly, via
`reportBuffer.filterInPlace(_._1.tick < targetTick)`); replay reaches the same (or corrected)
completion point again and calls `finishJourney` again — but the guard is still `true` from the
first, now-invalidated attempt, so the call is silently swallowed and **no report survives for that
trip's completion at all**, for the rest of the simulation (the guard is never reset again short of
a whole new trip starting). Confirmed directly: `entity 42` (a `Car`) showed `journey_completed`
reported at `tick=0` in the time-warp parquet output — a stale/impossible timestamp, symptomatic of
this exact class of corruption.

**Fix**: added `clearCompletionGuards()` to each of the four journey reporters — narrower than
`reset()`, clearing only the `...Reported` flags without wiping accumulated SUMO metrics
(`sumoDepartTick` etc.) that describe the surviving, not-undone portion of the current trip. Wired
into `Car`/`Bus`/`Bicycle`/`Motorcycle`'s (new) `onRollbackDiscardPending` override — the same
existing extension point `BusStation`/`SubwayStation` already use for their own actor-local stash —
called unconditionally on every rollback for that actor. Safe: if the guarded completion was NOT
among the undone events (it already happened before the rollback's target), nothing in the replay
can call `finishJourney` again for that already-finished trip, so clearing the guard can't produce
a spurious duplicate. New test: `CarJourneyReporterSpec` (plain ScalaTest, no Pekko). Full suite:
344 tests, 0 failures.

**Measured effect, same live scenario**: `journey_completed` 15→23 rows, `sumo_tripinfo` 15→23,
`enter_link` 15→21, `leave_link` 2→3 (conservative baseline: 51/51/51/26 respectively) — a real,
confirmed improvement, but **most of the loss remains**. Two more, distinct causes identified but
**not fixed this session**:

**Cause 2 (found, partially fixed): `PersonMetricsReporter.reportScheduleComplete` had no
idempotency guard at all** — unlike the vehicle journey reporters, there was no `...Reported` flag
to reset in the first place; `Person.dispatch`'s `PlanStepResult.Finished` branch called it
unconditionally every time that branch was reached, and replay could reach it more than once.
Explained why `person_schedule_complete` was *duplicated* (conservative: 30, time-warp: 33-58
across runs) rather than lost.

**Fix**: added a `protected var scheduleCompleteReported: Boolean` guard on `Person` (no per-trip
reset needed, unlike the vehicle case — a Person's daily schedule completes at most once ever,
immediately followed by `destruct = true`), checked/set around the `reportScheduleComplete` call,
and cleared via a new `Person.onRollbackDiscardPending` override, same mechanism as `Car`/`Bus`/
`Bicycle`/`Motorcycle`. New test: `PersonScheduleCompleteGuardSpec` (drives the guard/reset directly
since `dispatch` itself is private). Full suite: 347 tests, 0 failures.

**Measured effect, same live scenario**: duplicate count dropped (e.g. entity `45`: 4 → 3 rows at
the same tick) but **duplication is not fully eliminated** — some entities still show 2-3 rows.
This means `dispatch(PlanStepResult.Finished)` can apparently be reached more than once for the
same Person *without* an intervening rollback for that actor resetting the guard in between (the
guard-clear is keyed to this actor's own `onRollbackDiscardPending` firing, but if the duplicate
calls happen within a window where no rollback touched *this* actor at all, clearing on rollback
can't be the whole story). Not investigated further — next step would be logging every call to
`dispatch(Finished)` with `currentGeneration`/`isReplaying` to see what actually triggers the
repeat calls when no rollback intervenes.

**Cause 3 (found via new Prometheus instrumentation, not fixed): vehicles thrash on entering links
without progressing to leaving them — a functional rollback/replay bug, NOT a report-pipeline bug.**

To distinguish "reports lost in the buffering pipeline" from "the underlying behavior itself is
wrong," added three new metrics (`core.metrics.core.ActorMetrics`,
`htc_report_discarded_by_rollback_total`/`htc_report_flushed_total`, both by `event_type`, plus
`htc_antimessages_sent_total` by `sender_actor_type`) and instrumented `SimulationBaseActor.report`/
`flushBufferedReportsUpTo`/`rollbackAndCascade`'s discard/`sendAntiMessage`. Existing
`ActorMetrics.eventsProcessed{event_type}` already counted every `report()` call *attempted*
(conservative and Time Warp alike). Querying `:9999/metrics` right after the same live
`tw_livelock_repro` run (before shutdown) gave, per `event_type` (attempted / discarded-by-rollback
/ flushed):

| event_type | attempted | discarded | flushed | attempted − discarded | conservative baseline (attempted-equivalent) |
|---|---|---|---|---|---|
| `enter_link` | 84 | 61 | 20 | 23 (≈ flushed, small race) | 51 |
| `leave_link` | 7 | 2 | 5 | 5 (exact) | 26 |
| `route_planned` | 62 | 56 | 6 | 6 (exact) | 40 |
| `journey_started` | 74 | 64 | 10 | 10 (exact) | 50 |
| `sumo_tripinfo` | 29 | 8 | 21 | 21 (exact) | 51 |
| `journey_completed` | 29 | 8 | 21 | 21 (exact) | 51 |
| `vehicle_event_count` | 23 | 6 | 17 | 17 (exact) | 40 |

**The buffering pipeline's own accounting is correct** — `attempted − discarded = flushed` holds
almost exactly for every event type. Nothing is silently lost between `report()` and the reporter
target; every report is accounted for as either genuinely flushed or genuinely discarded because a
rollback undid the tick it described. This rules out a report-buffering bug as Cause 3.

**What the numbers show instead**: a clear over/under-attempt split. "Entering" events
(`enter_link` 84 vs. 51 baseline, `journey_started` 74 vs. 50, `route_planned` 62 vs. 40) are
*over*-attempted — replay is re-generating the same early-route report() calls repeatedly, while
"completion" events (`leave_link` 7 vs. 26, `journey_completed`/`sumo_tripinfo` 29 vs. 51,
`vehicle_event_count` 23 vs. 40) are *under*-attempted — vehicles rarely make it far enough to call
these at all. This is the signature of a vehicle repeatedly entering a link, being rolled back, and
retrying — without net forward progress through its route — not vehicles genuinely completing
shorter, valid, different routes. Corroborated by anti-message volume by sender type from the same
run: `hybrid.actor.Car` 66, `hybrid.actor.Link` 64, vs. `hybrid.actor.Node` 17, `hybrid.actor.Bicycle`
10, `hybrid.actor.Person` 1 — the Car↔Link enter/leave-link exchange dominates rollback churn by a
wide margin over every other interaction type in this scenario.

**Root cause found, partially fixed (2026-09-11/12).** Traced with the new metrics above: of the
Car↔Link `ReceiveEnterLinkInfo` stragglers, most were NOT the 2026-09-06 `AwaitedReply` `key`+`kind`
livelock class (that fix's `requestSeq` identity check is correct and already in place) — they were
a *different* bug: `SimulationBaseActor.handleInteractWith` unconditionally triggered a full
rollback for any tick-behind interaction, checked *before* `actInteractWith` (and therefore before
`CarLinkHandler`'s own `isAwaitingReplyFn` staleness gate) ever got a chance to recognize a reply as
already-superseded. **Fixed**: a new `protected def isKnownSupersededReply(event): Boolean = false`
hook on `SimulationBaseActor`, consulted before the rollback trigger; `Movable` overrides it using
the same `isAwaitingReply` identity check business logic already had. Also added the same staleness
gate to `CarLinkHandler.handleEnterLink` that `handleLeaveLink` already had (defense in depth — the
old comment claiming it was "always safe" to skip was wrong under heavy contention). New tests:
`MovableIsKnownSupersededReplySpec`. Full suite: 351 tests, 0 failures. **Measured effect**: only
~8 of ~42 rollbacks for this pair were genuinely superseded replies (now correctly dropped without
a rollback, tracked by `htc_stale_reply_dropped_without_rollback_total`) — a real but minority
improvement.

**The remaining ~34 are genuine causality violations, not a fixable protocol bug** — traced to
`Movable.actSpontaneous`'s `Waiting` case (`Movable.scala:78-91`): after sending `EnterLinkData`,
the Movable resolves `onFinishSpontaneous` immediately and then self-reschedules every tick
(`onFinishSpontaneous(Some(currentTick + 1))`) while polling for the reply, up to `MaxWaitingTicks`
(a self-recovery timeout for a genuinely lost reply). This is real dispatch activity from the LTM's
perspective, so `currentTick`/`highestProcessedTick` climb every tick with **no actual business
progress** — purely idle polling. If the `Link` is busy (its own LTM routee serving other vehicles)
and its real, correct reply arrives stamped with an earlier tick than the Movable's now-inflated
`currentTick`, the straggler check fires for what is genuinely the awaited, correct reply. This is
architectural, not a code bug: the per-tick self-poll pattern is exactly what makes Time Warp's
straggler mechanism see ordinary waiting as forward progress needing later correction. Full
before/after architecture diagrams, the proposed fix (eliminate the round-trip entirely using the
already-existing, already-replay-safe `DynamicWeightCache` instead of a live reply), and its
explicit fidelity trade-off (`Link.costPublishInterval`, default 10 ticks of staleness) are written
up in `docs/TIME_WARP_ARCHITECTURE_AUDIT.md`'s Section 5 — deliberately **not implemented**, pending
a modeling-fidelity decision, not an engineering one.

This entry supersedes the vague "Parquet parity with conservative mode is not yet achieved" language
elsewhere in `docs/TIME_WARP_DESIGN.md` with concrete, reproducible numbers. Reproduction: run
`simulations/input/tw_livelock_repro` in both `timeManagerType` modes against the same cluster and
diff parquet output by `(event_type, entity_id, tick)`.

## Time Warp: Awaited-Reply Registry Outside the Snapshot Broke Replay and Reprocessing of Undone Replies (Found 2026-10-21, Fixed 2026-10-21)

`outstandingAwaitedReplies` was a rollback-immune actor var. A checkpoint restore therefore could not
bring back a wait that an undone (or replayed) event had consumed, so a reply reexecuted by replay
(Gap P) or reprocessed after a straggler (Gap A) found nothing awaited, was dropped as stale, and the
actor stayed `Waiting`. A first patch recorded each `isAwaitingReply` verdict in the log; that was a
workaround and was replaced.

**Fix:** the registry is part of `MigrationSnapshot` (`awaitedReplies`), captured and restored with
`state`, so a restore plus replay rebuilds it exactly as it was at the restored point. Waits
registered by undone events vanish by themselves (`pruneInvalidatedAwaitedReplies` is gone), a wait
an undone event consumed comes back, and a shard migration can no longer drop a pending reply
obligation. Replay allocates no send seqs (it no longer resends); a replayed `registerAwaitedReply`
takes the seq of the original send from `LoggedEvent.sentMessages`, so the echoed `requestSeq` still
matches. Covered by `CarReplayEquivalenceSpec` (Gap P, undone reply accepted on reprocessing, stale
duplicate stays stale).

## Test Coverage

Effectively none. `src/main/scala` has ~504 files; `src/test/scala` has **exactly one** file
(`system/broker/kafka/abstraction/KafkaAbstractionSpec.scala`). No tests exist for Person, Car,
Bicycle, Motorcycle, Link, Node, TrafficSignal, Bus, or Subway — i.e. none of the core mobility
logic (car-following, lane-change, mode choice, routing) has automated coverage. `CLAUDE.md`
already acknowledges this in its own "Testing" section, but the README/docs don't surface it, so a
reader skimming just the README would assume normal test coverage exists. Treat any change to
`model.hybrid.actor` as needing manual verification (see the `verify` skill / `run` skill) since
there's no test suite to catch regressions.

## Stub / No-Op Components

- **`MachineLearningManager.scala`** (17 lines) is a no-op stub —
  `handleEvent: Receive = { case _ => }`. The README's manager table lists it as if it provides ML
  inference hooks; it currently does nothing.

## Stale Refactor Progress Logs

`docs/REFACTORING_PERSON_PROGRESS.md` and `docs/REFACTORING_STATUS.md` describe an in-progress
`Person.scala` refactor that at one point had 20 active compilation errors and duplicated/obsolete
methods. This was apparently resolved (`docs/REFACTORING_PERSON_COMPLETED.md`; current
`Person.scala` is 392 lines and compiles), but the earlier progress logs remain in `docs/` without
a clear "superseded" marker. A reader skimming `docs/` chronologically could reasonably conclude
the refactor is still broken. Either mark the in-progress logs as historical/completed at the top,
or fold their still-relevant content into `REFACTORING_PERSON_COMPLETED.md` and remove the rest.

## Minor Drift

- **REST API**: `POST /api/v1/simulation/resume` exists in `SimulationRoutes.scala` but isn't
  listed in `docs/API.md`'s endpoint table. Otherwise the documented endpoints
  (`/health`, `/simulation/status|start|pause|stop`, `/scenarios`, `/scenarios/{name}/load`,
  `/settings`) match the real routes.
- **Diagrams**: `docs/diagrams/HTC_EXECUTION_FLOW.drawio`/`.mmd` predate the other per-agent
  diagrams by over a week, and 324 files under `src/main/scala` have newer mtimes than
  `docs/PERSON_AGENT.md` — a plausible (not confirmed) sign that some agent docs have drifted from
  recent refactors. Worth a periodic pass to confirm the `docs/*_AGENT.md` files still match
  current handler behavior, especially after any `htc-actor-dev` work lands.

## What Holds Up Well

- Terraform (`terraform/gcp/main.tf`, `vm/main.tf`) and Kubernetes manifests (`k8s/*.yaml`,
  `k8s/monitoring/*.yaml`) are real, filled-in infrastructure — not scaffolding.
- Prometheus metrics and ClickHouse reporting are genuinely wired (`core/metrics/`,
  `core/actor/manager/report/ClickHouseReportData.scala`).
- The REST API, Person/Car/Bus/Subway agent behavior, and the manager hierarchy described in the
  README are accurate for the `model.hybrid.actor` package that's actually in active use.

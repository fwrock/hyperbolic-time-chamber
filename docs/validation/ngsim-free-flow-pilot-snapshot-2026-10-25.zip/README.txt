NGSIM initialized free-flow pilot observation snapshot

Source: U.S. Department of Transportation Federal Highway Administration. (2016). Next Generation Simulation (NGSIM) Vehicle Trajectories and Supporting Data. Provided by ITS DataHub through Data.transportation.gov. DOI: https://doi.org/10.21949/1504477
Retrieved: 2026-10-24

Dataset license: Creative Commons Attribution-ShareAlike 3.0.
https://creativecommons.org/licenses/by-sa/3.0/

Original metadata and bounded API responses are retained unchanged. Source URLs and per-file SHA-256 hashes are in quality-control.json. Generated quality-control fields convert feet to metres, fit initial speed from one second, and separate the next ten seconds as prediction observations. The retained pilot does not establish general empirical traffic validity.

Reproduction: extract this archive to a fresh directory and pass that directory as --snapshot to scripts/scenario/ngsim_field_pilot.py.
